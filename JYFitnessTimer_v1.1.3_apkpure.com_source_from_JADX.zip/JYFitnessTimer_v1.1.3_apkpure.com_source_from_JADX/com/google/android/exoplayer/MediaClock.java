package com.google.android.exoplayer;

public interface MediaClock {
    long getPositionUs();
}
