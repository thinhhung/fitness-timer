package com.google.android.exoplayer.chunk;

public interface FormatWrapper {
    Format getFormat();
}
