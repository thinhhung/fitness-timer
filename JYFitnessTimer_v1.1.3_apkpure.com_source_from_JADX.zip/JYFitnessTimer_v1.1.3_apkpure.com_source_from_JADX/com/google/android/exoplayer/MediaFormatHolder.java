package com.google.android.exoplayer;

import com.google.android.exoplayer.drm.DrmInitData;

public final class MediaFormatHolder {
    public DrmInitData drmInitData;
    public MediaFormat format;
}
