package com.google.android.exoplayer.extractor;

public interface SeekMap {
    public static final SeekMap UNSEEKABLE = new C15211();

    static class C15211 implements SeekMap {
        C15211() {
        }

        public boolean isSeekable() {
            return false;
        }

        public long getPosition(long timeUs) {
            return 0;
        }
    }

    long getPosition(long j);

    boolean isSeekable();
}
