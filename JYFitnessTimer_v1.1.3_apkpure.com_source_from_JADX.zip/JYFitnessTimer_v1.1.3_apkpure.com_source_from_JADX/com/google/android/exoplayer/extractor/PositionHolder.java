package com.google.android.exoplayer.extractor;

public final class PositionHolder {
    public long position;
}
