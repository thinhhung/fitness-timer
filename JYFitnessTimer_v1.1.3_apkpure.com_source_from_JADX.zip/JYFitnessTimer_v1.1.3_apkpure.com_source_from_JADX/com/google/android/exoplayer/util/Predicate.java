package com.google.android.exoplayer.util;

public interface Predicate<T> {
    boolean evaluate(T t);
}
