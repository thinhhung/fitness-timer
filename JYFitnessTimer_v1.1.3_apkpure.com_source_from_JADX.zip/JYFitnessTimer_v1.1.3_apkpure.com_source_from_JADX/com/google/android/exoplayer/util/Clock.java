package com.google.android.exoplayer.util;

public interface Clock {
    long elapsedRealtime();
}
