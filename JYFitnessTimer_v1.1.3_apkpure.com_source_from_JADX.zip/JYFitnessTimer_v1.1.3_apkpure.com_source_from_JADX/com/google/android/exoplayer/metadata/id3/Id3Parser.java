package com.google.android.exoplayer.metadata.id3;

import com.google.android.exoplayer.ParserException;
import com.google.android.exoplayer.metadata.MetadataParser;
import com.google.android.exoplayer.util.MimeTypes;
import com.google.android.exoplayer.util.ParsableByteArray;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import org.apache.commons.lang3.CharEncoding;

public final class Id3Parser implements MetadataParser<List<Id3Frame>> {
    private static final int ID3_TEXT_ENCODING_ISO_8859_1 = 0;
    private static final int ID3_TEXT_ENCODING_UTF_16 = 1;
    private static final int ID3_TEXT_ENCODING_UTF_16BE = 2;
    private static final int ID3_TEXT_ENCODING_UTF_8 = 3;

    public boolean canParse(String mimeType) {
        return mimeType.equals(MimeTypes.APPLICATION_ID3);
    }

    public List<Id3Frame> parse(byte[] data, int size) throws UnsupportedEncodingException, ParserException {
        List<Id3Frame> id3Frames = new ArrayList();
        ParsableByteArray parsableByteArray = new ParsableByteArray(data, size);
        int id3Size = parseId3Header(parsableByteArray);
        while (id3Size > 0) {
            int frameId0 = parsableByteArray.readUnsignedByte();
            int frameId1 = parsableByteArray.readUnsignedByte();
            int frameId2 = parsableByteArray.readUnsignedByte();
            int frameId3 = parsableByteArray.readUnsignedByte();
            int frameSize = parsableByteArray.readSynchSafeInt();
            if (frameSize <= 1) {
                break;
            }
            parsableByteArray.skipBytes(2);
            int encoding;
            String charset;
            byte[] frame;
            int firstZeroIndex;
            if (frameId0 == 84 && frameId1 == 88 && frameId2 == 88 && frameId3 == 88) {
                encoding = parsableByteArray.readUnsignedByte();
                charset = getCharsetName(encoding);
                frame = new byte[(frameSize - 1)];
                parsableByteArray.readBytes(frame, 0, frameSize - 1);
                firstZeroIndex = indexOfEOS(frame, 0, encoding);
                int valueStartIndex = firstZeroIndex + delimiterLength(encoding);
                id3Frames.add(new TxxxFrame(new String(frame, 0, firstZeroIndex, charset), new String(frame, valueStartIndex, indexOfEOS(frame, valueStartIndex, encoding) - valueStartIndex, charset)));
            } else if (frameId0 == 80 && frameId1 == 82 && frameId2 == 73 && frameId3 == 86) {
                frame = new byte[frameSize];
                parsableByteArray.readBytes(frame, 0, frameSize);
                firstZeroIndex = indexOf(frame, 0, (byte) 0);
                r0 = new String(frame, 0, firstZeroIndex, CharEncoding.ISO_8859_1);
                Object privateData = new byte[((frameSize - firstZeroIndex) - 1)];
                System.arraycopy(frame, firstZeroIndex + 1, privateData, 0, (frameSize - firstZeroIndex) - 1);
                id3Frames.add(new PrivFrame(r0, privateData));
            } else if (frameId0 == 71 && frameId1 == 69 && frameId2 == 79 && frameId3 == 66) {
                encoding = parsableByteArray.readUnsignedByte();
                charset = getCharsetName(encoding);
                frame = new byte[(frameSize - 1)];
                parsableByteArray.readBytes(frame, 0, frameSize - 1);
                firstZeroIndex = indexOf(frame, 0, (byte) 0);
                r0 = new String(frame, 0, firstZeroIndex, CharEncoding.ISO_8859_1);
                int filenameStartIndex = firstZeroIndex + 1;
                int filenameEndIndex = indexOfEOS(frame, filenameStartIndex, encoding);
                String filename = new String(frame, filenameStartIndex, filenameEndIndex - filenameStartIndex, charset);
                int descriptionStartIndex = filenameEndIndex + delimiterLength(encoding);
                int descriptionEndIndex = indexOfEOS(frame, descriptionStartIndex, encoding);
                String description = new String(frame, descriptionStartIndex, descriptionEndIndex - descriptionStartIndex, charset);
                int objectDataSize = ((frameSize - 1) - descriptionEndIndex) - delimiterLength(encoding);
                Object objectData = new byte[objectDataSize];
                System.arraycopy(frame, delimiterLength(encoding) + descriptionEndIndex, objectData, 0, objectDataSize);
                id3Frames.add(new GeobFrame(r0, filename, description, objectData));
            } else {
                String type = String.format(Locale.US, "%c%c%c%c", new Object[]{Integer.valueOf(frameId0), Integer.valueOf(frameId1), Integer.valueOf(frameId2), Integer.valueOf(frameId3)});
                frame = new byte[frameSize];
                parsableByteArray.readBytes(frame, 0, frameSize);
                id3Frames.add(new BinaryFrame(type, frame));
            }
            id3Size -= frameSize + 10;
        }
        return Collections.unmodifiableList(id3Frames);
    }

    private static int indexOf(byte[] data, int fromIndex, byte key) {
        for (int i = fromIndex; i < data.length; i++) {
            if (data[i] == key) {
                return i;
            }
        }
        return data.length;
    }

    private static int indexOfEOS(byte[] data, int fromIndex, int encodingByte) {
        int terminationPos = indexOf(data, fromIndex, (byte) 0);
        if (encodingByte == 0 || encodingByte == 3) {
            return terminationPos;
        }
        while (terminationPos < data.length - 1) {
            if (data[terminationPos + 1] == (byte) 0) {
                return terminationPos;
            }
            terminationPos = indexOf(data, terminationPos + 1, (byte) 0);
        }
        return data.length;
    }

    private static int delimiterLength(int encodingByte) {
        return (encodingByte == 0 || encodingByte == 3) ? 1 : 2;
    }

    private static int parseId3Header(ParsableByteArray id3Buffer) throws ParserException {
        int id1 = id3Buffer.readUnsignedByte();
        int id2 = id3Buffer.readUnsignedByte();
        int id3 = id3Buffer.readUnsignedByte();
        if (id1 == 73 && id2 == 68 && id3 == 51) {
            id3Buffer.skipBytes(2);
            int flags = id3Buffer.readUnsignedByte();
            int id3Size = id3Buffer.readSynchSafeInt();
            if ((flags & 2) != 0) {
                int extendedHeaderSize = id3Buffer.readSynchSafeInt();
                if (extendedHeaderSize > 4) {
                    id3Buffer.skipBytes(extendedHeaderSize - 4);
                }
                id3Size -= extendedHeaderSize;
            }
            if ((flags & 8) != 0) {
                return id3Size - 10;
            }
            return id3Size;
        }
        throw new ParserException(String.format(Locale.US, "Unexpected ID3 file identifier, expected \"ID3\", actual \"%c%c%c\".", new Object[]{Integer.valueOf(id1), Integer.valueOf(id2), Integer.valueOf(id3)}));
    }

    private static String getCharsetName(int encodingByte) {
        switch (encodingByte) {
            case 0:
                return CharEncoding.ISO_8859_1;
            case 1:
                return CharEncoding.UTF_16;
            case 2:
                return CharEncoding.UTF_16BE;
            case 3:
                return "UTF-8";
            default:
                return CharEncoding.ISO_8859_1;
        }
    }
}
