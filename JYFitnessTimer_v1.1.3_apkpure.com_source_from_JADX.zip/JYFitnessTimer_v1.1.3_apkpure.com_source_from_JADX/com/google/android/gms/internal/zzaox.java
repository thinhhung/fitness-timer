package com.google.android.gms.internal;

import android.util.Log;
import com.google.android.gms.analytics.Logger;

final class zzaox implements Logger {
    private boolean zzadJ;
    private int zzagZ = 2;

    zzaox() {
    }

    public final void error(Exception exception) {
    }

    public final void error(String str) {
    }

    public final int getLogLevel() {
        return this.zzagZ;
    }

    public final void info(String str) {
    }

    public final void setLogLevel(int i) {
        this.zzagZ = i;
        if (!this.zzadJ) {
            String str = (String) zzape.zzahi.get();
            Log.i((String) zzape.zzahi.get(), new StringBuilder(String.valueOf(str).length() + 91).append("Logger is deprecated. To enable debug logging, please run:\nadb shell setprop log.tag.").append(str).append(" DEBUG").toString());
            this.zzadJ = true;
        }
    }

    public final void verbose(String str) {
    }

    public final void warn(String str) {
    }
}
