package com.google.android.gms.internal;

final class zzcim implements Runnable {
    private /* synthetic */ zzcft zzbti;
    private /* synthetic */ zzcic zzbtj;
    private /* synthetic */ zzcgl zzbtn;

    zzcim(zzcic com_google_android_gms_internal_zzcic, zzcgl com_google_android_gms_internal_zzcgl, zzcft com_google_android_gms_internal_zzcft) {
        this.zzbtj = com_google_android_gms_internal_zzcic;
        this.zzbtn = com_google_android_gms_internal_zzcgl;
        this.zzbti = com_google_android_gms_internal_zzcft;
    }

    public final void run() {
        this.zzbtj.zzboi.zzzc();
        this.zzbtj.zzboi.zzb(this.zzbtn, this.zzbti);
    }
}
