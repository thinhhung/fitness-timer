package com.google.android.gms.internal;

final class zzuy implements zzale<zztt> {
    private /* synthetic */ zzut zzLB;

    zzuy(zzux com_google_android_gms_internal_zzux, zzut com_google_android_gms_internal_zzut) {
        this.zzLB = com_google_android_gms_internal_zzut;
    }

    public final /* synthetic */ void zzc(Object obj) {
        zztt com_google_android_gms_internal_zztt = (zztt) obj;
        zzahd.v("Getting a new session for JS Engine.");
        this.zzLB.zzf(com_google_android_gms_internal_zztt.zzeX());
    }
}
