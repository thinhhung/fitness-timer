package com.google.android.gms.internal;

import com.google.android.gms.ads.internal.zzbs;

@zzaaz
public abstract class zzabk implements zzabi, zzajb<Void> {
    private final Object mLock = new Object();
    private final zzalb<zzabq> zzSu;
    private final zzabi zzSv;

    public zzabk(zzalb<zzabq> com_google_android_gms_internal_zzalb_com_google_android_gms_internal_zzabq, zzabi com_google_android_gms_internal_zzabi) {
        this.zzSu = com_google_android_gms_internal_zzalb_com_google_android_gms_internal_zzabq;
        this.zzSv = com_google_android_gms_internal_zzabi;
    }

    public final void cancel() {
        zzgz();
    }

    public final void zza(zzabu com_google_android_gms_internal_zzabu) {
        synchronized (this.mLock) {
            this.zzSv.zza(com_google_android_gms_internal_zzabu);
            zzgz();
        }
    }

    final boolean zza(zzaby com_google_android_gms_internal_zzaby, zzabq com_google_android_gms_internal_zzabq) {
        try {
            com_google_android_gms_internal_zzaby.zza(com_google_android_gms_internal_zzabq, new zzabt(this));
            return true;
        } catch (Throwable th) {
            zzako.zzc("Could not fetch ad response from ad request service due to an Exception.", th);
            zzbs.zzbC().zza(th, "AdRequestClientTask.getAdResponseFromService");
            this.zzSv.zza(new zzabu(0));
            return false;
        }
    }

    public abstract zzaby zzgA();

    public final /* synthetic */ Object zzgo() {
        zzaby zzgA = zzgA();
        if (zzgA == null) {
            this.zzSv.zza(new zzabu(0));
            zzgz();
        } else {
            this.zzSu.zza(new zzabl(this, zzgA), new zzabm(this));
        }
        return null;
    }

    public abstract void zzgz();
}
