package com.google.android.gms.internal;

import android.app.job.JobParameters;
import android.content.Context;

public interface zzckl {
    boolean callServiceStopSelfResult(int i);

    Context getContext();

    void zza(JobParameters jobParameters, boolean z);
}
