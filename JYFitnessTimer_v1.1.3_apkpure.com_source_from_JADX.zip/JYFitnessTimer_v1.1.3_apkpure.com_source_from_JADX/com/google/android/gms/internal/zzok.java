package com.google.android.gms.internal;

import java.util.Map;

final class zzok implements zzrd {
    private /* synthetic */ zzvd zzIm;
    private /* synthetic */ zzog zzIn;

    zzok(zzog com_google_android_gms_internal_zzog, zzvd com_google_android_gms_internal_zzvd) {
        this.zzIn = com_google_android_gms_internal_zzog;
        this.zzIm = com_google_android_gms_internal_zzvd;
    }

    public final void zza(zzalm com_google_android_gms_internal_zzalm, Map<String, String> map) {
        zzalm com_google_android_gms_internal_zzalm2 = (zzalm) this.zzIn.zzIk.get();
        if (com_google_android_gms_internal_zzalm2 == null) {
            this.zzIm.zzb("/hideOverlay", (zzrd) this);
        } else {
            com_google_android_gms_internal_zzalm2.getView().setVisibility(8);
        }
    }
}
