package com.google.android.gms.internal;

final class zzano implements Runnable {
    private /* synthetic */ zzank zzafF;
    private /* synthetic */ zzapj zzafJ;

    zzano(zzank com_google_android_gms_internal_zzank, zzapj com_google_android_gms_internal_zzapj) {
        this.zzafF = com_google_android_gms_internal_zzank;
        this.zzafJ = com_google_android_gms_internal_zzapj;
    }

    public final void run() {
        this.zzafF.zzafD.zza(this.zzafJ);
    }
}
