package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

public final class zzyu extends zzed implements zzys {
    zzyu(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.purchase.client.IInAppPurchaseListener");
    }

    public final void zza(zzyq com_google_android_gms_internal_zzyq) throws RemoteException {
        Parcel zzY = zzY();
        zzef.zza(zzY, (IInterface) com_google_android_gms_internal_zzyq);
        zzb(1, zzY);
    }
}
