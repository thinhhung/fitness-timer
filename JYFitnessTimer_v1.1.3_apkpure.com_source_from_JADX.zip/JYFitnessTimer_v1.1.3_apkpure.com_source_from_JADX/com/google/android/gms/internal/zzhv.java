package com.google.android.gms.internal;

import android.os.Bundle;
import android.support.annotation.Nullable;
import com.google.android.gms.common.internal.zzf;

final class zzhv implements zzf {
    private /* synthetic */ zzhs zzzv;

    zzhv(zzhs com_google_android_gms_internal_zzhs) {
        this.zzzv = com_google_android_gms_internal_zzhs;
    }

    public final void onConnected(@Nullable Bundle bundle) {
        synchronized (zzhs.zzc(this.zzzv)) {
            try {
                if (zzhs.zzd(this.zzzv) != null) {
                    zzhs.zza(this.zzzv, zzhs.zzd(this.zzzv).zzdc());
                }
            } catch (Throwable e) {
                zzahd.zzb("Unable to obtain a cache service instance.", e);
                zzhs.zza(this.zzzv);
            }
            zzhs.zzc(this.zzzv).notifyAll();
        }
    }

    public final void onConnectionSuspended(int i) {
        synchronized (zzhs.zzc(this.zzzv)) {
            zzhs.zza(this.zzzv, null);
            zzhs.zzc(this.zzzv).notifyAll();
        }
    }
}
