package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences.Editor;

final class zzaho extends zzaid {
    private /* synthetic */ String zzZh;
    private /* synthetic */ Context zztI;

    zzaho(Context context, String str) {
        this.zztI = context;
        this.zzZh = str;
        super();
    }

    public final void zzbc() {
        Editor edit = this.zztI.getSharedPreferences("admob", 0).edit();
        edit.putString("native_advanced_settings", this.zzZh);
        edit.apply();
    }
}
