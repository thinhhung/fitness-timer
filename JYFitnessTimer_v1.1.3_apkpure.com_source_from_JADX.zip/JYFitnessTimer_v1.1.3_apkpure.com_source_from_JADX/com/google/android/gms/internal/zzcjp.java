package com.google.android.gms.internal;

import android.content.ComponentName;
import android.content.Context;
import android.os.RemoteException;
import android.support.annotation.WorkerThread;
import com.google.android.gms.common.internal.zzbr;
import com.google.android.gms.common.stats.zza;
import com.google.android.gms.common.util.zzf;
import com.google.android.gms.measurement.AppMeasurement$zzb;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

public final class zzcjp extends zzciv {
    private final zzckc zzbtX;
    private zzcgp zzbtY;
    private Boolean zzbtZ;
    private final zzcgd zzbua;
    private final zzckr zzbub;
    private final List<Runnable> zzbuc = new ArrayList();
    private final zzcgd zzbud;

    protected zzcjp(zzchx com_google_android_gms_internal_zzchx) {
        super(com_google_android_gms_internal_zzchx);
        this.zzbub = new zzckr(com_google_android_gms_internal_zzchx.zzkp());
        this.zzbtX = new zzckc(this);
        this.zzbua = new zzcjq(this, com_google_android_gms_internal_zzchx);
        this.zzbud = new zzcju(this, com_google_android_gms_internal_zzchx);
    }

    @WorkerThread
    private final void onServiceDisconnected(ComponentName componentName) {
        super.zzjB();
        if (this.zzbtY != null) {
            this.zzbtY = null;
            super.zzwE().zzyB().zzj("Disconnected from device MeasurementService", componentName);
            super.zzjB();
            zzkZ();
        }
    }

    @WorkerThread
    private final void zzkO() {
        super.zzjB();
        this.zzbub.start();
        this.zzbua.zzs(zzcfy.zzxA());
    }

    @WorkerThread
    private final void zzkP() {
        super.zzjB();
        if (isConnected()) {
            super.zzwE().zzyB().log("Inactivity, disconnecting from the service");
            disconnect();
        }
    }

    @WorkerThread
    private final void zzm(Runnable runnable) throws IllegalStateException {
        super.zzjB();
        if (isConnected()) {
            runnable.run();
        } else if (((long) this.zzbuc.size()) >= zzcfy.zzxI()) {
            super.zzwE().zzyv().log("Discarding data. Max runnable queue size reached");
        } else {
            this.zzbuc.add(runnable);
            this.zzbud.zzs(60000);
            zzkZ();
        }
    }

    @WorkerThread
    private final void zzzj() {
        super.zzjB();
        super.zzwE().zzyB().zzj("Processing queued up service tasks", Integer.valueOf(this.zzbuc.size()));
        for (Runnable run : this.zzbuc) {
            try {
                run.run();
            } catch (Throwable th) {
                super.zzwE().zzyv().zzj("Task exception while flushing queue", th);
            }
        }
        this.zzbuc.clear();
        this.zzbud.cancel();
    }

    @WorkerThread
    public final void disconnect() {
        super.zzjB();
        zzkC();
        try {
            zza.zzrT();
            super.getContext().unbindService(this.zzbtX);
        } catch (IllegalStateException e) {
        } catch (IllegalArgumentException e2) {
        }
        this.zzbtY = null;
    }

    public final /* bridge */ /* synthetic */ Context getContext() {
        return super.getContext();
    }

    @WorkerThread
    public final boolean isConnected() {
        super.zzjB();
        zzkC();
        return this.zzbtY != null;
    }

    @WorkerThread
    protected final void zza(zzcgp com_google_android_gms_internal_zzcgp) {
        super.zzjB();
        zzbr.zzu(com_google_android_gms_internal_zzcgp);
        this.zzbtY = com_google_android_gms_internal_zzcgp;
        zzkO();
        zzzj();
    }

    @WorkerThread
    final void zza(zzcgp com_google_android_gms_internal_zzcgp, com.google.android.gms.common.internal.safeparcel.zza com_google_android_gms_common_internal_safeparcel_zza) {
        super.zzjB();
        super.zzwo();
        zzkC();
        zzcfy.zzxD();
        List arrayList = new ArrayList();
        zzcfy.zzxM();
        int i = 100;
        for (int i2 = 0; i2 < 1001 && r5 == 100; i2++) {
            Object zzbo = super.zzwx().zzbo(100);
            if (zzbo != null) {
                arrayList.addAll(zzbo);
                i = zzbo.size();
            } else {
                i = 0;
            }
            if (com_google_android_gms_common_internal_safeparcel_zza != null && r5 < 100) {
                arrayList.add(com_google_android_gms_common_internal_safeparcel_zza);
            }
            ArrayList arrayList2 = (ArrayList) arrayList;
            int size = arrayList2.size();
            int i3 = 0;
            while (i3 < size) {
                Object obj = arrayList2.get(i3);
                i3++;
                com.google.android.gms.common.internal.safeparcel.zza com_google_android_gms_common_internal_safeparcel_zza2 = (com.google.android.gms.common.internal.safeparcel.zza) obj;
                if (com_google_android_gms_common_internal_safeparcel_zza2 instanceof zzcgl) {
                    try {
                        com_google_android_gms_internal_zzcgp.zza((zzcgl) com_google_android_gms_common_internal_safeparcel_zza2, super.zzwt().zzdW(super.zzwE().zzyC()));
                    } catch (RemoteException e) {
                        super.zzwE().zzyv().zzj("Failed to send event to the service", e);
                    }
                } else if (com_google_android_gms_common_internal_safeparcel_zza2 instanceof zzcku) {
                    try {
                        com_google_android_gms_internal_zzcgp.zza((zzcku) com_google_android_gms_common_internal_safeparcel_zza2, super.zzwt().zzdW(super.zzwE().zzyC()));
                    } catch (RemoteException e2) {
                        super.zzwE().zzyv().zzj("Failed to send attribute to the service", e2);
                    }
                } else if (com_google_android_gms_common_internal_safeparcel_zza2 instanceof zzcfw) {
                    try {
                        com_google_android_gms_internal_zzcgp.zza((zzcfw) com_google_android_gms_common_internal_safeparcel_zza2, super.zzwt().zzdW(super.zzwE().zzyC()));
                    } catch (RemoteException e22) {
                        super.zzwE().zzyv().zzj("Failed to send conditional property to the service", e22);
                    }
                } else {
                    super.zzwE().zzyv().log("Discarding data. Unrecognized parcel type.");
                }
            }
        }
    }

    @WorkerThread
    protected final void zza(AppMeasurement$zzb appMeasurement$zzb) {
        super.zzjB();
        zzkC();
        zzm(new zzcjt(this, appMeasurement$zzb));
    }

    @WorkerThread
    public final void zza(AtomicReference<String> atomicReference) {
        super.zzjB();
        zzkC();
        zzm(new zzcjr(this, atomicReference));
    }

    @WorkerThread
    protected final void zza(AtomicReference<List<zzcfw>> atomicReference, String str, String str2, String str3) {
        super.zzjB();
        zzkC();
        zzm(new zzcjy(this, atomicReference, str, str2, str3));
    }

    @WorkerThread
    protected final void zza(AtomicReference<List<zzcku>> atomicReference, String str, String str2, String str3, boolean z) {
        super.zzjB();
        zzkC();
        zzm(new zzcjz(this, atomicReference, str, str2, str3, z));
    }

    @WorkerThread
    protected final void zza(AtomicReference<List<zzcku>> atomicReference, boolean z) {
        super.zzjB();
        zzkC();
        zzm(new zzckb(this, atomicReference, z));
    }

    @WorkerThread
    protected final void zzb(zzcku com_google_android_gms_internal_zzcku) {
        super.zzjB();
        zzkC();
        zzcfy.zzxD();
        zzm(new zzcka(this, super.zzwx().zza(com_google_android_gms_internal_zzcku), com_google_android_gms_internal_zzcku));
    }

    @WorkerThread
    protected final void zzc(zzcgl com_google_android_gms_internal_zzcgl, String str) {
        zzbr.zzu(com_google_android_gms_internal_zzcgl);
        super.zzjB();
        zzkC();
        zzcfy.zzxD();
        zzm(new zzcjw(this, true, super.zzwx().zza(com_google_android_gms_internal_zzcgl), com_google_android_gms_internal_zzcgl, str));
    }

    @WorkerThread
    protected final void zzf(zzcfw com_google_android_gms_internal_zzcfw) {
        zzbr.zzu(com_google_android_gms_internal_zzcfw);
        super.zzjB();
        zzkC();
        zzcfy.zzxD();
        zzm(new zzcjx(this, true, super.zzwx().zzc(com_google_android_gms_internal_zzcfw), new zzcfw(com_google_android_gms_internal_zzcfw), com_google_android_gms_internal_zzcfw));
    }

    public final /* bridge */ /* synthetic */ void zzjB() {
        super.zzjB();
    }

    protected final void zzjC() {
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    @android.support.annotation.WorkerThread
    final void zzkZ() {
        /*
        r6 = this;
        r2 = 0;
        r1 = 1;
        super.zzjB();
        r6.zzkC();
        r0 = r6.isConnected();
        if (r0 == 0) goto L_0x000f;
    L_0x000e:
        return;
    L_0x000f:
        r0 = r6.zzbtZ;
        if (r0 != 0) goto L_0x0067;
    L_0x0013:
        r0 = super.zzwF();
        r0 = r0.zzyG();
        r6.zzbtZ = r0;
        r0 = r6.zzbtZ;
        if (r0 != 0) goto L_0x0067;
    L_0x0021:
        r0 = super.zzwE();
        r0 = r0.zzyB();
        r3 = "State of service unknown";
        r0.log(r3);
        super.zzjB();
        r6.zzkC();
        com.google.android.gms.internal.zzcfy.zzxD();
        r0 = super.zzwE();
        r0 = r0.zzyB();
        r3 = "Checking service availability";
        r0.log(r3);
        r0 = com.google.android.gms.common.zze.zzoU();
        r3 = super.getContext();
        r0 = r0.isGooglePlayServicesAvailable(r3);
        switch(r0) {
            case 0: goto L_0x0082;
            case 1: goto L_0x0091;
            case 2: goto L_0x00ae;
            case 3: goto L_0x00bd;
            case 9: goto L_0x00cb;
            case 18: goto L_0x009f;
            default: goto L_0x0053;
        };
    L_0x0053:
        r0 = r2;
    L_0x0054:
        r0 = java.lang.Boolean.valueOf(r0);
        r6.zzbtZ = r0;
        r0 = super.zzwF();
        r3 = r6.zzbtZ;
        r3 = r3.booleanValue();
        r0.zzak(r3);
    L_0x0067:
        r0 = r6.zzbtZ;
        r0 = r0.booleanValue();
        if (r0 == 0) goto L_0x00da;
    L_0x006f:
        r0 = super.zzwE();
        r0 = r0.zzyB();
        r1 = "Using measurement service";
        r0.log(r1);
        r0 = r6.zzbtX;
        r0.zzzk();
        goto L_0x000e;
    L_0x0082:
        r0 = super.zzwE();
        r0 = r0.zzyB();
        r3 = "Service available";
        r0.log(r3);
        r0 = r1;
        goto L_0x0054;
    L_0x0091:
        r0 = super.zzwE();
        r0 = r0.zzyB();
        r3 = "Service missing";
        r0.log(r3);
        goto L_0x0053;
    L_0x009f:
        r0 = super.zzwE();
        r0 = r0.zzyx();
        r3 = "Service updating";
        r0.log(r3);
        r0 = r1;
        goto L_0x0054;
    L_0x00ae:
        r0 = super.zzwE();
        r0 = r0.zzyA();
        r3 = "Service container out of date";
        r0.log(r3);
        r0 = r1;
        goto L_0x0054;
    L_0x00bd:
        r0 = super.zzwE();
        r0 = r0.zzyx();
        r3 = "Service disabled";
        r0.log(r3);
        goto L_0x0053;
    L_0x00cb:
        r0 = super.zzwE();
        r0 = r0.zzyx();
        r3 = "Service invalid";
        r0.log(r3);
        goto L_0x0053;
    L_0x00da:
        com.google.android.gms.internal.zzcfy.zzxD();
        r0 = super.getContext();
        r0 = r0.getPackageManager();
        r3 = new android.content.Intent;
        r3.<init>();
        r4 = super.getContext();
        r5 = "com.google.android.gms.measurement.AppMeasurementService";
        r3 = r3.setClassName(r4, r5);
        r4 = 65536; // 0x10000 float:9.18355E-41 double:3.2379E-319;
        r0 = r0.queryIntentServices(r3, r4);
        if (r0 == 0) goto L_0x0130;
    L_0x00fc:
        r0 = r0.size();
        if (r0 <= 0) goto L_0x0130;
    L_0x0102:
        if (r1 == 0) goto L_0x0132;
    L_0x0104:
        r0 = super.zzwE();
        r0 = r0.zzyB();
        r1 = "Using local app measurement service";
        r0.log(r1);
        r0 = new android.content.Intent;
        r1 = "com.google.android.gms.measurement.START";
        r0.<init>(r1);
        r1 = new android.content.ComponentName;
        r2 = super.getContext();
        com.google.android.gms.internal.zzcfy.zzxD();
        r3 = "com.google.android.gms.measurement.AppMeasurementService";
        r1.<init>(r2, r3);
        r0.setComponent(r1);
        r1 = r6.zzbtX;
        r1.zzk(r0);
        goto L_0x000e;
    L_0x0130:
        r1 = r2;
        goto L_0x0102;
    L_0x0132:
        r0 = super.zzwE();
        r0 = r0.zzyv();
        r1 = "Unable to use remote or local measurement implementation. Please register the AppMeasurementService service in the app manifest";
        r0.log(r1);
        goto L_0x000e;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.zzcjp.zzkZ():void");
    }

    public final /* bridge */ /* synthetic */ zzf zzkp() {
        return super.zzkp();
    }

    public final /* bridge */ /* synthetic */ zzckx zzwA() {
        return super.zzwA();
    }

    public final /* bridge */ /* synthetic */ zzchr zzwB() {
        return super.zzwB();
    }

    public final /* bridge */ /* synthetic */ zzckm zzwC() {
        return super.zzwC();
    }

    public final /* bridge */ /* synthetic */ zzchs zzwD() {
        return super.zzwD();
    }

    public final /* bridge */ /* synthetic */ zzcgx zzwE() {
        return super.zzwE();
    }

    public final /* bridge */ /* synthetic */ zzchi zzwF() {
        return super.zzwF();
    }

    public final /* bridge */ /* synthetic */ zzcfy zzwG() {
        return super.zzwG();
    }

    public final /* bridge */ /* synthetic */ void zzwn() {
        super.zzwn();
    }

    public final /* bridge */ /* synthetic */ void zzwo() {
        super.zzwo();
    }

    public final /* bridge */ /* synthetic */ void zzwp() {
        super.zzwp();
    }

    public final /* bridge */ /* synthetic */ zzcfo zzwq() {
        return super.zzwq();
    }

    public final /* bridge */ /* synthetic */ zzcfv zzwr() {
        return super.zzwr();
    }

    public final /* bridge */ /* synthetic */ zzcix zzws() {
        return super.zzws();
    }

    public final /* bridge */ /* synthetic */ zzcgs zzwt() {
        return super.zzwt();
    }

    public final /* bridge */ /* synthetic */ zzcgf zzwu() {
        return super.zzwu();
    }

    public final /* bridge */ /* synthetic */ zzcjp zzwv() {
        return super.zzwv();
    }

    public final /* bridge */ /* synthetic */ zzcjl zzww() {
        return super.zzww();
    }

    public final /* bridge */ /* synthetic */ zzcgt zzwx() {
        return super.zzwx();
    }

    public final /* bridge */ /* synthetic */ zzcfz zzwy() {
        return super.zzwy();
    }

    public final /* bridge */ /* synthetic */ zzcgv zzwz() {
        return super.zzwz();
    }

    @WorkerThread
    protected final void zzzh() {
        super.zzjB();
        zzkC();
        zzm(new zzcjv(this));
    }

    @WorkerThread
    protected final void zzzi() {
        super.zzjB();
        zzkC();
        zzm(new zzcjs(this));
    }
}
