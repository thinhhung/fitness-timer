package com.google.android.gms.internal;

final class zzdd implements Runnable {
    private /* synthetic */ zzdb zzqZ;
    private /* synthetic */ int zzra;
    private /* synthetic */ boolean zzrb;

    zzdd(zzdb com_google_android_gms_internal_zzdb, int i, boolean z) {
        this.zzqZ = com_google_android_gms_internal_zzdb;
        this.zzra = i;
        this.zzrb = z;
    }

    public final void run() {
        zzax zzb = this.zzqZ.zzb(this.zzra, this.zzrb);
        this.zzqZ.zzqO = zzb;
        if (zzdb.zza(this.zzra, zzb)) {
            this.zzqZ.zza(this.zzra + 1, this.zzrb);
        }
    }
}
