package com.google.android.gms.internal;

import java.util.HashMap;
import java.util.Map;

final class zzsd implements Runnable {
    private /* synthetic */ String zzJU;
    private /* synthetic */ int zzJW;
    private /* synthetic */ zzsb zzJY;
    private /* synthetic */ String zzsG;

    zzsd(zzsb com_google_android_gms_internal_zzsb, String str, String str2, int i) {
        this.zzJY = com_google_android_gms_internal_zzsb;
        this.zzsG = str;
        this.zzJU = str2;
        this.zzJW = i;
    }

    public final void run() {
        Map hashMap = new HashMap();
        hashMap.put("event", "precacheComplete");
        hashMap.put("src", this.zzsG);
        hashMap.put("cachedSrc", this.zzJU);
        hashMap.put("totalBytes", Integer.toString(this.zzJW));
        zzsb.zza(this.zzJY, "onPrecacheEvent", hashMap);
    }
}
