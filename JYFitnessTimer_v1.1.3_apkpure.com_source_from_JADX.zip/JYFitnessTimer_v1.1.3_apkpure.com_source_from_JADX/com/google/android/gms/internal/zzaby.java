package com.google.android.gms.internal;

import android.os.IInterface;
import android.os.RemoteException;

public interface zzaby extends IInterface {
    void zza(zzabq com_google_android_gms_internal_zzabq, zzacb com_google_android_gms_internal_zzacb) throws RemoteException;

    void zza(zzacj com_google_android_gms_internal_zzacj, zzace com_google_android_gms_internal_zzace) throws RemoteException;

    zzabu zzc(zzabq com_google_android_gms_internal_zzabq) throws RemoteException;
}
