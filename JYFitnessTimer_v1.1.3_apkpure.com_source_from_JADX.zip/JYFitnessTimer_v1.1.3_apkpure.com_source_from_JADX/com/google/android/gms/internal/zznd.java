package com.google.android.gms.internal;

import android.view.View;
import com.google.android.gms.ads.doubleclick.CustomRenderedAd;
import com.google.android.gms.dynamic.zzn;

@zzaaz
public final class zznd implements CustomRenderedAd {
    private final zzne zzHk;

    public zznd(zzne com_google_android_gms_internal_zzne) {
        this.zzHk = com_google_android_gms_internal_zzne;
    }

    public final String getBaseUrl() {
        try {
            return this.zzHk.zzdW();
        } catch (Throwable e) {
            zzako.zzc("Could not delegate getBaseURL to CustomRenderedAd", e);
            return null;
        }
    }

    public final String getContent() {
        try {
            return this.zzHk.getContent();
        } catch (Throwable e) {
            zzako.zzc("Could not delegate getContent to CustomRenderedAd", e);
            return null;
        }
    }

    public final void onAdRendered(View view) {
        try {
            this.zzHk.zzi(view != null ? zzn.zzw(view) : null);
        } catch (Throwable e) {
            zzako.zzc("Could not delegate onAdRendered to CustomRenderedAd", e);
        }
    }

    public final void recordClick() {
        try {
            this.zzHk.recordClick();
        } catch (Throwable e) {
            zzako.zzc("Could not delegate recordClick to CustomRenderedAd", e);
        }
    }

    public final void recordImpression() {
        try {
            this.zzHk.recordImpression();
        } catch (Throwable e) {
            zzako.zzc("Could not delegate recordImpression to CustomRenderedAd", e);
        }
    }
}
