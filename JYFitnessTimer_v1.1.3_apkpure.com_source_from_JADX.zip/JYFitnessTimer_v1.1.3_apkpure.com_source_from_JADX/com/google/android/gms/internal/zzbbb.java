package com.google.android.gms.internal;

import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.PendingResults;
import com.google.android.gms.common.api.Status;
import java.util.ArrayList;
import java.util.TimeZone;

public final class zzbbb {
    private ArrayList<zzcrz> zzazA;
    private ArrayList<byte[]> zzazB;
    private boolean zzazC;
    private final ajc zzazD;
    private boolean zzazE;
    private /* synthetic */ zzbaz zzazF;
    private String zzazm;
    private int zzazn;
    private String zzazo;
    private String zzazp;
    private int zzazr;
    private final zzbbd zzazw;
    private ArrayList<Integer> zzazx;
    private ArrayList<String> zzazy;
    private ArrayList<Integer> zzazz;

    private zzbbb(zzbaz com_google_android_gms_internal_zzbaz, byte[] bArr) {
        this(com_google_android_gms_internal_zzbaz, bArr, null);
    }

    private zzbbb(zzbaz com_google_android_gms_internal_zzbaz, byte[] bArr, zzbbd com_google_android_gms_internal_zzbbd) {
        this.zzazF = com_google_android_gms_internal_zzbaz;
        this.zzazn = this.zzazF.zzazn;
        this.zzazm = this.zzazF.zzazm;
        this.zzazo = this.zzazF.zzazo;
        zzbaz com_google_android_gms_internal_zzbaz2 = this.zzazF;
        this.zzazp = null;
        this.zzazr = 0;
        this.zzazx = null;
        this.zzazy = null;
        this.zzazz = null;
        this.zzazA = null;
        this.zzazB = null;
        this.zzazC = true;
        this.zzazD = new ajc();
        this.zzazE = false;
        this.zzazo = com_google_android_gms_internal_zzbaz.zzazo;
        this.zzazp = null;
        this.zzazD.zzcwE = com_google_android_gms_internal_zzbaz.zzazt.currentTimeMillis();
        this.zzazD.zzcwF = com_google_android_gms_internal_zzbaz.zzazt.elapsedRealtime();
        ajc com_google_android_gms_internal_ajc = this.zzazD;
        com_google_android_gms_internal_zzbaz.zzazu;
        com_google_android_gms_internal_ajc.zzcwQ = (long) (TimeZone.getDefault().getOffset(this.zzazD.zzcwE) / 1000);
        if (bArr != null) {
            this.zzazD.zzcwL = bArr;
        }
        this.zzazw = null;
    }

    public final zzbbb zzai(int i) {
        this.zzazD.zzcwH = i;
        return this;
    }

    public final zzbbb zzaj(int i) {
        this.zzazD.zzrE = i;
        return this;
    }

    public final void zzoQ() {
        zzoR();
    }

    @Deprecated
    public final PendingResult<Status> zzoR() {
        if (this.zzazE) {
            throw new IllegalStateException("do not reuse LogEventBuilder");
        }
        this.zzazE = true;
        zzbbg com_google_android_gms_internal_zzbbg = new zzbbg(new zzbbw(this.zzazF.packageName, this.zzazF.zzazl, this.zzazn, this.zzazm, this.zzazo, this.zzazp, this.zzazF.zzazq, 0), this.zzazD, null, null, zzbaz.zzb(null), null, zzbaz.zzb(null), null, null, this.zzazC);
        zzbbw com_google_android_gms_internal_zzbbw = com_google_android_gms_internal_zzbbg.zzazG;
        return this.zzazF.zzazv.zzg(com_google_android_gms_internal_zzbbw.zzazm, com_google_android_gms_internal_zzbbw.zzazn) ? this.zzazF.zzazs.zza(com_google_android_gms_internal_zzbbg) : PendingResults.immediatePendingResult(Status.zzaBo);
    }
}
