package com.google.android.gms.internal;

import android.text.TextUtils;
import com.google.android.gms.analytics.zzj;
import com.google.android.gms.common.internal.zzbr;
import java.util.HashMap;
import java.util.Map;

public final class zzanf extends zzj<zzanf> {
    private String zzafe;
    private String zzaff;
    private String zzafg;
    private String zzafh;
    private boolean zzafi;
    private String zzafj;
    private boolean zzafk;
    private double zzafl;

    public final String getUserId() {
        return this.zzafg;
    }

    public final void setClientId(String str) {
        this.zzaff = str;
    }

    public final void setUserId(String str) {
        this.zzafg = str;
    }

    public final String toString() {
        Map hashMap = new HashMap();
        hashMap.put("hitType", this.zzafe);
        hashMap.put("clientId", this.zzaff);
        hashMap.put("userId", this.zzafg);
        hashMap.put("androidAdId", this.zzafh);
        hashMap.put("AdTargetingEnabled", Boolean.valueOf(this.zzafi));
        hashMap.put("sessionControl", this.zzafj);
        hashMap.put("nonInteraction", Boolean.valueOf(this.zzafk));
        hashMap.put("sampleRate", Double.valueOf(this.zzafl));
        return zzj.zzh(hashMap);
    }

    public final void zzG(boolean z) {
        this.zzafi = z;
    }

    public final void zzH(boolean z) {
        this.zzafk = true;
    }

    public final /* synthetic */ void zzb(zzj com_google_android_gms_analytics_zzj) {
        boolean z = true;
        zzanf com_google_android_gms_internal_zzanf = (zzanf) com_google_android_gms_analytics_zzj;
        if (!TextUtils.isEmpty(this.zzafe)) {
            com_google_android_gms_internal_zzanf.zzafe = this.zzafe;
        }
        if (!TextUtils.isEmpty(this.zzaff)) {
            com_google_android_gms_internal_zzanf.zzaff = this.zzaff;
        }
        if (!TextUtils.isEmpty(this.zzafg)) {
            com_google_android_gms_internal_zzanf.zzafg = this.zzafg;
        }
        if (!TextUtils.isEmpty(this.zzafh)) {
            com_google_android_gms_internal_zzanf.zzafh = this.zzafh;
        }
        if (this.zzafi) {
            com_google_android_gms_internal_zzanf.zzafi = true;
        }
        if (!TextUtils.isEmpty(this.zzafj)) {
            com_google_android_gms_internal_zzanf.zzafj = this.zzafj;
        }
        if (this.zzafk) {
            com_google_android_gms_internal_zzanf.zzafk = this.zzafk;
        }
        if (this.zzafl != 0.0d) {
            double d = this.zzafl;
            if (d < 0.0d || d > 100.0d) {
                z = false;
            }
            zzbr.zzb(z, (Object) "Sample rate must be between 0% and 100%");
            com_google_android_gms_internal_zzanf.zzafl = d;
        }
    }

    public final void zzbj(String str) {
        this.zzafe = str;
    }

    public final void zzbk(String str) {
        this.zzafh = str;
    }

    public final String zzjV() {
        return this.zzafe;
    }

    public final String zzjW() {
        return this.zzaff;
    }

    public final String zzjX() {
        return this.zzafh;
    }

    public final boolean zzjY() {
        return this.zzafi;
    }

    public final String zzjZ() {
        return this.zzafj;
    }

    public final boolean zzka() {
        return this.zzafk;
    }

    public final double zzkb() {
        return this.zzafl;
    }
}
