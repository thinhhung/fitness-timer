package com.google.android.gms.internal;

final class zznr implements Runnable {
    private /* synthetic */ zznq zzHQ;

    zznr(zznq com_google_android_gms_internal_zznq) {
        this.zzHQ = com_google_android_gms_internal_zznq;
    }

    public final void run() {
        if (zznq.zzb(this.zzHQ) != null) {
            zznq.zzb(this.zzHQ).zzet();
            zznq.zzb(this.zzHQ).zzeu();
        }
        zznq.zza(this.zzHQ, null);
    }
}
