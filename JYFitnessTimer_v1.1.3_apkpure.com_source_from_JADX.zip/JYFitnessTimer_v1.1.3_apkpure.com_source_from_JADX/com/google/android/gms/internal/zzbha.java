package com.google.android.gms.internal;

import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.Api.ApiOptions.NoOptions;
import com.google.android.gms.common.api.Api.zza;
import com.google.android.gms.common.api.Api.zzf;

public final class zzbha {
    public static final Api<NoOptions> API = new Api("Common.API", zzajU, zzajT);
    public static final zzbhc zzaIA = new zzbhd();
    public static final zzf<zzbhi> zzajT = new zzf();
    private static final zza<zzbhi, NoOptions> zzajU = new zzbhb();
}
