package com.google.android.gms.internal;

import android.annotation.TargetApi;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;

@TargetApi(11)
@zzaaz
public final class zzamq extends zzams {
    public zzamq(zzalm com_google_android_gms_internal_zzalm, boolean z) {
        super(com_google_android_gms_internal_zzalm, z);
    }

    public final WebResourceResponse shouldInterceptRequest(WebView webView, String str) {
        return zza(webView, str, null);
    }
}
