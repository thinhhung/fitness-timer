package com.google.android.gms.internal;

import android.content.SharedPreferences.Editor;
import android.support.annotation.WorkerThread;
import android.util.Pair;
import com.google.android.gms.common.internal.zzbr;

public final class zzchm {
    private final long zzaiD;
    private /* synthetic */ zzchi zzbrJ;
    private String zzbrL;
    private final String zzbrM;
    private final String zzbrN;

    private zzchm(zzchi com_google_android_gms_internal_zzchi, String str, long j) {
        this.zzbrJ = com_google_android_gms_internal_zzchi;
        zzbr.zzcF(str);
        zzbr.zzaf(j > 0);
        this.zzbrL = String.valueOf(str).concat(":start");
        this.zzbrM = String.valueOf(str).concat(":count");
        this.zzbrN = String.valueOf(str).concat(":value");
        this.zzaiD = j;
    }

    @WorkerThread
    private final void zzlY() {
        this.zzbrJ.zzjB();
        long currentTimeMillis = this.zzbrJ.zzkp().currentTimeMillis();
        Editor edit = this.zzbrJ.zzaiz.edit();
        edit.remove(this.zzbrM);
        edit.remove(this.zzbrN);
        edit.putLong(this.zzbrL, currentTimeMillis);
        edit.apply();
    }

    @WorkerThread
    private final long zzma() {
        return this.zzbrJ.zzyD().getLong(this.zzbrL, 0);
    }

    @WorkerThread
    public final void zzf(String str, long j) {
        this.zzbrJ.zzjB();
        if (zzma() == 0) {
            zzlY();
        }
        if (str == null) {
            str = "";
        }
        long j2 = this.zzbrJ.zzaiz.getLong(this.zzbrM, 0);
        if (j2 <= 0) {
            Editor edit = this.zzbrJ.zzaiz.edit();
            edit.putString(this.zzbrN, str);
            edit.putLong(this.zzbrM, 1);
            edit.apply();
            return;
        }
        Object obj = (this.zzbrJ.zzwA().zzzr().nextLong() & Long.MAX_VALUE) < Long.MAX_VALUE / (j2 + 1) ? 1 : null;
        Editor edit2 = this.zzbrJ.zzaiz.edit();
        if (obj != null) {
            edit2.putString(this.zzbrN, str);
        }
        edit2.putLong(this.zzbrM, j2 + 1);
        edit2.apply();
    }

    @WorkerThread
    public final Pair<String, Long> zzlZ() {
        this.zzbrJ.zzjB();
        this.zzbrJ.zzjB();
        long zzma = zzma();
        if (zzma == 0) {
            zzlY();
            zzma = 0;
        } else {
            zzma = Math.abs(zzma - this.zzbrJ.zzkp().currentTimeMillis());
        }
        if (zzma < this.zzaiD) {
            return null;
        }
        if (zzma > (this.zzaiD << 1)) {
            zzlY();
            return null;
        }
        String string = this.zzbrJ.zzyD().getString(this.zzbrN, null);
        long j = this.zzbrJ.zzyD().getLong(this.zzbrM, 0);
        zzlY();
        return (string == null || j <= 0) ? zzchi.zzbrm : new Pair(string, Long.valueOf(j));
    }
}
