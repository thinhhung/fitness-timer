package com.google.android.gms.internal;

import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import com.google.android.gms.ads.identifier.AdvertisingIdClient.Info;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

public class zzcr extends zzcs {
    private static final String TAG = zzcr.class.getSimpleName();
    private Info zzql;

    private zzcr(Context context) {
        super(context, "");
    }

    public static String zza(String str, String str2) {
        return zzbv.zza(str, str2, true);
    }

    public static zzcr zzb(Context context) {
        zzcs.zza(context, true);
        return new zzcr(context);
    }

    protected final zzax zza(Context context, View view) {
        return null;
    }

    public final void zza(Info info) {
        this.zzql = info;
    }

    protected final void zza(zzdb com_google_android_gms_internal_zzdb, zzax com_google_android_gms_internal_zzax, zzau com_google_android_gms_internal_zzau) {
        if (!com_google_android_gms_internal_zzdb.zzqS) {
            zzcs.zza(zzb(com_google_android_gms_internal_zzdb, com_google_android_gms_internal_zzax, com_google_android_gms_internal_zzau));
        } else if (this.zzql != null) {
            Object id = this.zzql.getId();
            if (!TextUtils.isEmpty(id)) {
                com_google_android_gms_internal_zzax.zzbX = zzdg.zzn(id);
                com_google_android_gms_internal_zzax.zzbY = Integer.valueOf(5);
                com_google_android_gms_internal_zzax.zzbZ = Boolean.valueOf(this.zzql.isLimitAdTrackingEnabled());
            }
            this.zzql = null;
        }
    }

    protected final List<Callable<Void>> zzb(zzdb com_google_android_gms_internal_zzdb, zzax com_google_android_gms_internal_zzax, zzau com_google_android_gms_internal_zzau) {
        List<Callable<Void>> arrayList = new ArrayList();
        if (com_google_android_gms_internal_zzdb.getExecutorService() == null) {
            return arrayList;
        }
        zzdb com_google_android_gms_internal_zzdb2 = com_google_android_gms_internal_zzdb;
        arrayList.add(new zzdp(com_google_android_gms_internal_zzdb2, "Ob9vkrYwqwLnJveTtaSWm/WWJCjo/9DRtOCY3btkKa6pJtjMu6sI0iK41HSh10io", "UrT94Dq3ubetC7rQ64nVjqMQ53po9X61geGgrP+ILCU=", com_google_android_gms_internal_zzax, com_google_android_gms_internal_zzdb.zzy(), 24));
        return arrayList;
    }
}
