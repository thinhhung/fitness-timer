package com.google.android.gms.internal;

public interface zzap {
    String zzg(String str);
}
