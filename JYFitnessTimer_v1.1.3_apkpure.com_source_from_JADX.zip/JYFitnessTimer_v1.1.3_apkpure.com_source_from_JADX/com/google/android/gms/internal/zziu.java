package com.google.android.gms.internal;

import android.content.Context;
import android.location.Location;
import android.os.Bundle;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.ads.search.SearchAdRequest;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;

@zzaaz
public final class zziu {
    public static final zziu zzAu = new zziu();

    protected zziu() {
    }

    public static zzir zza(Context context, zzla com_google_android_gms_internal_zzla) {
        Date birthday = com_google_android_gms_internal_zzla.getBirthday();
        long time = birthday != null ? birthday.getTime() : -1;
        String contentUrl = com_google_android_gms_internal_zzla.getContentUrl();
        int gender = com_google_android_gms_internal_zzla.getGender();
        Collection keywords = com_google_android_gms_internal_zzla.getKeywords();
        List unmodifiableList = !keywords.isEmpty() ? Collections.unmodifiableList(new ArrayList(keywords)) : null;
        boolean isTestDevice = com_google_android_gms_internal_zzla.isTestDevice(context);
        int zzdA = com_google_android_gms_internal_zzla.zzdA();
        Location location = com_google_android_gms_internal_zzla.getLocation();
        Bundle networkExtrasBundle = com_google_android_gms_internal_zzla.getNetworkExtrasBundle(AdMobAdapter.class);
        boolean manualImpressionsEnabled = com_google_android_gms_internal_zzla.getManualImpressionsEnabled();
        String publisherProvidedId = com_google_android_gms_internal_zzla.getPublisherProvidedId();
        SearchAdRequest zzdx = com_google_android_gms_internal_zzla.zzdx();
        zzlt com_google_android_gms_internal_zzlt = zzdx != null ? new zzlt(zzdx) : null;
        String str = null;
        Context applicationContext = context.getApplicationContext();
        if (applicationContext != null) {
            String packageName = applicationContext.getPackageName();
            zzji.zzdr();
            str = zzakk.zza(Thread.currentThread().getStackTrace(), packageName);
        }
        return new zzir(7, time, networkExtrasBundle, gender, unmodifiableList, isTestDevice, zzdA, manualImpressionsEnabled, publisherProvidedId, com_google_android_gms_internal_zzlt, location, contentUrl, com_google_android_gms_internal_zzla.zzdz(), com_google_android_gms_internal_zzla.getCustomTargeting(), Collections.unmodifiableList(new ArrayList(com_google_android_gms_internal_zzla.zzdB())), com_google_android_gms_internal_zzla.zzdw(), str, com_google_android_gms_internal_zzla.isDesignedForFamilies());
    }
}
