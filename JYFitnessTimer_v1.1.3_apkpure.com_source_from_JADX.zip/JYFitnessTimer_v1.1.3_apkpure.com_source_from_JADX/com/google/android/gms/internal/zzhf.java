package com.google.android.gms.internal;

import android.support.annotation.Nullable;
import io.fabric.sdk.android.services.common.CommonUtils;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@zzaaz
public abstract class zzhf {
    @Nullable
    private static MessageDigest zzyZ = null;
    protected Object mLock = new Object();

    @Nullable
    protected final MessageDigest zzcV() {
        MessageDigest messageDigest;
        synchronized (this.mLock) {
            if (zzyZ != null) {
                messageDigest = zzyZ;
            } else {
                for (int i = 0; i < 2; i++) {
                    try {
                        zzyZ = MessageDigest.getInstance(CommonUtils.MD5_INSTANCE);
                    } catch (NoSuchAlgorithmException e) {
                    }
                }
                messageDigest = zzyZ;
            }
        }
        return messageDigest;
    }

    abstract byte[] zzy(String str);
}
