package com.google.android.gms.internal;

import java.util.HashMap;

public final class zzdf extends zzbs<Integer, Long> {
    public Long zzce;
    public Long zzcg;
    public Long zzck;
    public Long zzcl;
    public Long zzrc;
    public Long zzrd;
    public Long zzre;
    public Long zzrf;
    public Long zzrg;
    public Long zzrh;
    public Long zzri;
    public Long zzrj;
    public Long zzrk;

    public zzdf(String str) {
        zzi(str);
    }

    protected final void zzi(String str) {
        HashMap zzj = zzbs.zzj(str);
        if (zzj != null) {
            this.zzrc = (Long) zzj.get(Integer.valueOf(0));
            this.zzrd = (Long) zzj.get(Integer.valueOf(1));
            this.zzre = (Long) zzj.get(Integer.valueOf(2));
            this.zzcg = (Long) zzj.get(Integer.valueOf(3));
            this.zzce = (Long) zzj.get(Integer.valueOf(4));
            this.zzrf = (Long) zzj.get(Integer.valueOf(5));
            this.zzrg = (Long) zzj.get(Integer.valueOf(6));
            this.zzrh = (Long) zzj.get(Integer.valueOf(7));
            this.zzcl = (Long) zzj.get(Integer.valueOf(8));
            this.zzck = (Long) zzj.get(Integer.valueOf(9));
            this.zzri = (Long) zzj.get(Integer.valueOf(10));
            this.zzrj = (Long) zzj.get(Integer.valueOf(11));
            this.zzrk = (Long) zzj.get(Integer.valueOf(12));
        }
    }

    protected final HashMap<Integer, Long> zzv() {
        HashMap<Integer, Long> hashMap = new HashMap();
        hashMap.put(Integer.valueOf(0), this.zzrc);
        hashMap.put(Integer.valueOf(1), this.zzrd);
        hashMap.put(Integer.valueOf(2), this.zzre);
        hashMap.put(Integer.valueOf(3), this.zzcg);
        hashMap.put(Integer.valueOf(4), this.zzce);
        hashMap.put(Integer.valueOf(5), this.zzrf);
        hashMap.put(Integer.valueOf(6), this.zzrg);
        hashMap.put(Integer.valueOf(7), this.zzrh);
        hashMap.put(Integer.valueOf(8), this.zzcl);
        hashMap.put(Integer.valueOf(9), this.zzck);
        hashMap.put(Integer.valueOf(10), this.zzri);
        hashMap.put(Integer.valueOf(11), this.zzrj);
        hashMap.put(Integer.valueOf(12), this.zzrk);
        return hashMap;
    }
}
