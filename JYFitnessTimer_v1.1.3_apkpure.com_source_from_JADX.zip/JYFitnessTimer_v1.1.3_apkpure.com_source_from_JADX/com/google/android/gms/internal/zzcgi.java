package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzd;
import java.util.Iterator;

public final class zzcgi extends zza implements Iterable<String> {
    public static final Creator<zzcgi> CREATOR = new zzcgk();
    private final Bundle zzbpN;

    zzcgi(Bundle bundle) {
        this.zzbpN = bundle;
    }

    final Object get(String str) {
        return this.zzbpN.get(str);
    }

    public final Iterator<String> iterator() {
        return new zzcgj(this);
    }

    public final int size() {
        return this.zzbpN.size();
    }

    public final String toString() {
        return this.zzbpN.toString();
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int zze = zzd.zze(parcel);
        zzd.zza(parcel, 2, zzyr(), false);
        zzd.zzI(parcel, zze);
    }

    public final Bundle zzyr() {
        return new Bundle(this.zzbpN);
    }
}
