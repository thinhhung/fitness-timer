package com.google.android.gms.internal;

import java.io.IOException;

public final class zzaw extends ahz<zzaw> {
    public String zzaW;
    private String zzaX;
    private String zzaY;
    private String zzaZ;
    private String zzba;

    public zzaw() {
        this.zzaW = null;
        this.zzaX = null;
        this.zzaY = null;
        this.zzaZ = null;
        this.zzba = null;
        this.zzcvf = -1;
    }

    public final /* synthetic */ aif zza(ahw com_google_android_gms_internal_ahw) throws IOException {
        while (true) {
            int zzLQ = com_google_android_gms_internal_ahw.zzLQ();
            switch (zzLQ) {
                case 0:
                    break;
                case 10:
                    this.zzaW = com_google_android_gms_internal_ahw.readString();
                    continue;
                case 18:
                    this.zzaX = com_google_android_gms_internal_ahw.readString();
                    continue;
                case 26:
                    this.zzaY = com_google_android_gms_internal_ahw.readString();
                    continue;
                case 34:
                    this.zzaZ = com_google_android_gms_internal_ahw.readString();
                    continue;
                case 42:
                    this.zzba = com_google_android_gms_internal_ahw.readString();
                    continue;
                default:
                    if (!super.zza(com_google_android_gms_internal_ahw, zzLQ)) {
                        break;
                    }
                    continue;
            }
            return this;
        }
    }

    public final void zza(ahx com_google_android_gms_internal_ahx) throws IOException {
        if (this.zzaW != null) {
            com_google_android_gms_internal_ahx.zzl(1, this.zzaW);
        }
        if (this.zzaX != null) {
            com_google_android_gms_internal_ahx.zzl(2, this.zzaX);
        }
        if (this.zzaY != null) {
            com_google_android_gms_internal_ahx.zzl(3, this.zzaY);
        }
        if (this.zzaZ != null) {
            com_google_android_gms_internal_ahx.zzl(4, this.zzaZ);
        }
        if (this.zzba != null) {
            com_google_android_gms_internal_ahx.zzl(5, this.zzba);
        }
        super.zza(com_google_android_gms_internal_ahx);
    }

    protected final int zzn() {
        int zzn = super.zzn();
        if (this.zzaW != null) {
            zzn += ahx.zzm(1, this.zzaW);
        }
        if (this.zzaX != null) {
            zzn += ahx.zzm(2, this.zzaX);
        }
        if (this.zzaY != null) {
            zzn += ahx.zzm(3, this.zzaY);
        }
        if (this.zzaZ != null) {
            zzn += ahx.zzm(4, this.zzaZ);
        }
        return this.zzba != null ? zzn + ahx.zzm(5, this.zzba) : zzn;
    }
}
