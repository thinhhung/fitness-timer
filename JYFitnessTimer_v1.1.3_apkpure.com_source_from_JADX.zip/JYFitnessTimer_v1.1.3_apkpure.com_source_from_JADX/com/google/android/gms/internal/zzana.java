package com.google.android.gms.internal;

import com.google.android.gms.analytics.zzj;
import com.google.android.gms.common.internal.zzbr;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public final class zzana extends zzj<zzana> {
    private final Map<String, Object> zzHd = new HashMap();

    public final void set(String str, String str2) {
        zzbr.zzcF(str);
        if (str != null && str.startsWith("&")) {
            str = str.substring(1);
        }
        zzbr.zzh(str, "Name can not be empty or \"&\"");
        this.zzHd.put(str, str2);
    }

    public final String toString() {
        return zzj.zzh(this.zzHd);
    }

    public final /* synthetic */ void zzb(zzj com_google_android_gms_analytics_zzj) {
        zzana com_google_android_gms_internal_zzana = (zzana) com_google_android_gms_analytics_zzj;
        zzbr.zzu(com_google_android_gms_internal_zzana);
        com_google_android_gms_internal_zzana.zzHd.putAll(this.zzHd);
    }

    public final Map<String, Object> zzjQ() {
        return Collections.unmodifiableMap(this.zzHd);
    }
}
