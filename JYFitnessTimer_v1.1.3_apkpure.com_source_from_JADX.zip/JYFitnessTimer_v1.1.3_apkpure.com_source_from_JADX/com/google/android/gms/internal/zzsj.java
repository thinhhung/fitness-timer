package com.google.android.gms.internal;

import android.os.Handler;
import java.util.LinkedList;
import java.util.List;

@zzaaz
final class zzsj {
    private final List<zzth> zztK = new LinkedList();

    zzsj() {
    }

    final void zza(zzti com_google_android_gms_internal_zzti) {
        Handler handler = zzail.zzZt;
        for (zzth com_google_android_gms_internal_zztg : this.zztK) {
            handler.post(new zztg(this, com_google_android_gms_internal_zztg, com_google_android_gms_internal_zzti));
        }
        this.zztK.clear();
    }
}
