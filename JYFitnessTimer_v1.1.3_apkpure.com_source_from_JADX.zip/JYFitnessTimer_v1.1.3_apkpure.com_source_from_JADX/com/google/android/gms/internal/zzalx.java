package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.zzbl;
import com.google.android.gms.ads.internal.zzbs;
import com.google.android.gms.ads.internal.zzv;
import java.util.concurrent.Callable;

final class zzalx implements Callable<zzalm> {
    private /* synthetic */ zziv zzAJ;
    private /* synthetic */ zzakq zzKR;
    private /* synthetic */ zzv zzKT;
    private /* synthetic */ zzcu zzLk;
    private /* synthetic */ boolean zzabN;
    private /* synthetic */ boolean zzabO;
    private /* synthetic */ zznb zzabP;
    private /* synthetic */ zzbl zzabQ;
    private /* synthetic */ zzig zzabR;
    private /* synthetic */ Context zztI;

    zzalx(zzalw com_google_android_gms_internal_zzalw, Context context, zziv com_google_android_gms_internal_zziv, boolean z, boolean z2, zzcu com_google_android_gms_internal_zzcu, zzakq com_google_android_gms_internal_zzakq, zznb com_google_android_gms_internal_zznb, zzbl com_google_android_gms_ads_internal_zzbl, zzv com_google_android_gms_ads_internal_zzv, zzig com_google_android_gms_internal_zzig) {
        this.zztI = context;
        this.zzAJ = com_google_android_gms_internal_zziv;
        this.zzabN = z;
        this.zzabO = z2;
        this.zzLk = com_google_android_gms_internal_zzcu;
        this.zzKR = com_google_android_gms_internal_zzakq;
        this.zzabP = com_google_android_gms_internal_zznb;
        this.zzabQ = com_google_android_gms_ads_internal_zzbl;
        this.zzKT = com_google_android_gms_ads_internal_zzv;
        this.zzabR = com_google_android_gms_internal_zzig;
    }

    public final /* synthetic */ Object call() throws Exception {
        zzalm com_google_android_gms_internal_zzalz = new zzalz(zzama.zzb(this.zztI, this.zzAJ, this.zzabN, this.zzabO, this.zzLk, this.zzKR, this.zzabP, this.zzabQ, this.zzKT, this.zzabR));
        com_google_android_gms_internal_zzalz.setWebViewClient(zzbs.zzbA().zzb(com_google_android_gms_internal_zzalz, this.zzabO));
        com_google_android_gms_internal_zzalz.setWebChromeClient(zzbs.zzbA().zzm(com_google_android_gms_internal_zzalz));
        return com_google_android_gms_internal_zzalz;
    }
}
