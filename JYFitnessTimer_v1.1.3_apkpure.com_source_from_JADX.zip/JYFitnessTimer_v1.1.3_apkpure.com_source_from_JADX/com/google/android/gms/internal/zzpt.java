package com.google.android.gms.internal;

import android.os.IInterface;
import android.os.RemoteException;

public interface zzpt extends IInterface {
    void zzb(zzpj com_google_android_gms_internal_zzpj, String str) throws RemoteException;
}
