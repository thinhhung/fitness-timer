package com.google.android.gms.internal;

import java.io.IOException;

public final class agd extends ahz<agd> {
    public int zzcqB;
    public boolean zzcqC;
    public long zzcqD;

    public agd() {
        this.zzcqB = 0;
        this.zzcqC = false;
        this.zzcqD = 0;
        this.zzcuW = null;
        this.zzcvf = -1;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof agd)) {
            return false;
        }
        agd com_google_android_gms_internal_agd = (agd) obj;
        return this.zzcqB != com_google_android_gms_internal_agd.zzcqB ? false : this.zzcqC != com_google_android_gms_internal_agd.zzcqC ? false : this.zzcqD != com_google_android_gms_internal_agd.zzcqD ? false : (this.zzcuW == null || this.zzcuW.isEmpty()) ? com_google_android_gms_internal_agd.zzcuW == null || com_google_android_gms_internal_agd.zzcuW.isEmpty() : this.zzcuW.equals(com_google_android_gms_internal_agd.zzcuW);
    }

    public final int hashCode() {
        int hashCode = ((((this.zzcqC ? 1231 : 1237) + ((((getClass().getName().hashCode() + 527) * 31) + this.zzcqB) * 31)) * 31) + ((int) (this.zzcqD ^ (this.zzcqD >>> 32)))) * 31;
        int hashCode2 = (this.zzcuW == null || this.zzcuW.isEmpty()) ? 0 : this.zzcuW.hashCode();
        return hashCode2 + hashCode;
    }

    public final /* synthetic */ aif zza(ahw com_google_android_gms_internal_ahw) throws IOException {
        while (true) {
            int zzLQ = com_google_android_gms_internal_ahw.zzLQ();
            switch (zzLQ) {
                case 0:
                    break;
                case 8:
                    this.zzcqB = com_google_android_gms_internal_ahw.zzLV();
                    continue;
                case 16:
                    this.zzcqC = com_google_android_gms_internal_ahw.zzLT();
                    continue;
                case 25:
                    this.zzcqD = com_google_android_gms_internal_ahw.zzLY();
                    continue;
                default:
                    if (!super.zza(com_google_android_gms_internal_ahw, zzLQ)) {
                        break;
                    }
                    continue;
            }
            return this;
        }
    }

    public final void zza(ahx com_google_android_gms_internal_ahx) throws IOException {
        if (this.zzcqB != 0) {
            com_google_android_gms_internal_ahx.zzr(1, this.zzcqB);
        }
        if (this.zzcqC) {
            com_google_android_gms_internal_ahx.zzk(2, this.zzcqC);
        }
        if (this.zzcqD != 0) {
            com_google_android_gms_internal_ahx.zzc(3, this.zzcqD);
        }
        super.zza(com_google_android_gms_internal_ahx);
    }

    protected final int zzn() {
        int zzn = super.zzn();
        if (this.zzcqB != 0) {
            zzn += ahx.zzs(1, this.zzcqB);
        }
        if (this.zzcqC) {
            zzn += ahx.zzcs(2) + 1;
        }
        return this.zzcqD != 0 ? zzn + (ahx.zzcs(3) + 8) : zzn;
    }
}
