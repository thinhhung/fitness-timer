package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzd;
import com.google.android.gms.common.internal.zzbr;

public final class zzcku extends zza {
    public static final Creator<zzcku> CREATOR = new zzckv();
    public final String name;
    private int versionCode;
    private String zzaIH;
    public final String zzbpg;
    public final long zzbuC;
    private Long zzbuD;
    private Float zzbuE;
    private Double zzbuF;

    zzcku(int i, String str, long j, Long l, Float f, String str2, String str3, Double d) {
        Double d2 = null;
        this.versionCode = i;
        this.name = str;
        this.zzbuC = j;
        this.zzbuD = l;
        this.zzbuE = null;
        if (i == 1) {
            if (f != null) {
                d2 = Double.valueOf(f.doubleValue());
            }
            this.zzbuF = d2;
        } else {
            this.zzbuF = d;
        }
        this.zzaIH = str2;
        this.zzbpg = str3;
    }

    zzcku(zzckw com_google_android_gms_internal_zzckw) {
        this(com_google_android_gms_internal_zzckw.mName, com_google_android_gms_internal_zzckw.zzbuG, com_google_android_gms_internal_zzckw.mValue, com_google_android_gms_internal_zzckw.mOrigin);
    }

    zzcku(String str, long j, Object obj, String str2) {
        zzbr.zzcF(str);
        this.versionCode = 2;
        this.name = str;
        this.zzbuC = j;
        this.zzbpg = str2;
        if (obj == null) {
            this.zzbuD = null;
            this.zzbuE = null;
            this.zzbuF = null;
            this.zzaIH = null;
        } else if (obj instanceof Long) {
            this.zzbuD = (Long) obj;
            this.zzbuE = null;
            this.zzbuF = null;
            this.zzaIH = null;
        } else if (obj instanceof String) {
            this.zzbuD = null;
            this.zzbuE = null;
            this.zzbuF = null;
            this.zzaIH = (String) obj;
        } else if (obj instanceof Double) {
            this.zzbuD = null;
            this.zzbuE = null;
            this.zzbuF = (Double) obj;
            this.zzaIH = null;
        } else {
            throw new IllegalArgumentException("User attribute given of un-supported type");
        }
    }

    public final Object getValue() {
        return this.zzbuD != null ? this.zzbuD : this.zzbuF != null ? this.zzbuF : this.zzaIH != null ? this.zzaIH : null;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int zze = zzd.zze(parcel);
        zzd.zzc(parcel, 1, this.versionCode);
        zzd.zza(parcel, 2, this.name, false);
        zzd.zza(parcel, 3, this.zzbuC);
        zzd.zza(parcel, 4, this.zzbuD, false);
        zzd.zza(parcel, 5, null, false);
        zzd.zza(parcel, 6, this.zzaIH, false);
        zzd.zza(parcel, 7, this.zzbpg, false);
        zzd.zza(parcel, 8, this.zzbuF, false);
        zzd.zzI(parcel, zze);
    }
}
