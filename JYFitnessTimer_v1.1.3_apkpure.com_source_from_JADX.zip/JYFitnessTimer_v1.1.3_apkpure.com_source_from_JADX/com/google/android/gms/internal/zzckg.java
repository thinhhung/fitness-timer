package com.google.android.gms.internal;

import android.content.ComponentName;
import android.content.Context;

final class zzckg implements Runnable {
    private /* synthetic */ zzckc zzbuo;

    zzckg(zzckc com_google_android_gms_internal_zzckc) {
        this.zzbuo = com_google_android_gms_internal_zzckc;
    }

    public final void run() {
        zzcjp com_google_android_gms_internal_zzcjp = this.zzbuo.zzbue;
        Context context = this.zzbuo.zzbue.getContext();
        zzcfy.zzxD();
        com_google_android_gms_internal_zzcjp.onServiceDisconnected(new ComponentName(context, "com.google.android.gms.measurement.AppMeasurementService"));
    }
}
