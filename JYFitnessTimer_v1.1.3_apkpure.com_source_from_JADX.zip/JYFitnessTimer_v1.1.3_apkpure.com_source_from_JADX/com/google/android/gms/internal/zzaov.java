package com.google.android.gms.internal;

public interface zzaov<U extends zzaot> {
    void zzd(String str, int i);

    void zze(String str, boolean z);

    void zzl(String str, String str2);

    U zzll();

    void zzm(String str, String str2);
}
