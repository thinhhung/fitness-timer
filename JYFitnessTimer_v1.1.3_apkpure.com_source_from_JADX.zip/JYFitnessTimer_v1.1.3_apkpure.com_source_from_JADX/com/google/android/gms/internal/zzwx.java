package com.google.android.gms.internal;

import com.google.android.gms.ads.formats.NativeCustomTemplateAd;
import com.google.android.gms.ads.mediation.MediationBannerAdapter;
import com.google.android.gms.ads.mediation.MediationBannerListener;
import com.google.android.gms.ads.mediation.MediationInterstitialAdapter;
import com.google.android.gms.ads.mediation.MediationInterstitialListener;
import com.google.android.gms.ads.mediation.MediationNativeAdapter;
import com.google.android.gms.ads.mediation.MediationNativeListener;
import com.google.android.gms.ads.mediation.NativeAdMapper;
import com.google.android.gms.common.internal.zzbr;

@zzaaz
public final class zzwx implements MediationBannerListener, MediationInterstitialListener, MediationNativeListener {
    private final zzwj zzNg;
    private NativeAdMapper zzNh;
    private NativeCustomTemplateAd zzNi;

    public zzwx(zzwj com_google_android_gms_internal_zzwj) {
        this.zzNg = com_google_android_gms_internal_zzwj;
    }

    public final void onAdClicked(MediationBannerAdapter mediationBannerAdapter) {
        zzbr.zzcz("onAdClicked must be called on the main UI thread.");
        zzako.zzaC("Adapter called onAdClicked.");
        try {
            this.zzNg.onAdClicked();
        } catch (Throwable e) {
            zzako.zzc("Could not call onAdClicked.", e);
        }
    }

    public final void onAdClicked(MediationInterstitialAdapter mediationInterstitialAdapter) {
        zzbr.zzcz("onAdClicked must be called on the main UI thread.");
        zzako.zzaC("Adapter called onAdClicked.");
        try {
            this.zzNg.onAdClicked();
        } catch (Throwable e) {
            zzako.zzc("Could not call onAdClicked.", e);
        }
    }

    public final void onAdClicked(MediationNativeAdapter mediationNativeAdapter) {
        zzbr.zzcz("onAdClicked must be called on the main UI thread.");
        NativeAdMapper nativeAdMapper = this.zzNh;
        if (this.zzNi == null) {
            if (nativeAdMapper == null) {
                zzako.zzaT("Could not call onAdClicked since NativeAdMapper is null.");
                return;
            } else if (!nativeAdMapper.getOverrideClickHandling()) {
                zzako.zzaC("Could not call onAdClicked since setOverrideClickHandling is not set to true");
                return;
            }
        }
        zzako.zzaC("Adapter called onAdClicked.");
        try {
            this.zzNg.onAdClicked();
        } catch (Throwable e) {
            zzako.zzc("Could not call onAdClicked.", e);
        }
    }

    public final void onAdClosed(MediationBannerAdapter mediationBannerAdapter) {
        zzbr.zzcz("onAdClosed must be called on the main UI thread.");
        zzako.zzaC("Adapter called onAdClosed.");
        try {
            this.zzNg.onAdClosed();
        } catch (Throwable e) {
            zzako.zzc("Could not call onAdClosed.", e);
        }
    }

    public final void onAdClosed(MediationInterstitialAdapter mediationInterstitialAdapter) {
        zzbr.zzcz("onAdClosed must be called on the main UI thread.");
        zzako.zzaC("Adapter called onAdClosed.");
        try {
            this.zzNg.onAdClosed();
        } catch (Throwable e) {
            zzako.zzc("Could not call onAdClosed.", e);
        }
    }

    public final void onAdClosed(MediationNativeAdapter mediationNativeAdapter) {
        zzbr.zzcz("onAdClosed must be called on the main UI thread.");
        zzako.zzaC("Adapter called onAdClosed.");
        try {
            this.zzNg.onAdClosed();
        } catch (Throwable e) {
            zzako.zzc("Could not call onAdClosed.", e);
        }
    }

    public final void onAdFailedToLoad(MediationBannerAdapter mediationBannerAdapter, int i) {
        zzbr.zzcz("onAdFailedToLoad must be called on the main UI thread.");
        zzako.zzaC("Adapter called onAdFailedToLoad with error. " + i);
        try {
            this.zzNg.onAdFailedToLoad(i);
        } catch (Throwable e) {
            zzako.zzc("Could not call onAdFailedToLoad.", e);
        }
    }

    public final void onAdFailedToLoad(MediationInterstitialAdapter mediationInterstitialAdapter, int i) {
        zzbr.zzcz("onAdFailedToLoad must be called on the main UI thread.");
        zzako.zzaC("Adapter called onAdFailedToLoad with error " + i + ".");
        try {
            this.zzNg.onAdFailedToLoad(i);
        } catch (Throwable e) {
            zzako.zzc("Could not call onAdFailedToLoad.", e);
        }
    }

    public final void onAdFailedToLoad(MediationNativeAdapter mediationNativeAdapter, int i) {
        zzbr.zzcz("onAdFailedToLoad must be called on the main UI thread.");
        zzako.zzaC("Adapter called onAdFailedToLoad with error " + i + ".");
        try {
            this.zzNg.onAdFailedToLoad(i);
        } catch (Throwable e) {
            zzako.zzc("Could not call onAdFailedToLoad.", e);
        }
    }

    public final void onAdImpression(MediationNativeAdapter mediationNativeAdapter) {
        zzbr.zzcz("onAdImpression must be called on the main UI thread.");
        NativeAdMapper nativeAdMapper = this.zzNh;
        if (this.zzNi == null) {
            if (nativeAdMapper == null) {
                zzako.zzaT("Could not call onAdImpression since NativeAdMapper is null. ");
                return;
            } else if (!nativeAdMapper.getOverrideImpressionRecording()) {
                zzako.zzaC("Could not call onAdImpression since setOverrideImpressionRecording is not set to true");
                return;
            }
        }
        zzako.zzaC("Adapter called onAdImpression.");
        try {
            this.zzNg.onAdImpression();
        } catch (Throwable e) {
            zzako.zzc("Could not call onAdImpression.", e);
        }
    }

    public final void onAdLeftApplication(MediationBannerAdapter mediationBannerAdapter) {
        zzbr.zzcz("onAdLeftApplication must be called on the main UI thread.");
        zzako.zzaC("Adapter called onAdLeftApplication.");
        try {
            this.zzNg.onAdLeftApplication();
        } catch (Throwable e) {
            zzako.zzc("Could not call onAdLeftApplication.", e);
        }
    }

    public final void onAdLeftApplication(MediationInterstitialAdapter mediationInterstitialAdapter) {
        zzbr.zzcz("onAdLeftApplication must be called on the main UI thread.");
        zzako.zzaC("Adapter called onAdLeftApplication.");
        try {
            this.zzNg.onAdLeftApplication();
        } catch (Throwable e) {
            zzako.zzc("Could not call onAdLeftApplication.", e);
        }
    }

    public final void onAdLeftApplication(MediationNativeAdapter mediationNativeAdapter) {
        zzbr.zzcz("onAdLeftApplication must be called on the main UI thread.");
        zzako.zzaC("Adapter called onAdLeftApplication.");
        try {
            this.zzNg.onAdLeftApplication();
        } catch (Throwable e) {
            zzako.zzc("Could not call onAdLeftApplication.", e);
        }
    }

    public final void onAdLoaded(MediationBannerAdapter mediationBannerAdapter) {
        zzbr.zzcz("onAdLoaded must be called on the main UI thread.");
        zzako.zzaC("Adapter called onAdLoaded.");
        try {
            this.zzNg.onAdLoaded();
        } catch (Throwable e) {
            zzako.zzc("Could not call onAdLoaded.", e);
        }
    }

    public final void onAdLoaded(MediationInterstitialAdapter mediationInterstitialAdapter) {
        zzbr.zzcz("onAdLoaded must be called on the main UI thread.");
        zzako.zzaC("Adapter called onAdLoaded.");
        try {
            this.zzNg.onAdLoaded();
        } catch (Throwable e) {
            zzako.zzc("Could not call onAdLoaded.", e);
        }
    }

    public final void onAdLoaded(MediationNativeAdapter mediationNativeAdapter, NativeAdMapper nativeAdMapper) {
        zzbr.zzcz("onAdLoaded must be called on the main UI thread.");
        zzako.zzaC("Adapter called onAdLoaded.");
        this.zzNh = nativeAdMapper;
        try {
            this.zzNg.onAdLoaded();
        } catch (Throwable e) {
            zzako.zzc("Could not call onAdLoaded.", e);
        }
    }

    public final void onAdOpened(MediationBannerAdapter mediationBannerAdapter) {
        zzbr.zzcz("onAdOpened must be called on the main UI thread.");
        zzako.zzaC("Adapter called onAdOpened.");
        try {
            this.zzNg.onAdOpened();
        } catch (Throwable e) {
            zzako.zzc("Could not call onAdOpened.", e);
        }
    }

    public final void onAdOpened(MediationInterstitialAdapter mediationInterstitialAdapter) {
        zzbr.zzcz("onAdOpened must be called on the main UI thread.");
        zzako.zzaC("Adapter called onAdOpened.");
        try {
            this.zzNg.onAdOpened();
        } catch (Throwable e) {
            zzako.zzc("Could not call onAdOpened.", e);
        }
    }

    public final void onAdOpened(MediationNativeAdapter mediationNativeAdapter) {
        zzbr.zzcz("onAdOpened must be called on the main UI thread.");
        zzako.zzaC("Adapter called onAdOpened.");
        try {
            this.zzNg.onAdOpened();
        } catch (Throwable e) {
            zzako.zzc("Could not call onAdOpened.", e);
        }
    }

    public final void zza(MediationBannerAdapter mediationBannerAdapter, String str, String str2) {
        zzbr.zzcz("onAppEvent must be called on the main UI thread.");
        zzako.zzaC("Adapter called onAppEvent.");
        try {
            this.zzNg.onAppEvent(str, str2);
        } catch (Throwable e) {
            zzako.zzc("Could not call onAppEvent.", e);
        }
    }

    public final void zza(MediationNativeAdapter mediationNativeAdapter, NativeCustomTemplateAd nativeCustomTemplateAd) {
        zzbr.zzcz("onAdLoaded must be called on the main UI thread.");
        String str = "Adapter called onAdLoaded with template id ";
        String valueOf = String.valueOf(nativeCustomTemplateAd.getCustomTemplateId());
        zzako.zzaC(valueOf.length() != 0 ? str.concat(valueOf) : new String(str));
        this.zzNi = nativeCustomTemplateAd;
        try {
            this.zzNg.onAdLoaded();
        } catch (Throwable e) {
            zzako.zzc("Could not call onAdLoaded.", e);
        }
    }

    public final void zza(MediationNativeAdapter mediationNativeAdapter, NativeCustomTemplateAd nativeCustomTemplateAd, String str) {
        if (nativeCustomTemplateAd instanceof zzpm) {
            try {
                this.zzNg.zzb(((zzpm) nativeCustomTemplateAd).zzew(), str);
                return;
            } catch (Throwable e) {
                zzako.zzc("Could not call onCustomClick.", e);
                return;
            }
        }
        zzako.zzaT("Unexpected native custom template ad type.");
    }

    public final NativeAdMapper zzfw() {
        return this.zzNh;
    }

    public final NativeCustomTemplateAd zzfx() {
        return this.zzNi;
    }
}
