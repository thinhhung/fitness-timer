package com.google.android.gms.internal;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

final class zzgg extends BroadcastReceiver {
    private /* synthetic */ zzge zzxJ;

    zzgg(zzge com_google_android_gms_internal_zzge) {
        this.zzxJ = com_google_android_gms_internal_zzge;
    }

    public final void onReceive(Context context, Intent intent) {
        zzge.zza(this.zzxJ, 3);
    }
}
