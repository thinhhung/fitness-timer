package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.zzal;
import com.google.android.gms.ads.internal.zzv;

@zzaaz
public final class zzsi {
    private final Context mContext;
    private final zzv zzsV;
    private final zzakq zztZ;
    private final zzwd zzta;

    zzsi(Context context, zzwd com_google_android_gms_internal_zzwd, zzakq com_google_android_gms_internal_zzakq, zzv com_google_android_gms_ads_internal_zzv) {
        this.mContext = context;
        this.zzta = com_google_android_gms_internal_zzwd;
        this.zztZ = com_google_android_gms_internal_zzakq;
        this.zzsV = com_google_android_gms_ads_internal_zzv;
    }

    public final Context getApplicationContext() {
        return this.mContext.getApplicationContext();
    }

    public final zzal zzW(String str) {
        return new zzal(this.mContext, new zziv(), str, this.zzta, this.zztZ, this.zzsV);
    }

    public final zzal zzX(String str) {
        return new zzal(this.mContext.getApplicationContext(), new zziv(), str, this.zzta, this.zztZ, this.zzsV);
    }

    public final zzsi zzeE() {
        return new zzsi(this.mContext.getApplicationContext(), this.zzta, this.zztZ, this.zzsV);
    }
}
