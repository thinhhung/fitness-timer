package com.google.android.gms.internal;

import android.location.Location;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzd;
import com.google.android.gms.common.internal.zzbh;
import java.util.Arrays;
import java.util.List;

@zzaaz
public final class zzir extends zza {
    public static final Creator<zzir> CREATOR = new zzit();
    public final Bundle extras;
    public final int versionCode;
    public final Bundle zzAa;
    public final Bundle zzAb;
    public final List<String> zzAc;
    public final String zzAd;
    public final String zzAe;
    public final boolean zzAf;
    public final long zzzQ;
    public final int zzzR;
    public final List<String> zzzS;
    public final boolean zzzT;
    public final int zzzU;
    public final boolean zzzV;
    public final String zzzW;
    public final zzlt zzzX;
    public final Location zzzY;
    public final String zzzZ;

    public zzir(int i, long j, Bundle bundle, int i2, List<String> list, boolean z, int i3, boolean z2, String str, zzlt com_google_android_gms_internal_zzlt, Location location, String str2, Bundle bundle2, Bundle bundle3, List<String> list2, String str3, String str4, boolean z3) {
        this.versionCode = i;
        this.zzzQ = j;
        if (bundle == null) {
            bundle = new Bundle();
        }
        this.extras = bundle;
        this.zzzR = i2;
        this.zzzS = list;
        this.zzzT = z;
        this.zzzU = i3;
        this.zzzV = z2;
        this.zzzW = str;
        this.zzzX = com_google_android_gms_internal_zzlt;
        this.zzzY = location;
        this.zzzZ = str2;
        if (bundle2 == null) {
            bundle2 = new Bundle();
        }
        this.zzAa = bundle2;
        this.zzAb = bundle3;
        this.zzAc = list2;
        this.zzAd = str3;
        this.zzAe = str4;
        this.zzAf = z3;
    }

    public static void zzh(zzir com_google_android_gms_internal_zzir) {
        com_google_android_gms_internal_zzir.zzAa.putBundle("com.google.ads.mediation.admob.AdMobAdapter", com_google_android_gms_internal_zzir.extras);
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof zzir)) {
            return false;
        }
        zzir com_google_android_gms_internal_zzir = (zzir) obj;
        return this.versionCode == com_google_android_gms_internal_zzir.versionCode && this.zzzQ == com_google_android_gms_internal_zzir.zzzQ && zzbh.equal(this.extras, com_google_android_gms_internal_zzir.extras) && this.zzzR == com_google_android_gms_internal_zzir.zzzR && zzbh.equal(this.zzzS, com_google_android_gms_internal_zzir.zzzS) && this.zzzT == com_google_android_gms_internal_zzir.zzzT && this.zzzU == com_google_android_gms_internal_zzir.zzzU && this.zzzV == com_google_android_gms_internal_zzir.zzzV && zzbh.equal(this.zzzW, com_google_android_gms_internal_zzir.zzzW) && zzbh.equal(this.zzzX, com_google_android_gms_internal_zzir.zzzX) && zzbh.equal(this.zzzY, com_google_android_gms_internal_zzir.zzzY) && zzbh.equal(this.zzzZ, com_google_android_gms_internal_zzir.zzzZ) && zzbh.equal(this.zzAa, com_google_android_gms_internal_zzir.zzAa) && zzbh.equal(this.zzAb, com_google_android_gms_internal_zzir.zzAb) && zzbh.equal(this.zzAc, com_google_android_gms_internal_zzir.zzAc) && zzbh.equal(this.zzAd, com_google_android_gms_internal_zzir.zzAd) && zzbh.equal(this.zzAe, com_google_android_gms_internal_zzir.zzAe) && this.zzAf == com_google_android_gms_internal_zzir.zzAf;
    }

    public final int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.versionCode), Long.valueOf(this.zzzQ), this.extras, Integer.valueOf(this.zzzR), this.zzzS, Boolean.valueOf(this.zzzT), Integer.valueOf(this.zzzU), Boolean.valueOf(this.zzzV), this.zzzW, this.zzzX, this.zzzY, this.zzzZ, this.zzAa, this.zzAb, this.zzAc, this.zzAd, this.zzAe, Boolean.valueOf(this.zzAf)});
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int zze = zzd.zze(parcel);
        zzd.zzc(parcel, 1, this.versionCode);
        zzd.zza(parcel, 2, this.zzzQ);
        zzd.zza(parcel, 3, this.extras, false);
        zzd.zzc(parcel, 4, this.zzzR);
        zzd.zzb(parcel, 5, this.zzzS, false);
        zzd.zza(parcel, 6, this.zzzT);
        zzd.zzc(parcel, 7, this.zzzU);
        zzd.zza(parcel, 8, this.zzzV);
        zzd.zza(parcel, 9, this.zzzW, false);
        zzd.zza(parcel, 10, this.zzzX, i, false);
        zzd.zza(parcel, 11, this.zzzY, i, false);
        zzd.zza(parcel, 12, this.zzzZ, false);
        zzd.zza(parcel, 13, this.zzAa, false);
        zzd.zza(parcel, 14, this.zzAb, false);
        zzd.zzb(parcel, 15, this.zzAc, false);
        zzd.zza(parcel, 16, this.zzAd, false);
        zzd.zza(parcel, 17, this.zzAe, false);
        zzd.zza(parcel, 18, this.zzAf);
        zzd.zzI(parcel, zze);
    }
}
