package com.google.android.gms.internal;

import android.accounts.Account;
import java.util.ArrayList;
import java.util.List;

public final class zzaqj {
    private List<zzaqn> zzaja;
    private String zzajb;
    private boolean zzajc;
    private Account zzajd;

    public final zzaqj zzJ(boolean z) {
        this.zzajc = true;
        return this;
    }

    public final zzaqj zza(zzaqn com_google_android_gms_internal_zzaqn) {
        if (this.zzaja == null && com_google_android_gms_internal_zzaqn != null) {
            this.zzaja = new ArrayList();
        }
        if (com_google_android_gms_internal_zzaqn != null) {
            this.zzaja.add(com_google_android_gms_internal_zzaqn);
        }
        return this;
    }

    public final zzaqj zzb(Account account) {
        this.zzajd = account;
        return this;
    }

    public final zzaqj zzbG(String str) {
        this.zzajb = str;
        return this;
    }

    public final zzaqi zzmh() {
        return new zzaqi(this.zzajb, this.zzajc, this.zzajd, this.zzaja != null ? (zzaqn[]) this.zzaja.toArray(new zzaqn[this.zzaja.size()]) : null);
    }
}
