package com.google.android.gms.internal;

import android.os.Bundle;
import android.os.SystemClock;
import com.google.android.gms.ads.internal.zzbs;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

@zzaaz
public final class zzagt {
    private final Object mLock;
    private boolean zzVc;
    private final LinkedList<zzagu> zzYb;
    private final String zzYc;
    private final String zzYd;
    private long zzYe;
    private long zzYf;
    private long zzYg;
    private long zzYh;
    private long zzYi;
    private long zzYj;
    private final zzagw zzvw;

    private zzagt(zzagw com_google_android_gms_internal_zzagw, String str, String str2) {
        this.mLock = new Object();
        this.zzYe = -1;
        this.zzYf = -1;
        this.zzVc = false;
        this.zzYg = -1;
        this.zzYh = 0;
        this.zzYi = -1;
        this.zzYj = -1;
        this.zzvw = com_google_android_gms_internal_zzagw;
        this.zzYc = str;
        this.zzYd = str2;
        this.zzYb = new LinkedList();
    }

    public zzagt(String str, String str2) {
        this(zzbs.zzbC(), str, str2);
    }

    public final Bundle toBundle() {
        Bundle bundle;
        synchronized (this.mLock) {
            bundle = new Bundle();
            bundle.putString("seq_num", this.zzYc);
            bundle.putString("slotid", this.zzYd);
            bundle.putBoolean("ismediation", this.zzVc);
            bundle.putLong("treq", this.zzYi);
            bundle.putLong("tresponse", this.zzYj);
            bundle.putLong("timp", this.zzYf);
            bundle.putLong("tload", this.zzYg);
            bundle.putLong("pcc", this.zzYh);
            bundle.putLong("tfetch", this.zzYe);
            ArrayList arrayList = new ArrayList();
            Iterator it = this.zzYb.iterator();
            while (it.hasNext()) {
                arrayList.add(((zzagu) it.next()).toBundle());
            }
            bundle.putParcelableArrayList("tclick", arrayList);
        }
        return bundle;
    }

    public final void zzh(long j) {
        synchronized (this.mLock) {
            this.zzYj = j;
            if (this.zzYj != -1) {
                this.zzvw.zza(this);
            }
        }
    }

    public final void zzhb() {
        synchronized (this.mLock) {
            if (this.zzYj != -1 && this.zzYf == -1) {
                this.zzYf = SystemClock.elapsedRealtime();
                this.zzvw.zza(this);
            }
            this.zzvw.zzhp().zzhb();
        }
    }

    public final void zzhc() {
        synchronized (this.mLock) {
            if (this.zzYj != -1) {
                zzagu com_google_android_gms_internal_zzagu = new zzagu();
                com_google_android_gms_internal_zzagu.zzhg();
                this.zzYb.add(com_google_android_gms_internal_zzagu);
                this.zzYh++;
                this.zzvw.zzhp().zzhc();
                this.zzvw.zza(this);
            }
        }
    }

    public final void zzhd() {
        synchronized (this.mLock) {
            if (!(this.zzYj == -1 || this.zzYb.isEmpty())) {
                zzagu com_google_android_gms_internal_zzagu = (zzagu) this.zzYb.getLast();
                if (com_google_android_gms_internal_zzagu.zzhe() == -1) {
                    com_google_android_gms_internal_zzagu.zzhf();
                    this.zzvw.zza(this);
                }
            }
        }
    }

    public final void zzi(long j) {
        synchronized (this.mLock) {
            if (this.zzYj != -1) {
                this.zzYe = j;
                this.zzvw.zza(this);
            }
        }
    }

    public final void zzo(zzir com_google_android_gms_internal_zzir) {
        synchronized (this.mLock) {
            this.zzYi = SystemClock.elapsedRealtime();
            this.zzvw.zzhp().zzb(com_google_android_gms_internal_zzir, this.zzYi);
        }
    }

    public final void zzv(boolean z) {
        synchronized (this.mLock) {
            if (this.zzYj != -1) {
                this.zzYg = SystemClock.elapsedRealtime();
                if (!z) {
                    this.zzYf = this.zzYg;
                    this.zzvw.zza(this);
                }
            }
        }
    }

    public final void zzw(boolean z) {
        synchronized (this.mLock) {
            if (this.zzYj != -1) {
                this.zzVc = z;
                this.zzvw.zza(this);
            }
        }
    }
}
