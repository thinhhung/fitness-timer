package com.google.android.gms.internal;

public interface zzalb<T> {
    void zza(zzale<T> com_google_android_gms_internal_zzale_T, zzalc com_google_android_gms_internal_zzalc);

    void zzf(T t);
}
