package com.google.android.gms.internal;

import java.io.IOException;

public final class ajf extends aif {
    private static volatile ajf[] zzcxa;
    public String zzcxb;

    public ajf() {
        this.zzcxb = "";
        this.zzcvf = -1;
    }

    public static ajf[] zzMx() {
        if (zzcxa == null) {
            synchronized (aid.zzcve) {
                if (zzcxa == null) {
                    zzcxa = new ajf[0];
                }
            }
        }
        return zzcxa;
    }

    public final /* synthetic */ aif zza(ahw com_google_android_gms_internal_ahw) throws IOException {
        while (true) {
            int zzLQ = com_google_android_gms_internal_ahw.zzLQ();
            switch (zzLQ) {
                case 0:
                    break;
                case 10:
                    this.zzcxb = com_google_android_gms_internal_ahw.readString();
                    continue;
                default:
                    if (!com_google_android_gms_internal_ahw.zzcl(zzLQ)) {
                        break;
                    }
                    continue;
            }
            return this;
        }
    }

    public final void zza(ahx com_google_android_gms_internal_ahx) throws IOException {
        if (!(this.zzcxb == null || this.zzcxb.equals(""))) {
            com_google_android_gms_internal_ahx.zzl(1, this.zzcxb);
        }
        super.zza(com_google_android_gms_internal_ahx);
    }

    protected final int zzn() {
        int zzn = super.zzn();
        return (this.zzcxb == null || this.zzcxb.equals("")) ? zzn : zzn + ahx.zzm(1, this.zzcxb);
    }
}
