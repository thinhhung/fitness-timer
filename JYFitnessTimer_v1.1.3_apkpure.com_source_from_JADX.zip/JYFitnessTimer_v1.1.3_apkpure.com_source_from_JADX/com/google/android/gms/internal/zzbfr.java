package com.google.android.gms.internal;

import android.support.annotation.NonNull;
import com.google.android.gms.common.api.Api.zzb;

public final class zzbfr {
    public final zzbfq<zzb, ?> zzaBw;
    public final zzbgk<zzb, ?> zzaBx;

    public zzbfr(@NonNull zzbfq<zzb, ?> com_google_android_gms_internal_zzbfq_com_google_android_gms_common_api_Api_zzb__, @NonNull zzbgk<zzb, ?> com_google_android_gms_internal_zzbgk_com_google_android_gms_common_api_Api_zzb__) {
        this.zzaBw = com_google_android_gms_internal_zzbfq_com_google_android_gms_common_api_Api_zzb__;
        this.zzaBx = com_google_android_gms_internal_zzbgk_com_google_android_gms_common_api_Api_zzb__;
    }
}
