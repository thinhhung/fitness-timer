package com.google.android.gms.internal;

final class zzbdn extends zzbek {
    private /* synthetic */ zzbdm zzaDd;

    zzbdn(zzbdm com_google_android_gms_internal_zzbdm, zzbei com_google_android_gms_internal_zzbei) {
        this.zzaDd = com_google_android_gms_internal_zzbdm;
        super(com_google_android_gms_internal_zzbei);
    }

    public final void zzpT() {
        this.zzaDd.onConnectionSuspended(1);
    }
}
