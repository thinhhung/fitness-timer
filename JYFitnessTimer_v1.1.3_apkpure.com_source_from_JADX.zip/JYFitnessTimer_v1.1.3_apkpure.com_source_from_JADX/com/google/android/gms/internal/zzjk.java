package com.google.android.gms.internal;

import com.google.android.gms.ads.AdListener;

@zzaaz
public class zzjk extends AdListener {
    private final Object lock = new Object();
    private AdListener zzAT;

    public void onAdClosed() {
        synchronized (this.lock) {
            if (this.zzAT != null) {
                this.zzAT.onAdClosed();
            }
        }
    }

    public void onAdFailedToLoad(int i) {
        synchronized (this.lock) {
            if (this.zzAT != null) {
                this.zzAT.onAdFailedToLoad(i);
            }
        }
    }

    public void onAdLeftApplication() {
        synchronized (this.lock) {
            if (this.zzAT != null) {
                this.zzAT.onAdLeftApplication();
            }
        }
    }

    public void onAdLoaded() {
        synchronized (this.lock) {
            if (this.zzAT != null) {
                this.zzAT.onAdLoaded();
            }
        }
    }

    public void onAdOpened() {
        synchronized (this.lock) {
            if (this.zzAT != null) {
                this.zzAT.onAdOpened();
            }
        }
    }

    public final void zza(AdListener adListener) {
        synchronized (this.lock) {
            this.zzAT = adListener;
        }
    }
}
