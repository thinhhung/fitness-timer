package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;

public final class zzjt extends zzed implements zzjr {
    zzjt(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.client.IAdLoader");
    }

    public final String getMediationAdapterClassName() throws RemoteException {
        Parcel zza = zza(2, zzY());
        String readString = zza.readString();
        zza.recycle();
        return readString;
    }

    public final boolean isLoading() throws RemoteException {
        Parcel zza = zza(3, zzY());
        boolean zza2 = zzef.zza(zza);
        zza.recycle();
        return zza2;
    }

    public final String zzaH() throws RemoteException {
        Parcel zza = zza(4, zzY());
        String readString = zza.readString();
        zza.recycle();
        return readString;
    }

    public final void zzc(zzir com_google_android_gms_internal_zzir) throws RemoteException {
        Parcel zzY = zzY();
        zzef.zza(zzY, (Parcelable) com_google_android_gms_internal_zzir);
        zzb(1, zzY);
    }
}
