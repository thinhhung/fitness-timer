package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.internal.view.SupportMenu;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.internal.safeparcel.zzb;

public final class zzbjn implements Creator<zzbjm> {
    public final /* synthetic */ Object createFromParcel(Parcel parcel) {
        DataHolder dataHolder = null;
        int zzd = zzb.zzd(parcel);
        int i = 0;
        long j = 0;
        DataHolder dataHolder2 = null;
        while (parcel.dataPosition() < zzd) {
            int readInt = parcel.readInt();
            switch (SupportMenu.USER_MASK & readInt) {
                case 2:
                    i = zzb.zzg(parcel, readInt);
                    break;
                case 3:
                    dataHolder2 = (DataHolder) zzb.zza(parcel, readInt, DataHolder.CREATOR);
                    break;
                case 4:
                    j = zzb.zzi(parcel, readInt);
                    break;
                case 5:
                    dataHolder = (DataHolder) zzb.zza(parcel, readInt, DataHolder.CREATOR);
                    break;
                default:
                    zzb.zzb(parcel, readInt);
                    break;
            }
        }
        zzb.zzF(parcel, zzd);
        return new zzbjm(i, dataHolder2, j, dataHolder);
    }

    public final /* synthetic */ Object[] newArray(int i) {
        return new zzbjm[i];
    }
}
