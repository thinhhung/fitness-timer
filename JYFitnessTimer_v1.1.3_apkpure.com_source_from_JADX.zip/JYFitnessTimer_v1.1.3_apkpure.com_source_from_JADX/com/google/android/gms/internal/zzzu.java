package com.google.android.gms.internal;

final class zzzu implements zzale<zzvd> {
    private /* synthetic */ zzzy zzRu;

    zzzu(zzzt com_google_android_gms_internal_zzzt, zzzy com_google_android_gms_internal_zzzy) {
        this.zzRu = com_google_android_gms_internal_zzzy;
    }

    public final /* synthetic */ void zzc(Object obj) {
        this.zzRu.zzd((zzvd) obj);
    }
}
