package com.google.android.gms.internal;

import android.content.Context;

@zzaaz
public class zzzl extends zzzd implements zzalr {
    zzzl(Context context, zzags com_google_android_gms_internal_zzags, zzalm com_google_android_gms_internal_zzalm, zzzk com_google_android_gms_internal_zzzk) {
        super(context, com_google_android_gms_internal_zzags, com_google_android_gms_internal_zzalm, com_google_android_gms_internal_zzzk);
    }

    protected final void zzgn() {
        if (this.zzQT.errorCode == -2) {
            this.zzJK.zziv().zza((zzalr) this);
            zzgp();
            zzako.zzaC("Loading HTML in WebView.");
            this.zzJK.loadDataWithBaseURL(this.zzQT.zzPk, this.zzQT.body, "text/html", "UTF-8", null);
        }
    }

    protected void zzgp() {
    }
}
