package com.google.android.gms.internal;

import android.support.annotation.Nullable;
import android.support.v4.util.SimpleArrayMap;
import android.view.View;
import android.widget.FrameLayout;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.zzn;
import java.util.Arrays;
import java.util.List;

@zzaaz
public final class zznu extends zzpk implements zzoa {
    private final Object mLock = new Object();
    private final zznn zzHM;
    @Nullable
    private zzks zzHN;
    @Nullable
    private View zzHO;
    private zzny zzHP;
    private final String zzHU;
    private final SimpleArrayMap<String, zznp> zzHV;
    private final SimpleArrayMap<String, String> zzHW;

    public zznu(String str, SimpleArrayMap<String, zznp> simpleArrayMap, SimpleArrayMap<String, String> simpleArrayMap2, zznn com_google_android_gms_internal_zznn, zzks com_google_android_gms_internal_zzks, View view) {
        this.zzHU = str;
        this.zzHV = simpleArrayMap;
        this.zzHW = simpleArrayMap2;
        this.zzHM = com_google_android_gms_internal_zznn;
        this.zzHN = com_google_android_gms_internal_zzks;
        this.zzHO = view;
    }

    public final void destroy() {
        this.zzHP = null;
        this.zzHN = null;
        this.zzHO = null;
    }

    public final List<String> getAvailableAssetNames() {
        int i = 0;
        String[] strArr = new String[(this.zzHV.size() + this.zzHW.size())];
        int i2 = 0;
        for (int i3 = 0; i3 < this.zzHV.size(); i3++) {
            strArr[i2] = (String) this.zzHV.keyAt(i3);
            i2++;
        }
        while (i < this.zzHW.size()) {
            strArr[i2] = (String) this.zzHW.keyAt(i);
            i++;
            i2++;
        }
        return Arrays.asList(strArr);
    }

    public final String getCustomTemplateId() {
        return this.zzHU;
    }

    public final zzks getVideoController() {
        return this.zzHN;
    }

    public final void performClick(String str) {
        synchronized (this.mLock) {
            if (this.zzHP == null) {
                zzako.m5148e("Attempt to call performClick before ad initialized.");
                return;
            }
            this.zzHP.zza(null, str, null, null, null);
        }
    }

    public final void recordImpression() {
        synchronized (this.mLock) {
            if (this.zzHP == null) {
                zzako.m5148e("Attempt to perform recordImpression before ad initialized.");
                return;
            }
            this.zzHP.zza(null, null);
        }
    }

    public final String zzP(String str) {
        return (String) this.zzHW.get(str);
    }

    public final zzos zzQ(String str) {
        return (zzos) this.zzHV.get(str);
    }

    public final void zzb(zzny com_google_android_gms_internal_zzny) {
        synchronized (this.mLock) {
            this.zzHP = com_google_android_gms_internal_zzny;
        }
    }

    public final IObjectWrapper zzeh() {
        return zzn.zzw(this.zzHP);
    }

    public final String zzei() {
        return "3";
    }

    public final zznn zzej() {
        return this.zzHM;
    }

    public final View zzek() {
        return this.zzHO;
    }

    public final IObjectWrapper zzem() {
        return zzn.zzw(this.zzHP.getContext().getApplicationContext());
    }

    public final boolean zzj(IObjectWrapper iObjectWrapper) {
        if (this.zzHP == null) {
            zzako.m5148e("Attempt to call renderVideoInMediaView before ad initialized.");
            return false;
        } else if (this.zzHO == null) {
            return false;
        } else {
            FrameLayout frameLayout = (FrameLayout) zzn.zzE(iObjectWrapper);
            this.zzHP.zza(frameLayout, new zznv(this));
            return true;
        }
    }
}
