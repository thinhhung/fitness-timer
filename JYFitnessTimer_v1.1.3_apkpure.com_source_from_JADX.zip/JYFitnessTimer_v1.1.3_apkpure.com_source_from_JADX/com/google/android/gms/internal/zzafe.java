package com.google.android.gms.internal;

public interface zzafe {
    void zzgS();

    void zzv(int i);
}
