package com.google.android.gms.internal;

import android.text.TextUtils;
import java.util.Map;

final class zzoh implements zzrd {
    final /* synthetic */ zzvd zzIm;
    final /* synthetic */ zzog zzIn;

    zzoh(zzog com_google_android_gms_internal_zzog, zzvd com_google_android_gms_internal_zzvd) {
        this.zzIn = com_google_android_gms_internal_zzog;
        this.zzIm = com_google_android_gms_internal_zzvd;
    }

    public final void zza(zzalm com_google_android_gms_internal_zzalm, Map<String, String> map) {
        zzalm com_google_android_gms_internal_zzalm2 = (zzalm) this.zzIn.zzIk.get();
        if (com_google_android_gms_internal_zzalm2 == null) {
            this.zzIm.zzb("/loadHtml", (zzrd) this);
            return;
        }
        com_google_android_gms_internal_zzalm2.zziv().zza(new zzoi(this, map));
        String str = (String) map.get("overlayHtml");
        String str2 = (String) map.get("baseUrl");
        if (TextUtils.isEmpty(str2)) {
            com_google_android_gms_internal_zzalm2.loadData(str, "text/html", "UTF-8");
        } else {
            com_google_android_gms_internal_zzalm2.loadDataWithBaseURL(str2, str, "text/html", "UTF-8", null);
        }
    }
}
