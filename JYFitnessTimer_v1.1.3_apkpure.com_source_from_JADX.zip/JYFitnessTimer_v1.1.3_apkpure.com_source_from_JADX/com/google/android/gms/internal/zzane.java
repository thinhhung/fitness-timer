package com.google.android.gms.internal;

import android.text.TextUtils;
import com.google.android.gms.analytics.zzj;
import com.google.android.gms.measurement.AppMeasurement$Param;
import java.util.HashMap;
import java.util.Map;

public final class zzane extends zzj<zzane> {
    public String zzafc;
    public boolean zzafd;

    public final String toString() {
        Map hashMap = new HashMap();
        hashMap.put("description", this.zzafc);
        hashMap.put(AppMeasurement$Param.FATAL, Boolean.valueOf(this.zzafd));
        return zzj.zzh(hashMap);
    }

    public final /* synthetic */ void zzb(zzj com_google_android_gms_analytics_zzj) {
        zzane com_google_android_gms_internal_zzane = (zzane) com_google_android_gms_analytics_zzj;
        if (!TextUtils.isEmpty(this.zzafc)) {
            com_google_android_gms_internal_zzane.zzafc = this.zzafc;
        }
        if (this.zzafd) {
            com_google_android_gms_internal_zzane.zzafd = this.zzafd;
        }
    }
}
