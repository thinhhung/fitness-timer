package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.Api.zzb;
import com.google.android.gms.common.api.GoogleApiClient;
import java.util.List;

final class zzcto extends zzf {
    private /* synthetic */ String zzbBT;
    private /* synthetic */ List zzbBU;
    private /* synthetic */ String zzbBV;

    zzcto(zzctm com_google_android_gms_internal_zzctm, GoogleApiClient googleApiClient, List list, String str, String str2) {
        this.zzbBU = list;
        this.zzbBV = str;
        this.zzbBT = str2;
        super(googleApiClient);
    }

    protected final /* synthetic */ void zza(zzb com_google_android_gms_common_api_Api_zzb) throws RemoteException {
        ((zzctz) com_google_android_gms_common_api_Api_zzb).zza(this.zzbCa, this.zzbBU, 2, this.zzbBV, this.zzbBT);
    }
}
