package com.google.android.gms.internal;

import java.util.HashMap;

public final class zzbu extends zzbs<Integer, Object> {
    public String zzaW;
    public String zzaY;
    public String zzaZ;
    public String zzba;
    public long zzlR;

    public zzbu() {
        this.zzaW = "E";
        this.zzlR = -1;
        this.zzaY = "E";
        this.zzaZ = "E";
        this.zzba = "E";
    }

    public zzbu(String str) {
        this();
        zzi(str);
    }

    protected final void zzi(String str) {
        HashMap zzj = zzbs.zzj(str);
        if (zzj != null) {
            this.zzaW = zzj.get(Integer.valueOf(0)) == null ? "E" : (String) zzj.get(Integer.valueOf(0));
            this.zzlR = zzj.get(Integer.valueOf(1)) == null ? -1 : ((Long) zzj.get(Integer.valueOf(1))).longValue();
            this.zzaY = zzj.get(Integer.valueOf(2)) == null ? "E" : (String) zzj.get(Integer.valueOf(2));
            this.zzaZ = zzj.get(Integer.valueOf(3)) == null ? "E" : (String) zzj.get(Integer.valueOf(3));
            this.zzba = zzj.get(Integer.valueOf(4)) == null ? "E" : (String) zzj.get(Integer.valueOf(4));
        }
    }

    protected final HashMap<Integer, Object> zzv() {
        HashMap<Integer, Object> hashMap = new HashMap();
        hashMap.put(Integer.valueOf(0), this.zzaW);
        hashMap.put(Integer.valueOf(4), this.zzba);
        hashMap.put(Integer.valueOf(3), this.zzaZ);
        hashMap.put(Integer.valueOf(2), this.zzaY);
        hashMap.put(Integer.valueOf(1), Long.valueOf(this.zzlR));
        return hashMap;
    }
}
