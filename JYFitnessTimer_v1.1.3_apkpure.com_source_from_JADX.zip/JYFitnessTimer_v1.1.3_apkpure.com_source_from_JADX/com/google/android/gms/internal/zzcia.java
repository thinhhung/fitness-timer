package com.google.android.gms.internal;

import java.util.List;
import java.util.Map;

final class zzcia implements zzchd {
    private /* synthetic */ zzchx zzbtc;

    zzcia(zzchx com_google_android_gms_internal_zzchx) {
        this.zzbtc = com_google_android_gms_internal_zzchx;
    }

    public final void zza(String str, int i, Throwable th, byte[] bArr, Map<String, List<String>> map) {
        this.zzbtc.zza(i, th, bArr);
    }
}
