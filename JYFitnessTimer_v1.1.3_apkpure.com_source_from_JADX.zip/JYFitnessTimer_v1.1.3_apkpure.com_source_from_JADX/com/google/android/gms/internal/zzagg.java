package com.google.android.gms.internal;

import android.content.Context;

public interface zzagg {
    zzagf zza(Context context, zzakq com_google_android_gms_internal_zzakq, zzabu com_google_android_gms_internal_zzabu);
}
