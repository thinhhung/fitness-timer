package com.google.android.gms.internal;

import android.content.Context;

@zzaaz
public abstract class zzadw {
    protected static void zze(zzadg com_google_android_gms_internal_zzadg) {
        if (com_google_android_gms_internal_zzadg.zzUP != null) {
            com_google_android_gms_internal_zzadg.zzUP.release();
        }
    }

    public abstract void zza(Context context, zzadg com_google_android_gms_internal_zzadg, zzakq com_google_android_gms_internal_zzakq);
}
