package com.google.android.gms.internal;

final class zzaok implements Runnable {
    private /* synthetic */ zzaoh zzagH;

    zzaok(zzaoh com_google_android_gms_internal_zzaoh) {
        this.zzagH = com_google_android_gms_internal_zzaoh;
    }

    public final void run() {
        this.zzagH.zzkW();
    }
}
