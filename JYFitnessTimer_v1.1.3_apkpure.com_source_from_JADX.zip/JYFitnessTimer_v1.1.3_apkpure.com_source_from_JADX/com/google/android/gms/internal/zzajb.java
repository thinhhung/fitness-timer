package com.google.android.gms.internal;

@zzaaz
public interface zzajb<T> {
    void cancel();

    T zzgo();
}
