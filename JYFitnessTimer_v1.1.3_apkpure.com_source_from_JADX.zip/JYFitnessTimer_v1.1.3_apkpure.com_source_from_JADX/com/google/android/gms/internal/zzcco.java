package com.google.android.gms.internal;

import java.io.IOException;

public final class zzcco extends ahz<zzcco> {
    public String type;
    public zzccn[] zzbgz;

    public zzcco() {
        this.type = "";
        this.zzbgz = zzccn.zzvH();
        this.zzcuW = null;
        this.zzcvf = -1;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof zzcco)) {
            return false;
        }
        zzcco com_google_android_gms_internal_zzcco = (zzcco) obj;
        if (this.type == null) {
            if (com_google_android_gms_internal_zzcco.type != null) {
                return false;
            }
        } else if (!this.type.equals(com_google_android_gms_internal_zzcco.type)) {
            return false;
        }
        return !aid.equals(this.zzbgz, com_google_android_gms_internal_zzcco.zzbgz) ? false : (this.zzcuW == null || this.zzcuW.isEmpty()) ? com_google_android_gms_internal_zzcco.zzcuW == null || com_google_android_gms_internal_zzcco.zzcuW.isEmpty() : this.zzcuW.equals(com_google_android_gms_internal_zzcco.zzcuW);
    }

    public final int hashCode() {
        int i = 0;
        int hashCode = ((((this.type == null ? 0 : this.type.hashCode()) + ((getClass().getName().hashCode() + 527) * 31)) * 31) + aid.hashCode(this.zzbgz)) * 31;
        if (!(this.zzcuW == null || this.zzcuW.isEmpty())) {
            i = this.zzcuW.hashCode();
        }
        return hashCode + i;
    }

    public final /* synthetic */ aif zza(ahw com_google_android_gms_internal_ahw) throws IOException {
        while (true) {
            int zzLQ = com_google_android_gms_internal_ahw.zzLQ();
            switch (zzLQ) {
                case 0:
                    break;
                case 10:
                    this.type = com_google_android_gms_internal_ahw.readString();
                    continue;
                case 18:
                    int zzb = aij.zzb(com_google_android_gms_internal_ahw, 18);
                    zzLQ = this.zzbgz == null ? 0 : this.zzbgz.length;
                    Object obj = new zzccn[(zzb + zzLQ)];
                    if (zzLQ != 0) {
                        System.arraycopy(this.zzbgz, 0, obj, 0, zzLQ);
                    }
                    while (zzLQ < obj.length - 1) {
                        obj[zzLQ] = new zzccn();
                        com_google_android_gms_internal_ahw.zzb(obj[zzLQ]);
                        com_google_android_gms_internal_ahw.zzLQ();
                        zzLQ++;
                    }
                    obj[zzLQ] = new zzccn();
                    com_google_android_gms_internal_ahw.zzb(obj[zzLQ]);
                    this.zzbgz = obj;
                    continue;
                default:
                    if (!super.zza(com_google_android_gms_internal_ahw, zzLQ)) {
                        break;
                    }
                    continue;
            }
            return this;
        }
    }

    public final void zza(ahx com_google_android_gms_internal_ahx) throws IOException {
        if (!(this.type == null || this.type.equals(""))) {
            com_google_android_gms_internal_ahx.zzl(1, this.type);
        }
        if (this.zzbgz != null && this.zzbgz.length > 0) {
            for (aif com_google_android_gms_internal_aif : this.zzbgz) {
                if (com_google_android_gms_internal_aif != null) {
                    com_google_android_gms_internal_ahx.zza(2, com_google_android_gms_internal_aif);
                }
            }
        }
        super.zza(com_google_android_gms_internal_ahx);
    }

    protected final int zzn() {
        int zzn = super.zzn();
        if (!(this.type == null || this.type.equals(""))) {
            zzn += ahx.zzm(1, this.type);
        }
        if (this.zzbgz == null || this.zzbgz.length <= 0) {
            return zzn;
        }
        int i = zzn;
        for (aif com_google_android_gms_internal_aif : this.zzbgz) {
            if (com_google_android_gms_internal_aif != null) {
                i += ahx.zzb(2, com_google_android_gms_internal_aif);
            }
        }
        return i;
    }
}
