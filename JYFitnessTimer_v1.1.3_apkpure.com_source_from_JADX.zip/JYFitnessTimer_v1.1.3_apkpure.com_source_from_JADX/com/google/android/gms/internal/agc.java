package com.google.android.gms.internal;

import java.io.IOException;
import java.util.Arrays;

public final class agc extends ahz<agc> {
    private static volatile agc[] zzcqz;
    public String key;
    public byte[] zzcqA;

    public agc() {
        this.key = "";
        this.zzcqA = aij.zzcvs;
        this.zzcuW = null;
        this.zzcvf = -1;
    }

    public static agc[] zzKZ() {
        if (zzcqz == null) {
            synchronized (aid.zzcve) {
                if (zzcqz == null) {
                    zzcqz = new agc[0];
                }
            }
        }
        return zzcqz;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof agc)) {
            return false;
        }
        agc com_google_android_gms_internal_agc = (agc) obj;
        if (this.key == null) {
            if (com_google_android_gms_internal_agc.key != null) {
                return false;
            }
        } else if (!this.key.equals(com_google_android_gms_internal_agc.key)) {
            return false;
        }
        return !Arrays.equals(this.zzcqA, com_google_android_gms_internal_agc.zzcqA) ? false : (this.zzcuW == null || this.zzcuW.isEmpty()) ? com_google_android_gms_internal_agc.zzcuW == null || com_google_android_gms_internal_agc.zzcuW.isEmpty() : this.zzcuW.equals(com_google_android_gms_internal_agc.zzcuW);
    }

    public final int hashCode() {
        int i = 0;
        int hashCode = ((((this.key == null ? 0 : this.key.hashCode()) + ((getClass().getName().hashCode() + 527) * 31)) * 31) + Arrays.hashCode(this.zzcqA)) * 31;
        if (!(this.zzcuW == null || this.zzcuW.isEmpty())) {
            i = this.zzcuW.hashCode();
        }
        return hashCode + i;
    }

    public final /* synthetic */ aif zza(ahw com_google_android_gms_internal_ahw) throws IOException {
        while (true) {
            int zzLQ = com_google_android_gms_internal_ahw.zzLQ();
            switch (zzLQ) {
                case 0:
                    break;
                case 10:
                    this.key = com_google_android_gms_internal_ahw.readString();
                    continue;
                case 18:
                    this.zzcqA = com_google_android_gms_internal_ahw.readBytes();
                    continue;
                default:
                    if (!super.zza(com_google_android_gms_internal_ahw, zzLQ)) {
                        break;
                    }
                    continue;
            }
            return this;
        }
    }

    public final void zza(ahx com_google_android_gms_internal_ahx) throws IOException {
        if (!(this.key == null || this.key.equals(""))) {
            com_google_android_gms_internal_ahx.zzl(1, this.key);
        }
        if (!Arrays.equals(this.zzcqA, aij.zzcvs)) {
            com_google_android_gms_internal_ahx.zzb(2, this.zzcqA);
        }
        super.zza(com_google_android_gms_internal_ahx);
    }

    protected final int zzn() {
        int zzn = super.zzn();
        if (!(this.key == null || this.key.equals(""))) {
            zzn += ahx.zzm(1, this.key);
        }
        return !Arrays.equals(this.zzcqA, aij.zzcvs) ? zzn + ahx.zzc(2, this.zzcqA) : zzn;
    }
}
