package com.google.android.gms.internal;

import java.io.IOException;

public final class zzclm extends ahz<zzclm> {
    public long[] zzbwi;
    public long[] zzbwj;

    public zzclm() {
        this.zzbwi = aij.zzcvn;
        this.zzbwj = aij.zzcvn;
        this.zzcuW = null;
        this.zzcvf = -1;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof zzclm)) {
            return false;
        }
        zzclm com_google_android_gms_internal_zzclm = (zzclm) obj;
        return !aid.equals(this.zzbwi, com_google_android_gms_internal_zzclm.zzbwi) ? false : !aid.equals(this.zzbwj, com_google_android_gms_internal_zzclm.zzbwj) ? false : (this.zzcuW == null || this.zzcuW.isEmpty()) ? com_google_android_gms_internal_zzclm.zzcuW == null || com_google_android_gms_internal_zzclm.zzcuW.isEmpty() : this.zzcuW.equals(com_google_android_gms_internal_zzclm.zzcuW);
    }

    public final int hashCode() {
        int hashCode = (((((getClass().getName().hashCode() + 527) * 31) + aid.hashCode(this.zzbwi)) * 31) + aid.hashCode(this.zzbwj)) * 31;
        int hashCode2 = (this.zzcuW == null || this.zzcuW.isEmpty()) ? 0 : this.zzcuW.hashCode();
        return hashCode2 + hashCode;
    }

    public final /* synthetic */ aif zza(ahw com_google_android_gms_internal_ahw) throws IOException {
        while (true) {
            int zzLQ = com_google_android_gms_internal_ahw.zzLQ();
            int zzb;
            Object obj;
            int zzcm;
            Object obj2;
            switch (zzLQ) {
                case 0:
                    break;
                case 8:
                    zzb = aij.zzb(com_google_android_gms_internal_ahw, 8);
                    zzLQ = this.zzbwi == null ? 0 : this.zzbwi.length;
                    obj = new long[(zzb + zzLQ)];
                    if (zzLQ != 0) {
                        System.arraycopy(this.zzbwi, 0, obj, 0, zzLQ);
                    }
                    while (zzLQ < obj.length - 1) {
                        obj[zzLQ] = com_google_android_gms_internal_ahw.zzLW();
                        com_google_android_gms_internal_ahw.zzLQ();
                        zzLQ++;
                    }
                    obj[zzLQ] = com_google_android_gms_internal_ahw.zzLW();
                    this.zzbwi = obj;
                    continue;
                case 10:
                    zzcm = com_google_android_gms_internal_ahw.zzcm(com_google_android_gms_internal_ahw.zzLV());
                    zzb = com_google_android_gms_internal_ahw.getPosition();
                    zzLQ = 0;
                    while (com_google_android_gms_internal_ahw.zzMa() > 0) {
                        com_google_android_gms_internal_ahw.zzLW();
                        zzLQ++;
                    }
                    com_google_android_gms_internal_ahw.zzco(zzb);
                    zzb = this.zzbwi == null ? 0 : this.zzbwi.length;
                    obj2 = new long[(zzLQ + zzb)];
                    if (zzb != 0) {
                        System.arraycopy(this.zzbwi, 0, obj2, 0, zzb);
                    }
                    while (zzb < obj2.length) {
                        obj2[zzb] = com_google_android_gms_internal_ahw.zzLW();
                        zzb++;
                    }
                    this.zzbwi = obj2;
                    com_google_android_gms_internal_ahw.zzcn(zzcm);
                    continue;
                case 16:
                    zzb = aij.zzb(com_google_android_gms_internal_ahw, 16);
                    zzLQ = this.zzbwj == null ? 0 : this.zzbwj.length;
                    obj = new long[(zzb + zzLQ)];
                    if (zzLQ != 0) {
                        System.arraycopy(this.zzbwj, 0, obj, 0, zzLQ);
                    }
                    while (zzLQ < obj.length - 1) {
                        obj[zzLQ] = com_google_android_gms_internal_ahw.zzLW();
                        com_google_android_gms_internal_ahw.zzLQ();
                        zzLQ++;
                    }
                    obj[zzLQ] = com_google_android_gms_internal_ahw.zzLW();
                    this.zzbwj = obj;
                    continue;
                case 18:
                    zzcm = com_google_android_gms_internal_ahw.zzcm(com_google_android_gms_internal_ahw.zzLV());
                    zzb = com_google_android_gms_internal_ahw.getPosition();
                    zzLQ = 0;
                    while (com_google_android_gms_internal_ahw.zzMa() > 0) {
                        com_google_android_gms_internal_ahw.zzLW();
                        zzLQ++;
                    }
                    com_google_android_gms_internal_ahw.zzco(zzb);
                    zzb = this.zzbwj == null ? 0 : this.zzbwj.length;
                    obj2 = new long[(zzLQ + zzb)];
                    if (zzb != 0) {
                        System.arraycopy(this.zzbwj, 0, obj2, 0, zzb);
                    }
                    while (zzb < obj2.length) {
                        obj2[zzb] = com_google_android_gms_internal_ahw.zzLW();
                        zzb++;
                    }
                    this.zzbwj = obj2;
                    com_google_android_gms_internal_ahw.zzcn(zzcm);
                    continue;
                default:
                    if (!super.zza(com_google_android_gms_internal_ahw, zzLQ)) {
                        break;
                    }
                    continue;
            }
            return this;
        }
    }

    public final void zza(ahx com_google_android_gms_internal_ahx) throws IOException {
        int i = 0;
        if (this.zzbwi != null && this.zzbwi.length > 0) {
            for (long zza : this.zzbwi) {
                com_google_android_gms_internal_ahx.zza(1, zza);
            }
        }
        if (this.zzbwj != null && this.zzbwj.length > 0) {
            while (i < this.zzbwj.length) {
                com_google_android_gms_internal_ahx.zza(2, this.zzbwj[i]);
                i++;
            }
        }
        super.zza(com_google_android_gms_internal_ahx);
    }

    protected final int zzn() {
        int i;
        int i2;
        int i3 = 0;
        int zzn = super.zzn();
        if (this.zzbwi == null || this.zzbwi.length <= 0) {
            i = zzn;
        } else {
            i2 = 0;
            for (long zzaP : this.zzbwi) {
                i2 += ahx.zzaP(zzaP);
            }
            i = (zzn + i2) + (this.zzbwi.length * 1);
        }
        if (this.zzbwj == null || this.zzbwj.length <= 0) {
            return i;
        }
        i2 = 0;
        while (i3 < this.zzbwj.length) {
            i2 += ahx.zzaP(this.zzbwj[i3]);
            i3++;
        }
        return (i + i2) + (this.zzbwj.length * 1);
    }
}
