package com.google.android.gms.internal;

import android.content.Context;
import android.content.SharedPreferences.Editor;

final class zzahh extends zzaid {
    private /* synthetic */ String zzZb;
    private /* synthetic */ Context zztI;

    zzahh(Context context, String str) {
        this.zztI = context;
        this.zzZb = str;
        super();
    }

    public final void zzbc() {
        Editor edit = this.zztI.getSharedPreferences("admob", 0).edit();
        edit.putString("content_vertical_hashes", this.zzZb);
        edit.apply();
    }
}
