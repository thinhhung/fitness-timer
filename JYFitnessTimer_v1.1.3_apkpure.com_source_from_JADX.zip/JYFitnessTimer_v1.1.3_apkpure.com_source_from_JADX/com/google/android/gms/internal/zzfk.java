package com.google.android.gms.internal;

import android.support.annotation.Nullable;
import android.view.View;
import java.lang.ref.WeakReference;

public final class zzfk implements zzgs {
    private WeakReference<zzny> zzxl;

    public zzfk(zzny com_google_android_gms_internal_zzny) {
        this.zzxl = new WeakReference(com_google_android_gms_internal_zzny);
    }

    @Nullable
    public final View zzcu() {
        zzny com_google_android_gms_internal_zzny = (zzny) this.zzxl.get();
        return com_google_android_gms_internal_zzny != null ? com_google_android_gms_internal_zzny.zzes() : null;
    }

    public final boolean zzcv() {
        return this.zzxl.get() == null;
    }

    public final zzgs zzcw() {
        return new zzfm((zzny) this.zzxl.get());
    }
}
