package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import com.google.android.gms.dynamic.IObjectWrapper;
import com.google.android.gms.dynamic.IObjectWrapper.zza;
import java.util.List;

public final class zzpl extends zzed implements zzpj {
    zzpl(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.ads.internal.formats.client.INativeCustomTemplateAd");
    }

    public final void destroy() throws RemoteException {
        zzb(8, zzY());
    }

    public final List<String> getAvailableAssetNames() throws RemoteException {
        Parcel zza = zza(3, zzY());
        List createStringArrayList = zza.createStringArrayList();
        zza.recycle();
        return createStringArrayList;
    }

    public final String getCustomTemplateId() throws RemoteException {
        Parcel zza = zza(4, zzY());
        String readString = zza.readString();
        zza.recycle();
        return readString;
    }

    public final zzks getVideoController() throws RemoteException {
        Parcel zza = zza(7, zzY());
        zzks zzg = zzkt.zzg(zza.readStrongBinder());
        zza.recycle();
        return zzg;
    }

    public final void performClick(String str) throws RemoteException {
        Parcel zzY = zzY();
        zzY.writeString(str);
        zzb(5, zzY);
    }

    public final void recordImpression() throws RemoteException {
        zzb(6, zzY());
    }

    public final String zzP(String str) throws RemoteException {
        Parcel zzY = zzY();
        zzY.writeString(str);
        zzY = zza(1, zzY);
        String readString = zzY.readString();
        zzY.recycle();
        return readString;
    }

    public final zzos zzQ(String str) throws RemoteException {
        zzos com_google_android_gms_internal_zzos;
        Parcel zzY = zzY();
        zzY.writeString(str);
        Parcel zza = zza(2, zzY);
        IBinder readStrongBinder = zza.readStrongBinder();
        if (readStrongBinder == null) {
            com_google_android_gms_internal_zzos = null;
        } else {
            IInterface queryLocalInterface = readStrongBinder.queryLocalInterface("com.google.android.gms.ads.internal.formats.client.INativeAdImage");
            com_google_android_gms_internal_zzos = queryLocalInterface instanceof zzos ? (zzos) queryLocalInterface : new zzou(readStrongBinder);
        }
        zza.recycle();
        return com_google_android_gms_internal_zzos;
    }

    public final IObjectWrapper zzeh() throws RemoteException {
        Parcel zza = zza(11, zzY());
        IObjectWrapper zzM = zza.zzM(zza.readStrongBinder());
        zza.recycle();
        return zzM;
    }

    public final IObjectWrapper zzem() throws RemoteException {
        Parcel zza = zza(9, zzY());
        IObjectWrapper zzM = zza.zzM(zza.readStrongBinder());
        zza.recycle();
        return zzM;
    }

    public final boolean zzj(IObjectWrapper iObjectWrapper) throws RemoteException {
        Parcel zzY = zzY();
        zzef.zza(zzY, (IInterface) iObjectWrapper);
        zzY = zza(10, zzY);
        boolean zza = zzef.zza(zzY);
        zzY.recycle();
        return zza;
    }
}
