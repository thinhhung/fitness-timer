package com.google.android.gms.internal;

import android.os.Handler;
import com.google.android.gms.ads.internal.zzbs;
import java.util.HashMap;

@zzaaz
public final class zzig {
    private HashMap<String, Long> zzzD;
    private final zzij zzzE;
    private zzil zzzF;
    private boolean zzzG;
    private final boolean zzzH;
    private final int zzzI;
    private int zzzJ;
    private zzih zzzK;

    private zzig() {
        this.zzzG = false;
        this.zzzJ = 0;
        this.zzzH = false;
        this.zzzE = new zzik();
        this.zzzF = new zzil();
        this.zzzI = 0;
        zzdh();
    }

    public zzig(zzij com_google_android_gms_internal_zzij, boolean z) {
        this.zzzG = false;
        this.zzzJ = 0;
        this.zzzE = com_google_android_gms_internal_zzij;
        this.zzzD = new HashMap();
        this.zzzH = z;
        this.zzzI = ((Integer) zzbs.zzbK().zzd(zzmo.zzGH)).intValue();
        this.zzzF = new zzil();
        zzdh();
        zzbs.zzbO().zzid();
    }

    public static zzig zzdd() {
        return new zzig();
    }

    private final synchronized void zzdf() {
    }

    private final synchronized void zzdg() {
        Handler handler = zzbs.zzbO().getHandler();
        Object com_google_android_gms_internal_zzih = new zzih(this, this.zzzJ + 1);
        handler.postDelayed(com_google_android_gms_internal_zzih, (long) this.zzzI);
        this.zzzJ++;
        if (this.zzzK != null) {
            handler.removeCallbacks(this.zzzK);
        }
        this.zzzK = com_google_android_gms_internal_zzih;
    }

    private final synchronized void zzdh() {
    }

    public final synchronized void zza(zzii com_google_android_gms_internal_zzii) {
        if (this.zzzH) {
            com_google_android_gms_internal_zzii.zza(this.zzzF);
        }
        if (this.zzzG && this.zzzH) {
            zzdg();
        }
    }

    public final void zzde() {
        if (this.zzzH) {
            this.zzzG = true;
            zzdg();
        }
    }
}
