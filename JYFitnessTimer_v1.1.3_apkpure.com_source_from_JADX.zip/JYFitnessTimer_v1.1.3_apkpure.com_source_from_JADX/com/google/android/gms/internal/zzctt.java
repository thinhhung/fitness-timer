package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.Api.zzb;
import com.google.android.gms.common.api.GoogleApiClient;

final class zzctt extends zze {
    private /* synthetic */ String zzbBY;

    zzctt(zzctm com_google_android_gms_internal_zzctm, GoogleApiClient googleApiClient, String str) {
        this.zzbBY = str;
        super(googleApiClient);
    }

    protected final /* synthetic */ void zza(zzb com_google_android_gms_common_api_Api_zzb) throws RemoteException {
        zzctz com_google_android_gms_internal_zzctz = (zzctz) com_google_android_gms_common_api_Api_zzb;
        ((zzctk) com_google_android_gms_internal_zzctz.zzrd()).zza(this.zzbCa, this.zzbBY);
    }
}
