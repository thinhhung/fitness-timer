package com.google.android.gms.internal;

import com.google.android.gms.common.internal.zzbr;
import java.lang.Thread.UncaughtExceptionHandler;

final class zzchu implements UncaughtExceptionHandler {
    private final String zzbsk;
    private /* synthetic */ zzchs zzbsl;

    public zzchu(zzchs com_google_android_gms_internal_zzchs, String str) {
        this.zzbsl = com_google_android_gms_internal_zzchs;
        zzbr.zzu(str);
        this.zzbsk = str;
    }

    public final synchronized void uncaughtException(Thread thread, Throwable th) {
        this.zzbsl.zzwE().zzyv().zzj(this.zzbsk, th);
    }
}
