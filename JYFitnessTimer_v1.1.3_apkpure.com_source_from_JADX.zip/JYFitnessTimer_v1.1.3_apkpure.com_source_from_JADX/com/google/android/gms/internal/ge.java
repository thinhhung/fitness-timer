package com.google.android.gms.internal;

public final class ge {
    public static gd zzDC() {
        return new gc();
    }
}
