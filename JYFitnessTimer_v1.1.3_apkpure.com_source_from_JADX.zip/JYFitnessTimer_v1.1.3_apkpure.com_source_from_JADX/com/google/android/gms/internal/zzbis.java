package com.google.android.gms.internal;

import java.util.HashMap;
import java.util.Map;

public final class zzbis {
    private long zzaKq = 43200;
    private Map<String, String> zzaKr;
    private int zzaKs;
    private int zzaKu = -1;
    private int zzaKv = -1;

    public final zzbis zzA(long j) {
        this.zzaKq = j;
        return this;
    }

    public final zzbis zzA(String str, String str2) {
        if (this.zzaKr == null) {
            this.zzaKr = new HashMap();
        }
        this.zzaKr.put(str, str2);
        return this;
    }

    public final zzbis zzaE(int i) {
        this.zzaKs = 10300;
        return this;
    }

    public final zzbis zzaF(int i) {
        this.zzaKu = i;
        return this;
    }

    public final zzbis zzaG(int i) {
        this.zzaKv = i;
        return this;
    }

    public final zzbir zzsq() {
        return new zzbir();
    }
}
