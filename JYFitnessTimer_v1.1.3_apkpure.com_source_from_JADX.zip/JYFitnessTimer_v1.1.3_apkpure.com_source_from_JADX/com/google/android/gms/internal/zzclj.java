package com.google.android.gms.internal;

import java.io.IOException;

public final class zzclj extends ahz<zzclj> {
    private static volatile zzclj[] zzbvD;
    public String name;
    public String zzaIH;
    private Float zzbuE;
    public Double zzbuF;
    public Long zzbvE;

    public zzclj() {
        this.name = null;
        this.zzaIH = null;
        this.zzbvE = null;
        this.zzbuE = null;
        this.zzbuF = null;
        this.zzcuW = null;
        this.zzcvf = -1;
    }

    public static zzclj[] zzzA() {
        if (zzbvD == null) {
            synchronized (aid.zzcve) {
                if (zzbvD == null) {
                    zzbvD = new zzclj[0];
                }
            }
        }
        return zzbvD;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof zzclj)) {
            return false;
        }
        zzclj com_google_android_gms_internal_zzclj = (zzclj) obj;
        if (this.name == null) {
            if (com_google_android_gms_internal_zzclj.name != null) {
                return false;
            }
        } else if (!this.name.equals(com_google_android_gms_internal_zzclj.name)) {
            return false;
        }
        if (this.zzaIH == null) {
            if (com_google_android_gms_internal_zzclj.zzaIH != null) {
                return false;
            }
        } else if (!this.zzaIH.equals(com_google_android_gms_internal_zzclj.zzaIH)) {
            return false;
        }
        if (this.zzbvE == null) {
            if (com_google_android_gms_internal_zzclj.zzbvE != null) {
                return false;
            }
        } else if (!this.zzbvE.equals(com_google_android_gms_internal_zzclj.zzbvE)) {
            return false;
        }
        if (this.zzbuE == null) {
            if (com_google_android_gms_internal_zzclj.zzbuE != null) {
                return false;
            }
        } else if (!this.zzbuE.equals(com_google_android_gms_internal_zzclj.zzbuE)) {
            return false;
        }
        if (this.zzbuF == null) {
            if (com_google_android_gms_internal_zzclj.zzbuF != null) {
                return false;
            }
        } else if (!this.zzbuF.equals(com_google_android_gms_internal_zzclj.zzbuF)) {
            return false;
        }
        return (this.zzcuW == null || this.zzcuW.isEmpty()) ? com_google_android_gms_internal_zzclj.zzcuW == null || com_google_android_gms_internal_zzclj.zzcuW.isEmpty() : this.zzcuW.equals(com_google_android_gms_internal_zzclj.zzcuW);
    }

    public final int hashCode() {
        int i = 0;
        int hashCode = ((this.zzbuF == null ? 0 : this.zzbuF.hashCode()) + (((this.zzbuE == null ? 0 : this.zzbuE.hashCode()) + (((this.zzbvE == null ? 0 : this.zzbvE.hashCode()) + (((this.zzaIH == null ? 0 : this.zzaIH.hashCode()) + (((this.name == null ? 0 : this.name.hashCode()) + ((getClass().getName().hashCode() + 527) * 31)) * 31)) * 31)) * 31)) * 31)) * 31;
        if (!(this.zzcuW == null || this.zzcuW.isEmpty())) {
            i = this.zzcuW.hashCode();
        }
        return hashCode + i;
    }

    public final /* synthetic */ aif zza(ahw com_google_android_gms_internal_ahw) throws IOException {
        while (true) {
            int zzLQ = com_google_android_gms_internal_ahw.zzLQ();
            switch (zzLQ) {
                case 0:
                    break;
                case 10:
                    this.name = com_google_android_gms_internal_ahw.readString();
                    continue;
                case 18:
                    this.zzaIH = com_google_android_gms_internal_ahw.readString();
                    continue;
                case 24:
                    this.zzbvE = Long.valueOf(com_google_android_gms_internal_ahw.zzLW());
                    continue;
                case 37:
                    this.zzbuE = Float.valueOf(Float.intBitsToFloat(com_google_android_gms_internal_ahw.zzLX()));
                    continue;
                case 41:
                    this.zzbuF = Double.valueOf(Double.longBitsToDouble(com_google_android_gms_internal_ahw.zzLY()));
                    continue;
                default:
                    if (!super.zza(com_google_android_gms_internal_ahw, zzLQ)) {
                        break;
                    }
                    continue;
            }
            return this;
        }
    }

    public final void zza(ahx com_google_android_gms_internal_ahx) throws IOException {
        if (this.name != null) {
            com_google_android_gms_internal_ahx.zzl(1, this.name);
        }
        if (this.zzaIH != null) {
            com_google_android_gms_internal_ahx.zzl(2, this.zzaIH);
        }
        if (this.zzbvE != null) {
            com_google_android_gms_internal_ahx.zzb(3, this.zzbvE.longValue());
        }
        if (this.zzbuE != null) {
            com_google_android_gms_internal_ahx.zzc(4, this.zzbuE.floatValue());
        }
        if (this.zzbuF != null) {
            com_google_android_gms_internal_ahx.zza(5, this.zzbuF.doubleValue());
        }
        super.zza(com_google_android_gms_internal_ahx);
    }

    protected final int zzn() {
        int zzn = super.zzn();
        if (this.name != null) {
            zzn += ahx.zzm(1, this.name);
        }
        if (this.zzaIH != null) {
            zzn += ahx.zzm(2, this.zzaIH);
        }
        if (this.zzbvE != null) {
            zzn += ahx.zze(3, this.zzbvE.longValue());
        }
        if (this.zzbuE != null) {
            this.zzbuE.floatValue();
            zzn += ahx.zzcs(4) + 4;
        }
        if (this.zzbuF == null) {
            return zzn;
        }
        this.zzbuF.doubleValue();
        return zzn + (ahx.zzcs(5) + 8);
    }
}
