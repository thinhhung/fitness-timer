package com.google.android.gms.internal;

import java.io.IOException;

public final class zzcla extends ahz<zzcla> {
    private static volatile zzcla[] zzbuV;
    public zzcld zzbuW;
    public zzclb zzbuX;
    public Boolean zzbuY;
    public String zzbuZ;

    public zzcla() {
        this.zzbuW = null;
        this.zzbuX = null;
        this.zzbuY = null;
        this.zzbuZ = null;
        this.zzcuW = null;
        this.zzcvf = -1;
    }

    public static zzcla[] zzzu() {
        if (zzbuV == null) {
            synchronized (aid.zzcve) {
                if (zzbuV == null) {
                    zzbuV = new zzcla[0];
                }
            }
        }
        return zzbuV;
    }

    public final boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof zzcla)) {
            return false;
        }
        zzcla com_google_android_gms_internal_zzcla = (zzcla) obj;
        if (this.zzbuW == null) {
            if (com_google_android_gms_internal_zzcla.zzbuW != null) {
                return false;
            }
        } else if (!this.zzbuW.equals(com_google_android_gms_internal_zzcla.zzbuW)) {
            return false;
        }
        if (this.zzbuX == null) {
            if (com_google_android_gms_internal_zzcla.zzbuX != null) {
                return false;
            }
        } else if (!this.zzbuX.equals(com_google_android_gms_internal_zzcla.zzbuX)) {
            return false;
        }
        if (this.zzbuY == null) {
            if (com_google_android_gms_internal_zzcla.zzbuY != null) {
                return false;
            }
        } else if (!this.zzbuY.equals(com_google_android_gms_internal_zzcla.zzbuY)) {
            return false;
        }
        if (this.zzbuZ == null) {
            if (com_google_android_gms_internal_zzcla.zzbuZ != null) {
                return false;
            }
        } else if (!this.zzbuZ.equals(com_google_android_gms_internal_zzcla.zzbuZ)) {
            return false;
        }
        return (this.zzcuW == null || this.zzcuW.isEmpty()) ? com_google_android_gms_internal_zzcla.zzcuW == null || com_google_android_gms_internal_zzcla.zzcuW.isEmpty() : this.zzcuW.equals(com_google_android_gms_internal_zzcla.zzcuW);
    }

    public final int hashCode() {
        int i = 0;
        int hashCode = ((this.zzbuZ == null ? 0 : this.zzbuZ.hashCode()) + (((this.zzbuY == null ? 0 : this.zzbuY.hashCode()) + (((this.zzbuX == null ? 0 : this.zzbuX.hashCode()) + (((this.zzbuW == null ? 0 : this.zzbuW.hashCode()) + ((getClass().getName().hashCode() + 527) * 31)) * 31)) * 31)) * 31)) * 31;
        if (!(this.zzcuW == null || this.zzcuW.isEmpty())) {
            i = this.zzcuW.hashCode();
        }
        return hashCode + i;
    }

    public final /* synthetic */ aif zza(ahw com_google_android_gms_internal_ahw) throws IOException {
        while (true) {
            int zzLQ = com_google_android_gms_internal_ahw.zzLQ();
            switch (zzLQ) {
                case 0:
                    break;
                case 10:
                    if (this.zzbuW == null) {
                        this.zzbuW = new zzcld();
                    }
                    com_google_android_gms_internal_ahw.zzb(this.zzbuW);
                    continue;
                case 18:
                    if (this.zzbuX == null) {
                        this.zzbuX = new zzclb();
                    }
                    com_google_android_gms_internal_ahw.zzb(this.zzbuX);
                    continue;
                case 24:
                    this.zzbuY = Boolean.valueOf(com_google_android_gms_internal_ahw.zzLT());
                    continue;
                case 34:
                    this.zzbuZ = com_google_android_gms_internal_ahw.readString();
                    continue;
                default:
                    if (!super.zza(com_google_android_gms_internal_ahw, zzLQ)) {
                        break;
                    }
                    continue;
            }
            return this;
        }
    }

    public final void zza(ahx com_google_android_gms_internal_ahx) throws IOException {
        if (this.zzbuW != null) {
            com_google_android_gms_internal_ahx.zza(1, this.zzbuW);
        }
        if (this.zzbuX != null) {
            com_google_android_gms_internal_ahx.zza(2, this.zzbuX);
        }
        if (this.zzbuY != null) {
            com_google_android_gms_internal_ahx.zzk(3, this.zzbuY.booleanValue());
        }
        if (this.zzbuZ != null) {
            com_google_android_gms_internal_ahx.zzl(4, this.zzbuZ);
        }
        super.zza(com_google_android_gms_internal_ahx);
    }

    protected final int zzn() {
        int zzn = super.zzn();
        if (this.zzbuW != null) {
            zzn += ahx.zzb(1, this.zzbuW);
        }
        if (this.zzbuX != null) {
            zzn += ahx.zzb(2, this.zzbuX);
        }
        if (this.zzbuY != null) {
            this.zzbuY.booleanValue();
            zzn += ahx.zzcs(3) + 1;
        }
        return this.zzbuZ != null ? zzn + ahx.zzm(4, this.zzbuZ) : zzn;
    }
}
