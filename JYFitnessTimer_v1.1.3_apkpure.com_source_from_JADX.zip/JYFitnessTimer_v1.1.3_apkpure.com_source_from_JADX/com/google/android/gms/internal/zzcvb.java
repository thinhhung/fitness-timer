package com.google.android.gms.internal;

import android.os.RemoteException;

public class zzcvb extends zzcvd {
    public void zzb(zzcvj com_google_android_gms_internal_zzcvj) throws RemoteException {
    }
}
