package com.google.android.gms.internal;

import android.view.View;

public interface zzoa {
    String getCustomTemplateId();

    void zzb(zzny com_google_android_gms_internal_zzny);

    String zzei();

    zznn zzej();

    View zzek();
}
