package com.google.android.gms.internal;

final class zzzs implements Runnable {
    private /* synthetic */ zzzr zzRk;
    private /* synthetic */ zzagr zztA;

    zzzs(zzzr com_google_android_gms_internal_zzzr, zzagr com_google_android_gms_internal_zzagr) {
        this.zzRk = com_google_android_gms_internal_zzzr;
        this.zztA = com_google_android_gms_internal_zzagr;
    }

    public final void run() {
        zzzr.zza(this.zzRk).zzb(this.zztA);
    }
}
