package com.google.android.gms.internal;

import java.util.Collections;
import java.util.Map;

public final class fu {
    private final zzbr zzbGy;
    private final Map<String, zzbr> zzbLb;

    private fu(Map<String, zzbr> map, zzbr com_google_android_gms_internal_zzbr) {
        this.zzbLb = map;
        this.zzbGy = com_google_android_gms_internal_zzbr;
    }

    public static fv zzDu() {
        return new fv();
    }

    public final String toString() {
        String valueOf = String.valueOf(Collections.unmodifiableMap(this.zzbLb));
        String valueOf2 = String.valueOf(this.zzbGy);
        return new StringBuilder((String.valueOf(valueOf).length() + 32) + String.valueOf(valueOf2).length()).append("Properties: ").append(valueOf).append(" pushAfterEvaluate: ").append(valueOf2).toString();
    }

    public final zzbr zzBK() {
        return this.zzbGy;
    }

    public final Map<String, zzbr> zzCW() {
        return Collections.unmodifiableMap(this.zzbLb);
    }

    public final void zza(String str, zzbr com_google_android_gms_internal_zzbr) {
        this.zzbLb.put(str, com_google_android_gms_internal_zzbr);
    }
}
