package com.google.android.gms.internal;

import android.support.annotation.Nullable;
import android.view.View;

public interface zzgs {
    @Nullable
    View zzcu();

    boolean zzcv();

    zzgs zzcw();
}
