package com.google.android.gms.internal;

import java.io.IOException;

public final class aip extends ahz<aip> {
    private byte[] body;
    private aim[] zzcvL;
    private byte[] zzcvM;
    private Integer zzcvN;
    private aiq zzcvR;
    private byte[] zzcvS;

    public aip() {
        this.zzcvR = null;
        this.zzcvL = aim.zzMm();
        this.body = null;
        this.zzcvM = null;
        this.zzcvN = null;
        this.zzcvS = null;
        this.zzcuW = null;
        this.zzcvf = -1;
    }

    public final /* synthetic */ aif zza(ahw com_google_android_gms_internal_ahw) throws IOException {
        while (true) {
            int zzLQ = com_google_android_gms_internal_ahw.zzLQ();
            switch (zzLQ) {
                case 0:
                    break;
                case 10:
                    if (this.zzcvR == null) {
                        this.zzcvR = new aiq();
                    }
                    com_google_android_gms_internal_ahw.zzb(this.zzcvR);
                    continue;
                case 18:
                    int zzb = aij.zzb(com_google_android_gms_internal_ahw, 18);
                    zzLQ = this.zzcvL == null ? 0 : this.zzcvL.length;
                    Object obj = new aim[(zzb + zzLQ)];
                    if (zzLQ != 0) {
                        System.arraycopy(this.zzcvL, 0, obj, 0, zzLQ);
                    }
                    while (zzLQ < obj.length - 1) {
                        obj[zzLQ] = new aim();
                        com_google_android_gms_internal_ahw.zzb(obj[zzLQ]);
                        com_google_android_gms_internal_ahw.zzLQ();
                        zzLQ++;
                    }
                    obj[zzLQ] = new aim();
                    com_google_android_gms_internal_ahw.zzb(obj[zzLQ]);
                    this.zzcvL = obj;
                    continue;
                case 26:
                    this.body = com_google_android_gms_internal_ahw.readBytes();
                    continue;
                case 34:
                    this.zzcvM = com_google_android_gms_internal_ahw.readBytes();
                    continue;
                case 40:
                    this.zzcvN = Integer.valueOf(com_google_android_gms_internal_ahw.zzLS());
                    continue;
                case 50:
                    this.zzcvS = com_google_android_gms_internal_ahw.readBytes();
                    continue;
                default:
                    if (!super.zza(com_google_android_gms_internal_ahw, zzLQ)) {
                        break;
                    }
                    continue;
            }
            return this;
        }
    }

    public final void zza(ahx com_google_android_gms_internal_ahx) throws IOException {
        if (this.zzcvR != null) {
            com_google_android_gms_internal_ahx.zza(1, this.zzcvR);
        }
        if (this.zzcvL != null && this.zzcvL.length > 0) {
            for (aif com_google_android_gms_internal_aif : this.zzcvL) {
                if (com_google_android_gms_internal_aif != null) {
                    com_google_android_gms_internal_ahx.zza(2, com_google_android_gms_internal_aif);
                }
            }
        }
        if (this.body != null) {
            com_google_android_gms_internal_ahx.zzb(3, this.body);
        }
        if (this.zzcvM != null) {
            com_google_android_gms_internal_ahx.zzb(4, this.zzcvM);
        }
        if (this.zzcvN != null) {
            com_google_android_gms_internal_ahx.zzr(5, this.zzcvN.intValue());
        }
        if (this.zzcvS != null) {
            com_google_android_gms_internal_ahx.zzb(6, this.zzcvS);
        }
        super.zza(com_google_android_gms_internal_ahx);
    }

    protected final int zzn() {
        int zzn = super.zzn();
        if (this.zzcvR != null) {
            zzn += ahx.zzb(1, this.zzcvR);
        }
        if (this.zzcvL != null && this.zzcvL.length > 0) {
            int i = zzn;
            for (aif com_google_android_gms_internal_aif : this.zzcvL) {
                if (com_google_android_gms_internal_aif != null) {
                    i += ahx.zzb(2, com_google_android_gms_internal_aif);
                }
            }
            zzn = i;
        }
        if (this.body != null) {
            zzn += ahx.zzc(3, this.body);
        }
        if (this.zzcvM != null) {
            zzn += ahx.zzc(4, this.zzcvM);
        }
        if (this.zzcvN != null) {
            zzn += ahx.zzs(5, this.zzcvN.intValue());
        }
        return this.zzcvS != null ? zzn + ahx.zzc(6, this.zzcvS) : zzn;
    }
}
