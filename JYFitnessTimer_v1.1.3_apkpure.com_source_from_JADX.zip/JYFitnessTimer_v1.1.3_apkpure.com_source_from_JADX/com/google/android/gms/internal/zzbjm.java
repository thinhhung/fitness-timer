package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.data.DataHolder;
import com.google.android.gms.common.internal.safeparcel.zza;
import com.google.android.gms.common.internal.safeparcel.zzd;

public final class zzbjm extends zza {
    public static final Creator<zzbjm> CREATOR = new zzbjn();
    private final long zzaKC;
    private final DataHolder zzaKL;
    private final DataHolder zzaKM;
    private final int zzaxw;

    public zzbjm(int i, DataHolder dataHolder, long j, DataHolder dataHolder2) {
        this.zzaxw = i;
        this.zzaKL = dataHolder;
        this.zzaKC = j;
        this.zzaKM = dataHolder2;
    }

    public final int getStatusCode() {
        return this.zzaxw;
    }

    public final long getThrottleEndTimeMillis() {
        return this.zzaKC;
    }

    public final void writeToParcel(Parcel parcel, int i) {
        int zze = zzd.zze(parcel);
        zzd.zzc(parcel, 2, this.zzaxw);
        zzd.zza(parcel, 3, this.zzaKL, i, false);
        zzd.zza(parcel, 4, this.zzaKC);
        zzd.zza(parcel, 5, this.zzaKM, i, false);
        zzd.zzI(parcel, zze);
    }

    public final DataHolder zzst() {
        return this.zzaKL;
    }

    public final DataHolder zzsu() {
        return this.zzaKM;
    }

    public final void zzsv() {
        if (this.zzaKL != null && !this.zzaKL.isClosed()) {
            this.zzaKL.close();
        }
    }

    public final void zzsw() {
        if (this.zzaKM != null && !this.zzaKM.isClosed()) {
            this.zzaKM.close();
        }
    }
}
