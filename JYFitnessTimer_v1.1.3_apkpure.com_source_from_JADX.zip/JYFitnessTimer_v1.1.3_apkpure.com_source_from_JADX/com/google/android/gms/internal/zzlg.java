package com.google.android.gms.internal;

import android.content.Context;

final class zzlg implements Runnable {
    private /* synthetic */ zzlf zzBt;
    private /* synthetic */ Context zztI;

    zzlg(zzlf com_google_android_gms_internal_zzlf, Context context) {
        this.zzBt = com_google_android_gms_internal_zzlf;
        this.zztI = context;
    }

    public final void run() {
        this.zzBt.getRewardedVideoAdInstance(this.zztI);
    }
}
