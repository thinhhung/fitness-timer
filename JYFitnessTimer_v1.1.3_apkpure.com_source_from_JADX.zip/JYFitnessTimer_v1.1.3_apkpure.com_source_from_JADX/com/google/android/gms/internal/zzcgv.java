package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import bolts.MeasurementEvent;
import com.google.android.gms.common.internal.zzbr;
import com.google.android.gms.common.util.zzf;
import com.google.android.gms.measurement.AppMeasurement$Event;
import com.google.android.gms.measurement.AppMeasurement$Param;
import com.google.android.gms.measurement.AppMeasurement$UserProperty;
import com.onesignal.shortcutbadger.impl.NewHtcHomeBadger;
import org.apache.commons.lang3.StringUtils;

public final class zzcgv extends zzciv {
    private static String[] zzbqM = new String[AppMeasurement$Event.zzboj.length];
    private static String[] zzbqN = new String[AppMeasurement$Param.zzbol.length];
    private static String[] zzbqO = new String[AppMeasurement$UserProperty.zzboq.length];

    zzcgv(zzchx com_google_android_gms_internal_zzchx) {
        super(com_google_android_gms_internal_zzchx);
    }

    @Nullable
    private static String zza(String str, String[] strArr, String[] strArr2, String[] strArr3) {
        boolean z = true;
        int i = 0;
        zzbr.zzu(strArr);
        zzbr.zzu(strArr2);
        zzbr.zzu(strArr3);
        zzbr.zzaf(strArr.length == strArr2.length);
        if (strArr.length != strArr3.length) {
            z = false;
        }
        zzbr.zzaf(z);
        while (i < strArr.length) {
            if (zzckx.zzR(str, strArr[i])) {
                synchronized (strArr3) {
                    if (strArr3[i] == null) {
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append(strArr2[i]);
                        stringBuilder.append("(");
                        stringBuilder.append(strArr[i]);
                        stringBuilder.append(")");
                        strArr3[i] = stringBuilder.toString();
                    }
                    str = strArr3[i];
                }
                return str;
            }
            i++;
        }
        return str;
    }

    private static void zza(StringBuilder stringBuilder, int i) {
        for (int i2 = 0; i2 < i; i2++) {
            stringBuilder.append("  ");
        }
    }

    private final void zza(StringBuilder stringBuilder, int i, zzcla com_google_android_gms_internal_zzcla) {
        if (com_google_android_gms_internal_zzcla != null) {
            zza(stringBuilder, i);
            stringBuilder.append("filter {\n");
            zza(stringBuilder, i, "complement", com_google_android_gms_internal_zzcla.zzbuY);
            zza(stringBuilder, i, "param_name", zzdY(com_google_android_gms_internal_zzcla.zzbuZ));
            int i2 = i + 1;
            String str = "string_filter";
            zzcld com_google_android_gms_internal_zzcld = com_google_android_gms_internal_zzcla.zzbuW;
            if (com_google_android_gms_internal_zzcld != null) {
                zza(stringBuilder, i2);
                stringBuilder.append(str);
                stringBuilder.append(" {\n");
                if (com_google_android_gms_internal_zzcld.zzbvi != null) {
                    Object obj = "UNKNOWN_MATCH_TYPE";
                    switch (com_google_android_gms_internal_zzcld.zzbvi.intValue()) {
                        case 1:
                            obj = "REGEXP";
                            break;
                        case 2:
                            obj = "BEGINS_WITH";
                            break;
                        case 3:
                            obj = "ENDS_WITH";
                            break;
                        case 4:
                            obj = "PARTIAL";
                            break;
                        case 5:
                            obj = "EXACT";
                            break;
                        case 6:
                            obj = "IN_LIST";
                            break;
                    }
                    zza(stringBuilder, i2, "match_type", obj);
                }
                zza(stringBuilder, i2, "expression", com_google_android_gms_internal_zzcld.zzbvj);
                zza(stringBuilder, i2, "case_sensitive", com_google_android_gms_internal_zzcld.zzbvk);
                if (com_google_android_gms_internal_zzcld.zzbvl.length > 0) {
                    zza(stringBuilder, i2 + 1);
                    stringBuilder.append("expression_list {\n");
                    for (String str2 : com_google_android_gms_internal_zzcld.zzbvl) {
                        zza(stringBuilder, i2 + 2);
                        stringBuilder.append(str2);
                        stringBuilder.append(StringUtils.LF);
                    }
                    stringBuilder.append("}\n");
                }
                zza(stringBuilder, i2);
                stringBuilder.append("}\n");
            }
            zza(stringBuilder, i + 1, "number_filter", com_google_android_gms_internal_zzcla.zzbuX);
            zza(stringBuilder, i);
            stringBuilder.append("}\n");
        }
    }

    private final void zza(StringBuilder stringBuilder, int i, String str, zzclb com_google_android_gms_internal_zzclb) {
        if (com_google_android_gms_internal_zzclb != null) {
            zza(stringBuilder, i);
            stringBuilder.append(str);
            stringBuilder.append(" {\n");
            if (com_google_android_gms_internal_zzclb.zzbva != null) {
                Object obj = "UNKNOWN_COMPARISON_TYPE";
                switch (com_google_android_gms_internal_zzclb.zzbva.intValue()) {
                    case 1:
                        obj = "LESS_THAN";
                        break;
                    case 2:
                        obj = "GREATER_THAN";
                        break;
                    case 3:
                        obj = "EQUAL";
                        break;
                    case 4:
                        obj = "BETWEEN";
                        break;
                }
                zza(stringBuilder, i, "comparison_type", obj);
            }
            zza(stringBuilder, i, "match_as_float", com_google_android_gms_internal_zzclb.zzbvb);
            zza(stringBuilder, i, "comparison_value", com_google_android_gms_internal_zzclb.zzbvc);
            zza(stringBuilder, i, "min_comparison_value", com_google_android_gms_internal_zzclb.zzbvd);
            zza(stringBuilder, i, "max_comparison_value", com_google_android_gms_internal_zzclb.zzbve);
            zza(stringBuilder, i);
            stringBuilder.append("}\n");
        }
    }

    private static void zza(StringBuilder stringBuilder, int i, String str, zzclm com_google_android_gms_internal_zzclm) {
        int i2 = 0;
        if (com_google_android_gms_internal_zzclm != null) {
            int i3;
            int i4;
            int i5 = i + 1;
            zza(stringBuilder, i5);
            stringBuilder.append(str);
            stringBuilder.append(" {\n");
            if (com_google_android_gms_internal_zzclm.zzbwj != null) {
                zza(stringBuilder, i5 + 1);
                stringBuilder.append("results: ");
                long[] jArr = com_google_android_gms_internal_zzclm.zzbwj;
                int length = jArr.length;
                i3 = 0;
                i4 = 0;
                while (i3 < length) {
                    Long valueOf = Long.valueOf(jArr[i3]);
                    int i6 = i4 + 1;
                    if (i4 != 0) {
                        stringBuilder.append(", ");
                    }
                    stringBuilder.append(valueOf);
                    i3++;
                    i4 = i6;
                }
                stringBuilder.append('\n');
            }
            if (com_google_android_gms_internal_zzclm.zzbwi != null) {
                zza(stringBuilder, i5 + 1);
                stringBuilder.append("status: ");
                long[] jArr2 = com_google_android_gms_internal_zzclm.zzbwi;
                int length2 = jArr2.length;
                i3 = 0;
                while (i2 < length2) {
                    Long valueOf2 = Long.valueOf(jArr2[i2]);
                    i4 = i3 + 1;
                    if (i3 != 0) {
                        stringBuilder.append(", ");
                    }
                    stringBuilder.append(valueOf2);
                    i2++;
                    i3 = i4;
                }
                stringBuilder.append('\n');
            }
            zza(stringBuilder, i5);
            stringBuilder.append("}\n");
        }
    }

    private static void zza(StringBuilder stringBuilder, int i, String str, Object obj) {
        if (obj != null) {
            zza(stringBuilder, i + 1);
            stringBuilder.append(str);
            stringBuilder.append(": ");
            stringBuilder.append(obj);
            stringBuilder.append('\n');
        }
    }

    private final void zza(StringBuilder stringBuilder, int i, zzclh[] com_google_android_gms_internal_zzclhArr) {
        if (com_google_android_gms_internal_zzclhArr != null) {
            for (zzclh com_google_android_gms_internal_zzclh : com_google_android_gms_internal_zzclhArr) {
                if (com_google_android_gms_internal_zzclh != null) {
                    zza(stringBuilder, 2);
                    stringBuilder.append("audience_membership {\n");
                    zza(stringBuilder, 2, "audience_id", com_google_android_gms_internal_zzclh.zzbuM);
                    zza(stringBuilder, 2, "new_audience", com_google_android_gms_internal_zzclh.zzbvy);
                    zza(stringBuilder, 2, "current_data", com_google_android_gms_internal_zzclh.zzbvw);
                    zza(stringBuilder, 2, "previous_data", com_google_android_gms_internal_zzclh.zzbvx);
                    zza(stringBuilder, 2);
                    stringBuilder.append("}\n");
                }
            }
        }
    }

    private final void zza(StringBuilder stringBuilder, int i, zzcli[] com_google_android_gms_internal_zzcliArr) {
        if (com_google_android_gms_internal_zzcliArr != null) {
            for (zzcli com_google_android_gms_internal_zzcli : com_google_android_gms_internal_zzcliArr) {
                if (com_google_android_gms_internal_zzcli != null) {
                    zza(stringBuilder, 2);
                    stringBuilder.append("event {\n");
                    zza(stringBuilder, 2, "name", zzdX(com_google_android_gms_internal_zzcli.name));
                    zza(stringBuilder, 2, "timestamp_millis", com_google_android_gms_internal_zzcli.zzbvB);
                    zza(stringBuilder, 2, "previous_timestamp_millis", com_google_android_gms_internal_zzcli.zzbvC);
                    zza(stringBuilder, 2, NewHtcHomeBadger.COUNT, com_google_android_gms_internal_zzcli.count);
                    zzclj[] com_google_android_gms_internal_zzcljArr = com_google_android_gms_internal_zzcli.zzbvA;
                    if (com_google_android_gms_internal_zzcljArr != null) {
                        for (zzclj com_google_android_gms_internal_zzclj : com_google_android_gms_internal_zzcljArr) {
                            if (com_google_android_gms_internal_zzclj != null) {
                                zza(stringBuilder, 3);
                                stringBuilder.append("param {\n");
                                zza(stringBuilder, 3, "name", zzdY(com_google_android_gms_internal_zzclj.name));
                                zza(stringBuilder, 3, "string_value", com_google_android_gms_internal_zzclj.zzaIH);
                                zza(stringBuilder, 3, "int_value", com_google_android_gms_internal_zzclj.zzbvE);
                                zza(stringBuilder, 3, "double_value", com_google_android_gms_internal_zzclj.zzbuF);
                                zza(stringBuilder, 3);
                                stringBuilder.append("}\n");
                            }
                        }
                    }
                    zza(stringBuilder, 2);
                    stringBuilder.append("}\n");
                }
            }
        }
    }

    private final void zza(StringBuilder stringBuilder, int i, zzcln[] com_google_android_gms_internal_zzclnArr) {
        if (com_google_android_gms_internal_zzclnArr != null) {
            for (zzcln com_google_android_gms_internal_zzcln : com_google_android_gms_internal_zzclnArr) {
                if (com_google_android_gms_internal_zzcln != null) {
                    zza(stringBuilder, 2);
                    stringBuilder.append("user_property {\n");
                    zza(stringBuilder, 2, "set_timestamp_millis", com_google_android_gms_internal_zzcln.zzbwl);
                    zza(stringBuilder, 2, "name", zzdZ(com_google_android_gms_internal_zzcln.name));
                    zza(stringBuilder, 2, "string_value", com_google_android_gms_internal_zzcln.zzaIH);
                    zza(stringBuilder, 2, "int_value", com_google_android_gms_internal_zzcln.zzbvE);
                    zza(stringBuilder, 2, "double_value", com_google_android_gms_internal_zzcln.zzbuF);
                    zza(stringBuilder, 2);
                    stringBuilder.append("}\n");
                }
            }
        }
    }

    @Nullable
    private final String zzb(zzcgi com_google_android_gms_internal_zzcgi) {
        return com_google_android_gms_internal_zzcgi == null ? null : !zzyu() ? com_google_android_gms_internal_zzcgi.toString() : zzA(com_google_android_gms_internal_zzcgi.zzyr());
    }

    private final boolean zzyu() {
        return this.zzboi.zzwE().zzz(3);
    }

    public final /* bridge */ /* synthetic */ Context getContext() {
        return super.getContext();
    }

    @Nullable
    protected final String zzA(Bundle bundle) {
        if (bundle == null) {
            return null;
        }
        if (!zzyu()) {
            return bundle.toString();
        }
        StringBuilder stringBuilder = new StringBuilder();
        for (String str : bundle.keySet()) {
            if (stringBuilder.length() != 0) {
                stringBuilder.append(", ");
            } else {
                stringBuilder.append("Bundle[{");
            }
            stringBuilder.append(zzdY(str));
            stringBuilder.append("=");
            stringBuilder.append(bundle.get(str));
        }
        stringBuilder.append("}]");
        return stringBuilder.toString();
    }

    @Nullable
    protected final String zza(zzcgg com_google_android_gms_internal_zzcgg) {
        if (com_google_android_gms_internal_zzcgg == null) {
            return null;
        }
        if (!zzyu()) {
            return com_google_android_gms_internal_zzcgg.toString();
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Event{appId='");
        stringBuilder.append(com_google_android_gms_internal_zzcgg.mAppId);
        stringBuilder.append("', name='");
        stringBuilder.append(zzdX(com_google_android_gms_internal_zzcgg.mName));
        stringBuilder.append("', params=");
        stringBuilder.append(zzb(com_google_android_gms_internal_zzcgg.zzbpJ));
        stringBuilder.append("}");
        return stringBuilder.toString();
    }

    protected final String zza(zzckz com_google_android_gms_internal_zzckz) {
        int i = 0;
        if (com_google_android_gms_internal_zzckz == null) {
            return "null";
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("\nevent_filter {\n");
        zza(stringBuilder, 0, "filter_id", com_google_android_gms_internal_zzckz.zzbuQ);
        zza(stringBuilder, 0, MeasurementEvent.MEASUREMENT_EVENT_NAME_KEY, zzdX(com_google_android_gms_internal_zzckz.zzbuR));
        zza(stringBuilder, 1, "event_count_filter", com_google_android_gms_internal_zzckz.zzbuU);
        stringBuilder.append("  filters {\n");
        zzcla[] com_google_android_gms_internal_zzclaArr = com_google_android_gms_internal_zzckz.zzbuS;
        int length = com_google_android_gms_internal_zzclaArr.length;
        while (i < length) {
            zza(stringBuilder, 2, com_google_android_gms_internal_zzclaArr[i]);
            i++;
        }
        zza(stringBuilder, 1);
        stringBuilder.append("}\n}\n");
        return stringBuilder.toString();
    }

    protected final String zza(zzclc com_google_android_gms_internal_zzclc) {
        if (com_google_android_gms_internal_zzclc == null) {
            return "null";
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("\nproperty_filter {\n");
        zza(stringBuilder, 0, "filter_id", com_google_android_gms_internal_zzclc.zzbuQ);
        zza(stringBuilder, 0, "property_name", zzdZ(com_google_android_gms_internal_zzclc.zzbvg));
        zza(stringBuilder, 1, com_google_android_gms_internal_zzclc.zzbvh);
        stringBuilder.append("}\n");
        return stringBuilder.toString();
    }

    protected final String zza(zzclk com_google_android_gms_internal_zzclk) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("\nbatch {\n");
        if (com_google_android_gms_internal_zzclk.zzbvF != null) {
            for (zzcll com_google_android_gms_internal_zzcll : com_google_android_gms_internal_zzclk.zzbvF) {
                if (!(com_google_android_gms_internal_zzcll == null || com_google_android_gms_internal_zzcll == null)) {
                    zza(stringBuilder, 1);
                    stringBuilder.append("bundle {\n");
                    zza(stringBuilder, 1, "protocol_version", com_google_android_gms_internal_zzcll.zzbvH);
                    zza(stringBuilder, 1, "platform", com_google_android_gms_internal_zzcll.zzbvP);
                    zza(stringBuilder, 1, "gmp_version", com_google_android_gms_internal_zzcll.zzbvT);
                    zza(stringBuilder, 1, "uploading_gmp_version", com_google_android_gms_internal_zzcll.zzbvU);
                    zza(stringBuilder, 1, "config_version", com_google_android_gms_internal_zzcll.zzbwf);
                    zza(stringBuilder, 1, "gmp_app_id", com_google_android_gms_internal_zzcll.zzboU);
                    zza(stringBuilder, 1, "app_id", com_google_android_gms_internal_zzcll.zzaK);
                    zza(stringBuilder, 1, "app_version", com_google_android_gms_internal_zzcll.zzbha);
                    zza(stringBuilder, 1, "app_version_major", com_google_android_gms_internal_zzcll.zzbwc);
                    zza(stringBuilder, 1, "firebase_instance_id", com_google_android_gms_internal_zzcll.zzbpc);
                    zza(stringBuilder, 1, "dev_cert_hash", com_google_android_gms_internal_zzcll.zzbvY);
                    zza(stringBuilder, 1, "app_store", com_google_android_gms_internal_zzcll.zzboV);
                    zza(stringBuilder, 1, "upload_timestamp_millis", com_google_android_gms_internal_zzcll.zzbvK);
                    zza(stringBuilder, 1, "start_timestamp_millis", com_google_android_gms_internal_zzcll.zzbvL);
                    zza(stringBuilder, 1, "end_timestamp_millis", com_google_android_gms_internal_zzcll.zzbvM);
                    zza(stringBuilder, 1, "previous_bundle_start_timestamp_millis", com_google_android_gms_internal_zzcll.zzbvN);
                    zza(stringBuilder, 1, "previous_bundle_end_timestamp_millis", com_google_android_gms_internal_zzcll.zzbvO);
                    zza(stringBuilder, 1, "app_instance_id", com_google_android_gms_internal_zzcll.zzbvX);
                    zza(stringBuilder, 1, "resettable_device_id", com_google_android_gms_internal_zzcll.zzbvV);
                    zza(stringBuilder, 1, "limited_ad_tracking", com_google_android_gms_internal_zzcll.zzbvW);
                    zza(stringBuilder, 1, "os_version", com_google_android_gms_internal_zzcll.zzbb);
                    zza(stringBuilder, 1, "device_model", com_google_android_gms_internal_zzcll.zzbvQ);
                    zza(stringBuilder, 1, "user_default_language", com_google_android_gms_internal_zzcll.zzbvR);
                    zza(stringBuilder, 1, "time_zone_offset_minutes", com_google_android_gms_internal_zzcll.zzbvS);
                    zza(stringBuilder, 1, "bundle_sequential_index", com_google_android_gms_internal_zzcll.zzbvZ);
                    zza(stringBuilder, 1, "service_upload", com_google_android_gms_internal_zzcll.zzbwa);
                    zza(stringBuilder, 1, "health_monitor", com_google_android_gms_internal_zzcll.zzboY);
                    if (com_google_android_gms_internal_zzcll.zzbwg.longValue() != 0) {
                        zza(stringBuilder, 1, "android_id", com_google_android_gms_internal_zzcll.zzbwg);
                    }
                    zza(stringBuilder, 1, com_google_android_gms_internal_zzcll.zzbvJ);
                    zza(stringBuilder, 1, com_google_android_gms_internal_zzcll.zzbwb);
                    zza(stringBuilder, 1, com_google_android_gms_internal_zzcll.zzbvI);
                    zza(stringBuilder, 1);
                    stringBuilder.append("}\n");
                }
            }
        }
        stringBuilder.append("}\n");
        return stringBuilder.toString();
    }

    @Nullable
    protected final String zzb(zzcgl com_google_android_gms_internal_zzcgl) {
        if (com_google_android_gms_internal_zzcgl == null) {
            return null;
        }
        if (!zzyu()) {
            return com_google_android_gms_internal_zzcgl.toString();
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("origin=");
        stringBuilder.append(com_google_android_gms_internal_zzcgl.zzbpg);
        stringBuilder.append(",name=");
        stringBuilder.append(zzdX(com_google_android_gms_internal_zzcgl.name));
        stringBuilder.append(",params=");
        stringBuilder.append(zzb(com_google_android_gms_internal_zzcgl.zzbpQ));
        return stringBuilder.toString();
    }

    @Nullable
    protected final String zzdX(String str) {
        return str == null ? null : zzyu() ? zza(str, AppMeasurement$Event.zzbok, AppMeasurement$Event.zzboj, zzbqM) : str;
    }

    @Nullable
    protected final String zzdY(String str) {
        return str == null ? null : zzyu() ? zza(str, AppMeasurement$Param.zzbom, AppMeasurement$Param.zzbol, zzbqN) : str;
    }

    @Nullable
    protected final String zzdZ(String str) {
        if (str == null) {
            return null;
        }
        if (!zzyu()) {
            return str;
        }
        if (!str.startsWith("_exp_")) {
            return zza(str, AppMeasurement$UserProperty.zzbor, AppMeasurement$UserProperty.zzboq, zzbqO);
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("experiment_id");
        stringBuilder.append("(");
        stringBuilder.append(str);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }

    public final /* bridge */ /* synthetic */ void zzjB() {
        super.zzjB();
    }

    protected final void zzjC() {
    }

    public final /* bridge */ /* synthetic */ zzf zzkp() {
        return super.zzkp();
    }

    public final /* bridge */ /* synthetic */ zzckx zzwA() {
        return super.zzwA();
    }

    public final /* bridge */ /* synthetic */ zzchr zzwB() {
        return super.zzwB();
    }

    public final /* bridge */ /* synthetic */ zzckm zzwC() {
        return super.zzwC();
    }

    public final /* bridge */ /* synthetic */ zzchs zzwD() {
        return super.zzwD();
    }

    public final /* bridge */ /* synthetic */ zzcgx zzwE() {
        return super.zzwE();
    }

    public final /* bridge */ /* synthetic */ zzchi zzwF() {
        return super.zzwF();
    }

    public final /* bridge */ /* synthetic */ zzcfy zzwG() {
        return super.zzwG();
    }

    public final /* bridge */ /* synthetic */ void zzwn() {
        super.zzwn();
    }

    public final /* bridge */ /* synthetic */ void zzwo() {
        super.zzwo();
    }

    public final /* bridge */ /* synthetic */ void zzwp() {
        super.zzwp();
    }

    public final /* bridge */ /* synthetic */ zzcfo zzwq() {
        return super.zzwq();
    }

    public final /* bridge */ /* synthetic */ zzcfv zzwr() {
        return super.zzwr();
    }

    public final /* bridge */ /* synthetic */ zzcix zzws() {
        return super.zzws();
    }

    public final /* bridge */ /* synthetic */ zzcgs zzwt() {
        return super.zzwt();
    }

    public final /* bridge */ /* synthetic */ zzcgf zzwu() {
        return super.zzwu();
    }

    public final /* bridge */ /* synthetic */ zzcjp zzwv() {
        return super.zzwv();
    }

    public final /* bridge */ /* synthetic */ zzcjl zzww() {
        return super.zzww();
    }

    public final /* bridge */ /* synthetic */ zzcgt zzwx() {
        return super.zzwx();
    }

    public final /* bridge */ /* synthetic */ zzcfz zzwy() {
        return super.zzwy();
    }

    public final /* bridge */ /* synthetic */ zzcgv zzwz() {
        return super.zzwz();
    }
}
