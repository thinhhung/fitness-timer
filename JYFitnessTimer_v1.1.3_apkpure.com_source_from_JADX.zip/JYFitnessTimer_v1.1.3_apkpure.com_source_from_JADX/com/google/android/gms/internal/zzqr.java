package com.google.android.gms.internal;

import com.facebook.internal.NativeProtocol;
import java.util.Map;

final class zzqr implements zzrd {
    zzqr() {
    }

    public final void zza(zzalm com_google_android_gms_internal_zzalm, Map<String, String> map) {
        String str = (String) map.get(NativeProtocol.WEB_DIALOG_ACTION);
        if ("pause".equals(str)) {
            com_google_android_gms_internal_zzalm.zzaI();
        } else if ("resume".equals(str)) {
            com_google_android_gms_internal_zzalm.zzaJ();
        }
    }
}
