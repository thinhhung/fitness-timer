package com.google.android.gms.internal;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build.VERSION;
import android.support.annotation.WorkerThread;
import android.text.TextUtils;
import com.facebook.internal.AnalyticsEvents;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.util.zzf;
import com.google.firebase.iid.FirebaseInstanceId;
import java.math.BigInteger;
import java.util.Locale;

public final class zzcgs extends zzciv {
    private String mAppId;
    private String zzXD;
    private String zzaeJ;
    private String zzaeK;
    private String zzboF;
    private long zzboJ;
    private int zzbqG;
    private long zzbqH;
    private int zzbqI;

    zzcgs(zzchx com_google_android_gms_internal_zzchx) {
        super(com_google_android_gms_internal_zzchx);
    }

    @WorkerThread
    private final String zzwJ() {
        super.zzjB();
        try {
            return FirebaseInstanceId.getInstance().getId();
        } catch (IllegalStateException e) {
            super.zzwE().zzyx().log("Failed to retrieve Firebase Instance Id");
            return null;
        }
    }

    public final /* bridge */ /* synthetic */ Context getContext() {
        return super.getContext();
    }

    final String getGmpAppId() {
        zzkC();
        return this.zzXD;
    }

    @WorkerThread
    final zzcft zzdW(String str) {
        super.zzjB();
        String zzhk = zzhk();
        String gmpAppId = getGmpAppId();
        zzkC();
        String str2 = this.zzaeK;
        long zzyt = (long) zzyt();
        zzkC();
        String str3 = this.zzboF;
        long zzwO = zzcfy.zzwO();
        zzkC();
        super.zzjB();
        if (this.zzbqH == 0) {
            this.zzbqH = this.zzboi.zzwA().zzJ(super.getContext(), super.getContext().getPackageName());
        }
        long j = this.zzbqH;
        boolean isEnabled = this.zzboi.isEnabled();
        boolean z = !super.zzwF().zzbrG;
        String zzwJ = zzwJ();
        zzkC();
        long zzyW = this.zzboi.zzyW();
        zzkC();
        return new zzcft(zzhk, gmpAppId, str2, zzyt, str3, zzwO, j, str, isEnabled, z, zzwJ, 0, zzyW, this.zzbqI);
    }

    final String zzhk() {
        zzkC();
        return this.mAppId;
    }

    public final /* bridge */ /* synthetic */ void zzjB() {
        super.zzjB();
    }

    protected final void zzjC() {
        int i = 1;
        String str = "unknown";
        String str2 = AnalyticsEvents.PARAMETER_DIALOG_OUTCOME_VALUE_UNKNOWN;
        int i2 = Integer.MIN_VALUE;
        String str3 = AnalyticsEvents.PARAMETER_DIALOG_OUTCOME_VALUE_UNKNOWN;
        String packageName = super.getContext().getPackageName();
        PackageManager packageManager = super.getContext().getPackageManager();
        if (packageManager == null) {
            super.zzwE().zzyv().zzj("PackageManager is null, app identity information might be inaccurate. appId", zzcgx.zzea(packageName));
        } else {
            try {
                str = packageManager.getInstallerPackageName(packageName);
            } catch (IllegalArgumentException e) {
                super.zzwE().zzyv().zzj("Error retrieving app installer package name. appId", zzcgx.zzea(packageName));
            }
            if (str == null) {
                str = "manual_install";
            } else if ("com.android.vending".equals(str)) {
                str = "";
            }
            try {
                PackageInfo packageInfo = packageManager.getPackageInfo(super.getContext().getPackageName(), 0);
                if (packageInfo != null) {
                    CharSequence applicationLabel = packageManager.getApplicationLabel(packageInfo.applicationInfo);
                    if (!TextUtils.isEmpty(applicationLabel)) {
                        str3 = applicationLabel.toString();
                    }
                    str2 = packageInfo.versionName;
                    i2 = packageInfo.versionCode;
                }
            } catch (NameNotFoundException e2) {
                super.zzwE().zzyv().zze("Error retrieving package info. appId, appName", zzcgx.zzea(packageName), str3);
            }
        }
        this.mAppId = packageName;
        this.zzboF = str;
        this.zzaeK = str2;
        this.zzbqG = i2;
        this.zzaeJ = str3;
        this.zzbqH = 0;
        zzcfy.zzxD();
        Status zzaz = zzbey.zzaz(super.getContext());
        int i3 = (zzaz == null || !zzaz.isSuccess()) ? 0 : 1;
        if (i3 == 0) {
            if (zzaz == null) {
                super.zzwE().zzyv().log("GoogleService failed to initialize (no status)");
            } else {
                super.zzwE().zzyv().zze("GoogleService failed to initialize, status", Integer.valueOf(zzaz.getStatusCode()), zzaz.getStatusMessage());
            }
        }
        if (i3 != 0) {
            Boolean zzdO = super.zzwG().zzdO("firebase_analytics_collection_enabled");
            if (super.zzwG().zzxE()) {
                super.zzwE().zzyz().log("Collection disabled with firebase_analytics_collection_deactivated=1");
                i3 = 0;
            } else if (zzdO != null && !zzdO.booleanValue()) {
                super.zzwE().zzyz().log("Collection disabled with firebase_analytics_collection_enabled=0");
                i3 = 0;
            } else if (zzdO == null && zzcfy.zzqz()) {
                super.zzwE().zzyz().log("Collection disabled with google_app_measurement_enable=0");
                i3 = 0;
            } else {
                super.zzwE().zzyB().log("Collection enabled");
                i3 = 1;
            }
        } else {
            i3 = 0;
        }
        this.zzXD = "";
        this.zzboJ = 0;
        zzcfy.zzxD();
        try {
            String zzqy = zzbey.zzqy();
            if (TextUtils.isEmpty(zzqy)) {
                zzqy = "";
            }
            this.zzXD = zzqy;
            if (i3 != 0) {
                super.zzwE().zzyB().zze("App package, google app id", this.mAppId, this.zzXD);
            }
        } catch (IllegalStateException e3) {
            super.zzwE().zzyv().zze("getGoogleAppId or isMeasurementEnabled failed with exception. appId", zzcgx.zzea(packageName), e3);
        }
        if (VERSION.SDK_INT >= 16) {
            if (!zzbik.zzaN(super.getContext())) {
                i = 0;
            }
            this.zzbqI = i;
            return;
        }
        this.zzbqI = 0;
    }

    public final /* bridge */ /* synthetic */ zzf zzkp() {
        return super.zzkp();
    }

    public final /* bridge */ /* synthetic */ zzckx zzwA() {
        return super.zzwA();
    }

    public final /* bridge */ /* synthetic */ zzchr zzwB() {
        return super.zzwB();
    }

    public final /* bridge */ /* synthetic */ zzckm zzwC() {
        return super.zzwC();
    }

    public final /* bridge */ /* synthetic */ zzchs zzwD() {
        return super.zzwD();
    }

    public final /* bridge */ /* synthetic */ zzcgx zzwE() {
        return super.zzwE();
    }

    public final /* bridge */ /* synthetic */ zzchi zzwF() {
        return super.zzwF();
    }

    public final /* bridge */ /* synthetic */ zzcfy zzwG() {
        return super.zzwG();
    }

    public final /* bridge */ /* synthetic */ void zzwn() {
        super.zzwn();
    }

    public final /* bridge */ /* synthetic */ void zzwo() {
        super.zzwo();
    }

    public final /* bridge */ /* synthetic */ void zzwp() {
        super.zzwp();
    }

    public final /* bridge */ /* synthetic */ zzcfo zzwq() {
        return super.zzwq();
    }

    public final /* bridge */ /* synthetic */ zzcfv zzwr() {
        return super.zzwr();
    }

    public final /* bridge */ /* synthetic */ zzcix zzws() {
        return super.zzws();
    }

    public final /* bridge */ /* synthetic */ zzcgs zzwt() {
        return super.zzwt();
    }

    public final /* bridge */ /* synthetic */ zzcgf zzwu() {
        return super.zzwu();
    }

    public final /* bridge */ /* synthetic */ zzcjp zzwv() {
        return super.zzwv();
    }

    public final /* bridge */ /* synthetic */ zzcjl zzww() {
        return super.zzww();
    }

    public final /* bridge */ /* synthetic */ zzcgt zzwx() {
        return super.zzwx();
    }

    public final /* bridge */ /* synthetic */ zzcfz zzwy() {
        return super.zzwy();
    }

    public final /* bridge */ /* synthetic */ zzcgv zzwz() {
        return super.zzwz();
    }

    @WorkerThread
    final String zzys() {
        super.zzwA().zzzr().nextBytes(new byte[16]);
        return String.format(Locale.US, "%032x", new Object[]{new BigInteger(1, r0)});
    }

    final int zzyt() {
        zzkC();
        return this.zzbqG;
    }
}
