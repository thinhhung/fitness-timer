package com.google.android.gms.internal;

import android.view.ViewTreeObserver.OnScrollChangedListener;
import java.lang.ref.WeakReference;

final class zzaaq implements OnScrollChangedListener {
    private /* synthetic */ zzaaj zzSd;
    private /* synthetic */ WeakReference zzSf;

    zzaaq(zzaaj com_google_android_gms_internal_zzaaj, WeakReference weakReference) {
        this.zzSd = com_google_android_gms_internal_zzaaj;
        this.zzSf = weakReference;
    }

    public final void onScrollChanged() {
        this.zzSd.zza(this.zzSf, true);
    }
}
