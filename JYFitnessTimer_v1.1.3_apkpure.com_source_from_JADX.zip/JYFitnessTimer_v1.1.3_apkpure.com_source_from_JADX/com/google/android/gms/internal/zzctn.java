package com.google.android.gms.internal;

import android.os.RemoteException;
import com.google.android.gms.common.api.Api.zzb;
import com.google.android.gms.common.api.GoogleApiClient;

final class zzctn extends zzb {
    private /* synthetic */ byte[] zzbBS;
    private /* synthetic */ String zzbBT;

    zzctn(GoogleApiClient googleApiClient, byte[] bArr, String str) {
        this.zzbBS = bArr;
        this.zzbBT = str;
        super(googleApiClient);
    }

    protected final /* synthetic */ void zza(zzb com_google_android_gms_common_api_Api_zzb) throws RemoteException {
        ((zzctz) com_google_android_gms_common_api_Api_zzb).zzb(this.zzbCa, this.zzbBS, this.zzbBT);
    }
}
