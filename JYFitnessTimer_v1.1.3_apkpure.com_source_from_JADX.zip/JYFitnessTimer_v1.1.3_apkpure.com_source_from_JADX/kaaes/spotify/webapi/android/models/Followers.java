package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class Followers implements Parcelable {
    public static final Creator<Followers> CREATOR = new C31211();
    public String href;
    public int total;

    static class C31211 implements Creator<Followers> {
        C31211() {
        }

        public Followers createFromParcel(Parcel source) {
            return new Followers(source);
        }

        public Followers[] newArray(int size) {
            return new Followers[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.href);
        dest.writeInt(this.total);
    }

    protected Followers(Parcel in) {
        this.href = in.readString();
        this.total = in.readInt();
    }
}
