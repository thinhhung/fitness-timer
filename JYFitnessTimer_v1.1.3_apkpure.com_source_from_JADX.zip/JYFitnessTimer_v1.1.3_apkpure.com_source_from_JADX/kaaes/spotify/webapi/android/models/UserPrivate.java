package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable.Creator;

public class UserPrivate extends UserPublic {
    public static final Creator<UserPrivate> CREATOR = new C31431();
    public String birthdate;
    public String country;
    public String email;
    public String product;

    static class C31431 implements Creator<UserPrivate> {
        C31431() {
        }

        public UserPrivate createFromParcel(Parcel source) {
            return new UserPrivate(source);
        }

        public UserPrivate[] newArray(int size) {
            return new UserPrivate[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeString(this.birthdate);
        dest.writeString(this.country);
        dest.writeString(this.email);
        dest.writeString(this.product);
    }

    protected UserPrivate(Parcel in) {
        super(in);
        this.birthdate = in.readString();
        this.country = in.readString();
        this.email = in.readString();
        this.product = in.readString();
    }
}
