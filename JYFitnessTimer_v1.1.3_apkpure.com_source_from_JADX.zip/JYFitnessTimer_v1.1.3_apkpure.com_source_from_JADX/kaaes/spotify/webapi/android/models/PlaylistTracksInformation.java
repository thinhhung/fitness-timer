package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class PlaylistTracksInformation implements Parcelable {
    public static final Creator<PlaylistTracksInformation> CREATOR = new C31291();
    public String href;
    public int total;

    static class C31291 implements Creator<PlaylistTracksInformation> {
        C31291() {
        }

        public PlaylistTracksInformation createFromParcel(Parcel source) {
            return new PlaylistTracksInformation(source);
        }

        public PlaylistTracksInformation[] newArray(int size) {
            return new PlaylistTracksInformation[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.href);
        dest.writeInt(this.total);
    }

    protected PlaylistTracksInformation(Parcel in) {
        this.href = in.readString();
        this.total = in.readInt();
    }
}
