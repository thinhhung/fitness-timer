package kaaes.spotify.webapi.android.models;

import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;
import java.util.List;
import java.util.Map;

public abstract class PlaylistBase implements Parcelable {
    public Boolean collaborative;
    public Map<String, String> external_urls;
    public String href;
    public String id;
    public List<Image> images;
    @SerializedName("public")
    public Boolean is_public;
    public String name;
    public UserPublic owner;
    public String snapshot_id;
    public String type;
    public String uri;
}
