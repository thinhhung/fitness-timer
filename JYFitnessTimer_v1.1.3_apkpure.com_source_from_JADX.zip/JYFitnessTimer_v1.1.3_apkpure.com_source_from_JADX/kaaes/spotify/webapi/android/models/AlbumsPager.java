package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class AlbumsPager implements Parcelable {
    public static final Creator<AlbumsPager> CREATOR = new C31071();
    public Pager<AlbumSimple> albums;

    static class C31071 implements Creator<AlbumsPager> {
        C31071() {
        }

        public AlbumsPager createFromParcel(Parcel source) {
            return new AlbumsPager(source);
        }

        public AlbumsPager[] newArray(int size) {
            return new AlbumsPager[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(this.albums, 0);
    }

    protected AlbumsPager(Parcel in) {
        this.albums = (Pager) in.readParcelable(Pager.class.getClassLoader());
    }
}
