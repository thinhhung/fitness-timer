package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.google.gson.annotations.SerializedName;

public class PlaylistFollowPrivacy implements Parcelable {
    public static final Creator<PlaylistFollowPrivacy> CREATOR = new 1();
    @SerializedName("public")
    public Boolean is_public;

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(this.is_public);
    }

    protected PlaylistFollowPrivacy(Parcel in) {
        this.is_public = (Boolean) in.readValue(Boolean.class.getClassLoader());
    }
}
