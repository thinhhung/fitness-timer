package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import java.util.ArrayList;
import java.util.List;

public class TracksToRemove implements Parcelable {
    public static final Creator<TracksToRemove> CREATOR = new C31411();
    public List<TrackToRemove> tracks;

    static class C31411 implements Creator<TracksToRemove> {
        C31411() {
        }

        public TracksToRemove createFromParcel(Parcel source) {
            return new TracksToRemove(source);
        }

        public TracksToRemove[] newArray(int size) {
            return new TracksToRemove[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeList(this.tracks);
    }

    protected TracksToRemove(Parcel in) {
        this.tracks = new ArrayList();
        in.readList(this.tracks, List.class.getClassLoader());
    }
}
