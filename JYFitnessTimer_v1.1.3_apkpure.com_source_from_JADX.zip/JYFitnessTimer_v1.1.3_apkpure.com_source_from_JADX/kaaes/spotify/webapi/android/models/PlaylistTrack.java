package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class PlaylistTrack implements Parcelable {
    public static final Creator<PlaylistTrack> CREATOR = new C31281();
    public String added_at;
    public UserPublic added_by;
    public Boolean is_local;
    public Track track;

    static class C31281 implements Creator<PlaylistTrack> {
        C31281() {
        }

        public PlaylistTrack createFromParcel(Parcel source) {
            return new PlaylistTrack(source);
        }

        public PlaylistTrack[] newArray(int size) {
            return new PlaylistTrack[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.added_at);
        dest.writeParcelable(this.added_by, flags);
        dest.writeParcelable(this.track, 0);
        dest.writeValue(this.is_local);
    }

    protected PlaylistTrack(Parcel in) {
        this.added_at = in.readString();
        this.added_by = (UserPublic) in.readParcelable(UserPublic.class.getClassLoader());
        this.track = (Track) in.readParcelable(Track.class.getClassLoader());
        this.is_local = (Boolean) in.readValue(Boolean.class.getClassLoader());
    }
}
