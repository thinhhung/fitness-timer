package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import java.util.ArrayList;
import java.util.List;

public class TracksToRemoveWithPosition implements Parcelable {
    public static final Creator<TracksToRemoveWithPosition> CREATOR = new C31421();
    public List<TrackToRemoveWithPosition> tracks;

    static class C31421 implements Creator<TracksToRemoveWithPosition> {
        C31421() {
        }

        public TracksToRemoveWithPosition createFromParcel(Parcel source) {
            return new TracksToRemoveWithPosition(source);
        }

        public TracksToRemoveWithPosition[] newArray(int size) {
            return new TracksToRemoveWithPosition[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeList(this.tracks);
    }

    protected TracksToRemoveWithPosition(Parcel in) {
        this.tracks = new ArrayList();
        in.readList(this.tracks, List.class.getClassLoader());
    }
}
