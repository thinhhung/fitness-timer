package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable.Creator;

public class Playlist extends PlaylistBase {
    public static final Creator<Playlist> CREATOR = new C31261();
    public String description;
    public Followers followers;
    public Pager<PlaylistTrack> tracks;

    static class C31261 implements Creator<Playlist> {
        C31261() {
        }

        public Playlist createFromParcel(Parcel source) {
            return new Playlist(source);
        }

        public Playlist[] newArray(int size) {
            return new Playlist[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.description);
        dest.writeParcelable(this.followers, 0);
        dest.writeParcelable(this.tracks, 0);
    }

    protected Playlist(Parcel in) {
        this.description = in.readString();
        this.followers = (Followers) in.readParcelable(Followers.class.getClassLoader());
        this.tracks = (Pager) in.readParcelable(Pager.class.getClassLoader());
    }
}
