package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import java.util.Map;

public class Track extends TrackSimple {
    public static final Creator<Track> CREATOR = new C31351();
    public AlbumSimple album;
    public Map<String, String> external_ids;
    public Integer popularity;

    static class C31351 implements Creator<Track> {
        C31351() {
        }

        public Track createFromParcel(Parcel source) {
            return new Track(source);
        }

        public Track[] newArray(int size) {
            return new Track[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeParcelable(this.album, 0);
        dest.writeMap(this.external_ids);
        dest.writeValue(this.popularity);
    }

    protected Track(Parcel in) {
        super(in);
        this.album = (AlbumSimple) in.readParcelable(AlbumSimple.class.getClassLoader());
        this.external_ids = in.readHashMap(Map.class.getClassLoader());
        this.popularity = (Integer) in.readValue(Integer.class.getClassLoader());
    }
}
