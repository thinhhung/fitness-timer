package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class NewReleases implements Parcelable {
    public static final Creator<NewReleases> CREATOR = new C31241();
    public Pager<AlbumSimple> albums;

    static class C31241 implements Creator<NewReleases> {
        C31241() {
        }

        public NewReleases createFromParcel(Parcel source) {
            return new NewReleases(source);
        }

        public NewReleases[] newArray(int size) {
            return new NewReleases[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(this.albums, 0);
    }

    protected NewReleases(Parcel in) {
        this.albums = (Pager) in.readParcelable(Pager.class.getClassLoader());
    }
}
