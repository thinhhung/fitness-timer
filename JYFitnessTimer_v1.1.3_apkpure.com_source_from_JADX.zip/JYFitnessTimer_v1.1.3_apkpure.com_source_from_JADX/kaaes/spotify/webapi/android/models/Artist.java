package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import java.util.List;

public class Artist extends ArtistSimple {
    public static final Creator<Artist> CREATOR = new C31081();
    public Followers followers;
    public List<String> genres;
    public List<Image> images;
    public Integer popularity;

    static class C31081 implements Creator<Artist> {
        C31081() {
        }

        public Artist createFromParcel(Parcel source) {
            return new Artist(source);
        }

        public Artist[] newArray(int size) {
            return new Artist[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeParcelable(this.followers, flags);
        dest.writeStringList(this.genres);
        dest.writeTypedList(this.images);
        dest.writeValue(this.popularity);
    }

    protected Artist(Parcel in) {
        super(in);
        this.followers = (Followers) in.readParcelable(Followers.class.getClassLoader());
        this.genres = in.createStringArrayList();
        this.images = in.createTypedArrayList(Image.CREATOR);
        this.popularity = (Integer) in.readValue(Integer.class.getClassLoader());
    }
}
