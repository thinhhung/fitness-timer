package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class SavedAlbum implements Parcelable {
    public static final Creator<SavedAlbum> CREATOR = new C31321();
    public String added_at;
    public Album album;

    static class C31321 implements Creator<SavedAlbum> {
        C31321() {
        }

        public SavedAlbum createFromParcel(Parcel source) {
            return new SavedAlbum(source);
        }

        public SavedAlbum[] newArray(int size) {
            return new SavedAlbum[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.added_at);
        dest.writeParcelable(this.album, 0);
    }

    protected SavedAlbum(Parcel in) {
        this.added_at = in.readString();
        this.album = (Album) in.readParcelable(Album.class.getClassLoader());
    }
}
