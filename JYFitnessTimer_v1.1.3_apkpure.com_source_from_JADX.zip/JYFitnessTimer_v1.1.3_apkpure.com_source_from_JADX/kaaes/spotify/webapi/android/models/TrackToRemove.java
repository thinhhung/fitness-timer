package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class TrackToRemove implements Parcelable {
    public static final Creator<TrackToRemove> CREATOR = new C31371();
    public String uri;

    static class C31371 implements Creator<TrackToRemove> {
        C31371() {
        }

        public TrackToRemove createFromParcel(Parcel source) {
            return new TrackToRemove(source);
        }

        public TrackToRemove[] newArray(int size) {
            return new TrackToRemove[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.uri);
    }

    protected TrackToRemove(Parcel in) {
        this.uri = in.readString();
    }
}
