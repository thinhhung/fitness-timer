package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class Cursor implements Parcelable {
    public static final Creator<Cursor> CREATOR = new C31161();
    public String after;

    static class C31161 implements Creator<Cursor> {
        C31161() {
        }

        public Cursor createFromParcel(Parcel source) {
            return new Cursor(source);
        }

        public Cursor[] newArray(int size) {
            return new Cursor[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.after);
    }

    protected Cursor(Parcel in) {
        this.after = in.readString();
    }
}
