package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class SavedTrack implements Parcelable {
    public static final Creator<SavedTrack> CREATOR = new C31331();
    public String added_at;
    public Track track;

    static class C31331 implements Creator<SavedTrack> {
        C31331() {
        }

        public SavedTrack createFromParcel(Parcel source) {
            return new SavedTrack(source);
        }

        public SavedTrack[] newArray(int size) {
            return new SavedTrack[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.added_at);
        dest.writeParcelable(this.track, 0);
    }

    protected SavedTrack(Parcel in) {
        this.added_at = in.readString();
        this.track = (Track) in.readParcelable(Track.class.getClassLoader());
    }
}
