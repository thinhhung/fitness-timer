package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import java.util.List;
import java.util.Map;

public class Album extends AlbumSimple implements Parcelable {
    public static final Creator<Album> CREATOR = new C31041();
    public List<ArtistSimple> artists;
    public List<Copyright> copyrights;
    public Map<String, String> external_ids;
    public List<String> genres;
    public Integer popularity;
    public String release_date;
    public String release_date_precision;
    public Pager<TrackSimple> tracks;

    static class C31041 implements Creator<Album> {
        C31041() {
        }

        public Album createFromParcel(Parcel source) {
            return new Album(source);
        }

        public Album[] newArray(int size) {
            return new Album[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeTypedList(this.artists);
        dest.writeTypedList(this.copyrights);
        dest.writeMap(this.external_ids);
        dest.writeStringList(this.genres);
        dest.writeValue(this.popularity);
        dest.writeString(this.release_date);
        dest.writeString(this.release_date_precision);
        dest.writeParcelable(this.tracks, flags);
    }

    protected Album(Parcel in) {
        this.artists = in.createTypedArrayList(ArtistSimple.CREATOR);
        this.copyrights = in.createTypedArrayList(Copyright.CREATOR);
        this.external_ids = in.readHashMap(ClassLoader.getSystemClassLoader());
        this.genres = in.createStringArrayList();
        this.popularity = (Integer) in.readValue(Integer.class.getClassLoader());
        this.release_date = in.readString();
        this.release_date_precision = in.readString();
        this.tracks = (Pager) in.readParcelable(Pager.class.getClassLoader());
    }
}
