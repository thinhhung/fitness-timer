package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable.Creator;

public class PlaylistSimple extends PlaylistBase {
    public static final Creator<PlaylistSimple> CREATOR = new C31271();
    public PlaylistTracksInformation tracks;

    static class C31271 implements Creator<PlaylistSimple> {
        C31271() {
        }

        public PlaylistSimple createFromParcel(Parcel source) {
            return new PlaylistSimple(source);
        }

        public PlaylistSimple[] newArray(int size) {
            return new PlaylistSimple[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(this.tracks, flags);
    }

    protected PlaylistSimple(Parcel in) {
        this.tracks = (PlaylistTracksInformation) in.readParcelable(PlaylistTracksInformation.class.getClassLoader());
    }
}
