package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class TracksPager implements Parcelable {
    public static final Creator<TracksPager> CREATOR = new C31401();
    public Pager<Track> tracks;

    static class C31401 implements Creator<TracksPager> {
        C31401() {
        }

        public TracksPager createFromParcel(Parcel source) {
            return new TracksPager(source);
        }

        public TracksPager[] newArray(int size) {
            return new TracksPager[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(this.tracks, 0);
    }

    protected TracksPager(Parcel in) {
        this.tracks = (Pager) in.readParcelable(Pager.class.getClassLoader());
    }
}
