package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import java.util.Map;

public class LinkedTrack implements Parcelable {
    public static final Creator<LinkedTrack> CREATOR = new C31231();
    public Map<String, String> external_urls;
    public String href;
    public String id;
    public String type;
    public String uri;

    static class C31231 implements Creator<LinkedTrack> {
        C31231() {
        }

        public LinkedTrack createFromParcel(Parcel source) {
            return new LinkedTrack(source);
        }

        public LinkedTrack[] newArray(int size) {
            return new LinkedTrack[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeMap(this.external_urls);
        dest.writeString(this.href);
        dest.writeString(this.id);
        dest.writeString(this.type);
        dest.writeString(this.uri);
    }

    protected LinkedTrack(Parcel in) {
        this.external_urls = in.readHashMap(ClassLoader.getSystemClassLoader());
        this.href = in.readString();
        this.id = in.readString();
        this.type = in.readString();
        this.uri = in.readString();
    }
}
