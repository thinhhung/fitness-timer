package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class PlaylistsPager implements Parcelable {
    public static final Creator<PlaylistsPager> CREATOR = new C31301();
    public Pager<PlaylistSimple> playlists;

    static class C31301 implements Creator<PlaylistsPager> {
        C31301() {
        }

        public PlaylistsPager createFromParcel(Parcel source) {
            return new PlaylistsPager(source);
        }

        public PlaylistsPager[] newArray(int size) {
            return new PlaylistsPager[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(this.playlists, 0);
    }

    protected PlaylistsPager(Parcel in) {
        this.playlists = (Pager) in.readParcelable(Pager.class.getClassLoader());
    }
}
