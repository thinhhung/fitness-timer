package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable.Creator;

class PlaylistFollowPrivacy$1 implements Creator<PlaylistFollowPrivacy> {
    PlaylistFollowPrivacy$1() {
    }

    public PlaylistFollowPrivacy createFromParcel(Parcel source) {
        return new PlaylistFollowPrivacy(source);
    }

    public PlaylistFollowPrivacy[] newArray(int size) {
        return new PlaylistFollowPrivacy[size];
    }
}
