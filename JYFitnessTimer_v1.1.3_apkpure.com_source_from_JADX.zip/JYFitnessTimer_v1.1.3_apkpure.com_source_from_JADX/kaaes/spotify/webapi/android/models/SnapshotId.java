package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class SnapshotId implements Parcelable {
    public static final Creator<SnapshotId> CREATOR = new C31341();
    public String snapshot_id;

    static class C31341 implements Creator<SnapshotId> {
        C31341() {
        }

        public SnapshotId createFromParcel(Parcel source) {
            return new SnapshotId(source);
        }

        public SnapshotId[] newArray(int size) {
            return new SnapshotId[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.snapshot_id);
    }

    protected SnapshotId(Parcel in) {
        this.snapshot_id = in.readString();
    }
}
