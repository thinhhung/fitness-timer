package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import java.util.List;

public class Artists implements Parcelable {
    public static final Creator<Artists> CREATOR = new C31101();
    public List<Artist> artists;

    static class C31101 implements Creator<Artists> {
        C31101() {
        }

        public Artists createFromParcel(Parcel source) {
            return new Artists(source);
        }

        public Artists[] newArray(int size) {
            return new Artists[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeTypedList(this.artists);
    }

    protected Artists(Parcel in) {
        this.artists = in.createTypedArrayList(Artist.CREATOR);
    }
}
