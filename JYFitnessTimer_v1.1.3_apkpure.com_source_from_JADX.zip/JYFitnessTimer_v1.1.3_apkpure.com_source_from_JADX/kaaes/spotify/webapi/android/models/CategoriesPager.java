package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class CategoriesPager implements Parcelable {
    public static final Creator<CategoriesPager> CREATOR = new C31131();
    public Pager<Category> categories;

    static class C31131 implements Creator<CategoriesPager> {
        C31131() {
        }

        public CategoriesPager createFromParcel(Parcel source) {
            return new CategoriesPager(source);
        }

        public CategoriesPager[] newArray(int size) {
            return new CategoriesPager[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(this.categories, 0);
    }

    protected CategoriesPager(Parcel in) {
        this.categories = (Pager) in.readParcelable(Pager.class.getClassLoader());
    }
}
