package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class FeaturedPlaylists implements Parcelable {
    public static final Creator<FeaturedPlaylists> CREATOR = new C31201();
    public String message;
    public Pager<PlaylistSimple> playlists;

    static class C31201 implements Creator<FeaturedPlaylists> {
        C31201() {
        }

        public FeaturedPlaylists createFromParcel(Parcel source) {
            return new FeaturedPlaylists(source);
        }

        public FeaturedPlaylists[] newArray(int size) {
            return new FeaturedPlaylists[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.message);
        dest.writeParcelable(this.playlists, 0);
    }

    protected FeaturedPlaylists(Parcel in) {
        this.message = in.readString();
        this.playlists = (Pager) in.readParcelable(Pager.class.getClassLoader());
    }
}
