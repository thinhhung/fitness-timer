package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class ErrorResponse implements Parcelable {
    public static final Creator<ErrorResponse> CREATOR = new C31191();
    public ErrorDetails error;

    static class C31191 implements Creator<ErrorResponse> {
        C31191() {
        }

        public ErrorResponse createFromParcel(Parcel source) {
            return new ErrorResponse(source);
        }

        public ErrorResponse[] newArray(int size) {
            return new ErrorResponse[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(this.error, 0);
    }

    protected ErrorResponse(Parcel in) {
        this.error = (ErrorDetails) in.readParcelable(ErrorDetails.class.getClassLoader());
    }
}
