package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class ArtistsPager implements Parcelable {
    public static final Creator<ArtistsPager> CREATOR = new C31121();
    public Pager<Artist> artists;

    static class C31121 implements Creator<ArtistsPager> {
        C31121() {
        }

        public ArtistsPager createFromParcel(Parcel source) {
            return new ArtistsPager(source);
        }

        public ArtistsPager[] newArray(int size) {
            return new ArtistsPager[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(this.artists, 0);
    }

    protected ArtistsPager(Parcel in) {
        this.artists = (Pager) in.readParcelable(Pager.class.getClassLoader());
    }
}
