package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class Result implements Parcelable {
    public static final Creator<Result> CREATOR = new C31311();

    static class C31311 implements Creator<Result> {
        C31311() {
        }

        public Result createFromParcel(Parcel source) {
            return new Result(source);
        }

        public Result[] newArray(int size) {
            return new Result[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
    }

    protected Result(Parcel in) {
    }
}
