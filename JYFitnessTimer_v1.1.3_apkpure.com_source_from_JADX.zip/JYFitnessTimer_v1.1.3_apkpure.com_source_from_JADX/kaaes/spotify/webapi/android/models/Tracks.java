package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import java.util.List;

public class Tracks implements Parcelable {
    public static final Creator<Tracks> CREATOR = new C31391();
    public List<Track> tracks;

    static class C31391 implements Creator<Tracks> {
        C31391() {
        }

        public Tracks createFromParcel(Parcel source) {
            return new Tracks(source);
        }

        public Tracks[] newArray(int size) {
            return new Tracks[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeTypedList(this.tracks);
    }

    protected Tracks(Parcel in) {
        this.tracks = in.createTypedArrayList(Track.CREATOR);
    }
}
