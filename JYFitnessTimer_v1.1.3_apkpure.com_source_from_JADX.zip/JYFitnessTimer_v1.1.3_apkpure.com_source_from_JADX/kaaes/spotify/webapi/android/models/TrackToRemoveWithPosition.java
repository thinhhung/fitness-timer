package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import java.util.ArrayList;
import java.util.List;

public class TrackToRemoveWithPosition implements Parcelable {
    public static final Creator<TrackToRemoveWithPosition> CREATOR = new C31381();
    public List<Integer> positions;
    public String uri;

    static class C31381 implements Creator<TrackToRemoveWithPosition> {
        C31381() {
        }

        public TrackToRemoveWithPosition createFromParcel(Parcel source) {
            return new TrackToRemoveWithPosition(source);
        }

        public TrackToRemoveWithPosition[] newArray(int size) {
            return new TrackToRemoveWithPosition[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.uri);
        dest.writeList(this.positions);
    }

    protected TrackToRemoveWithPosition(Parcel in) {
        this.uri = in.readString();
        this.positions = new ArrayList();
        in.readList(this.positions, List.class.getClassLoader());
    }
}
