package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import java.util.List;

public class Albums implements Parcelable {
    public static final Creator<Albums> CREATOR = new C31061();
    public List<Album> albums;

    static class C31061 implements Creator<Albums> {
        C31061() {
        }

        public Albums createFromParcel(Parcel source) {
            return new Albums(source);
        }

        public Albums[] newArray(int size) {
            return new Albums[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeTypedList(this.albums);
    }

    protected Albums(Parcel in) {
        this.albums = in.createTypedArrayList(Album.CREATOR);
    }
}
