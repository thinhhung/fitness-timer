package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class ArtistsCursorPager implements Parcelable {
    public static final Creator<ArtistsCursorPager> CREATOR = new C31111();
    public CursorPager<Artist> artists;

    static class C31111 implements Creator<ArtistsCursorPager> {
        C31111() {
        }

        public ArtistsCursorPager createFromParcel(Parcel source) {
            return new ArtistsCursorPager(source);
        }

        public ArtistsCursorPager[] newArray(int size) {
            return new ArtistsCursorPager[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelable(this.artists, 0);
    }

    protected ArtistsCursorPager(Parcel in) {
        this.artists = (CursorPager) in.readParcelable(Pager.class.getClassLoader());
    }
}
