package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import java.util.List;

public class Category implements Parcelable {
    public static final Creator<Category> CREATOR = new C31141();
    public String href;
    public List<Image> icons;
    public String id;
    public String name;

    static class C31141 implements Creator<Category> {
        C31141() {
        }

        public Category createFromParcel(Parcel source) {
            return new Category(source);
        }

        public Category[] newArray(int size) {
            return new Category[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.href);
        dest.writeTypedList(this.icons);
        dest.writeString(this.id);
        dest.writeString(this.name);
    }

    protected Category(Parcel in) {
        this.href = in.readString();
        this.icons = in.createTypedArrayList(Image.CREATOR);
        this.id = in.readString();
        this.name = in.readString();
    }
}
