package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import java.util.ArrayList;
import java.util.List;

public class CursorPager<T> implements Parcelable {
    public static final Creator<CursorPager> CREATOR = new C31171();
    public Cursor cursors;
    public String href;
    public List<T> items;
    public int limit;
    public String next;
    public int total;

    static class C31171 implements Creator<CursorPager> {
        C31171() {
        }

        public CursorPager createFromParcel(Parcel source) {
            return new CursorPager(source);
        }

        public CursorPager[] newArray(int size) {
            return new CursorPager[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.href);
        dest.writeList(this.items);
        dest.writeInt(this.limit);
        dest.writeString(this.next);
        dest.writeParcelable(this.cursors, flags);
        dest.writeInt(this.total);
    }

    protected CursorPager(Parcel in) {
        this.href = in.readString();
        this.items = in.readArrayList(ArrayList.class.getClassLoader());
        this.limit = in.readInt();
        this.next = in.readString();
        this.cursors = (Cursor) in.readParcelable(Cursor.class.getClassLoader());
        this.total = in.readInt();
    }
}
