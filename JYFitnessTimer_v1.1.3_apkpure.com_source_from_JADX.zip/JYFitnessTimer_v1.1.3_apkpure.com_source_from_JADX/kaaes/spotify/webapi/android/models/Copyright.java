package kaaes.spotify.webapi.android.models;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

public class Copyright implements Parcelable {
    public static final Creator<Copyright> CREATOR = new C31151();
    public String text;
    public String type;

    static class C31151 implements Creator<Copyright> {
        C31151() {
        }

        public Copyright createFromParcel(Parcel source) {
            return new Copyright(source);
        }

        public Copyright[] newArray(int size) {
            return new Copyright[size];
        }
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.text);
        dest.writeString(this.type);
    }

    protected Copyright(Parcel in) {
        this.text = in.readString();
        this.type = in.readString();
    }
}
