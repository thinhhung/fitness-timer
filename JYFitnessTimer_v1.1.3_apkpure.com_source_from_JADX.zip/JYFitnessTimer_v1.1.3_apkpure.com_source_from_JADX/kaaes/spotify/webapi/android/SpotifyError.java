package kaaes.spotify.webapi.android;

import kaaes.spotify.webapi.android.models.ErrorDetails;
import kaaes.spotify.webapi.android.models.ErrorResponse;
import retrofit.RetrofitError;

public class SpotifyError extends Exception {
    private final ErrorDetails mErrorDetails;
    private final RetrofitError mRetrofitError;

    public static SpotifyError fromRetrofitError(RetrofitError error) {
        ErrorResponse errorResponse = (ErrorResponse) error.getBodyAs(ErrorResponse.class);
        if (errorResponse == null || errorResponse.error == null) {
            return new SpotifyError(error);
        }
        return new SpotifyError(error, errorResponse.error, errorResponse.error.status + " " + errorResponse.error.message);
    }

    public SpotifyError(RetrofitError retrofitError, ErrorDetails errorDetails, String message) {
        super(message, retrofitError);
        this.mRetrofitError = retrofitError;
        this.mErrorDetails = errorDetails;
    }

    public SpotifyError(RetrofitError retrofitError) {
        super(retrofitError);
        this.mRetrofitError = retrofitError;
        this.mErrorDetails = null;
    }

    public RetrofitError getRetrofitError() {
        return this.mRetrofitError;
    }

    public boolean hasErrorDetails() {
        return this.mErrorDetails != null;
    }

    public ErrorDetails getErrorDetails() {
        return this.mErrorDetails;
    }
}
