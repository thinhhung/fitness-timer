package kaaes.spotify.webapi.android;

import retrofit.Callback;
import retrofit.RetrofitError;

public abstract class SpotifyCallback<T> implements Callback<T> {
    public abstract void failure(SpotifyError spotifyError);

    public void failure(RetrofitError error) {
        failure(SpotifyError.fromRetrofitError(error));
    }
}
