package kaaes.spotify.webapi.android;

import io.fabric.sdk.android.services.network.HttpRequest;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import retrofit.RequestInterceptor;
import retrofit.RequestInterceptor.RequestFacade;
import retrofit.RestAdapter.Builder;
import retrofit.RestAdapter.LogLevel;
import retrofit.android.MainThreadExecutor;

public class SpotifyApi {
    public static final String SPOTIFY_WEB_API_ENDPOINT = "https://api.spotify.com/v1";
    private String mAccessToken;
    private final SpotifyService mSpotifyService;

    private class WebApiAuthenticator implements RequestInterceptor {
        private WebApiAuthenticator() {
        }

        public void intercept(RequestFacade request) {
            if (SpotifyApi.this.mAccessToken != null) {
                request.addHeader(HttpRequest.HEADER_AUTHORIZATION, "Bearer " + SpotifyApi.this.mAccessToken);
            }
        }
    }

    public SpotifyApi(Executor httpExecutor, Executor callbackExecutor) {
        this.mSpotifyService = init(httpExecutor, callbackExecutor);
    }

    private SpotifyService init(Executor httpExecutor, Executor callbackExecutor) {
        return (SpotifyService) new Builder().setLogLevel(LogLevel.BASIC).setExecutors(httpExecutor, callbackExecutor).setEndpoint(SPOTIFY_WEB_API_ENDPOINT).setRequestInterceptor(new WebApiAuthenticator()).build().create(SpotifyService.class);
    }

    public SpotifyApi() {
        this.mSpotifyService = init(Executors.newSingleThreadExecutor(), new MainThreadExecutor());
    }

    public SpotifyApi setAccessToken(String accessToken) {
        this.mAccessToken = accessToken;
        return this;
    }

    public SpotifyService getService() {
        return this.mSpotifyService;
    }
}
